#!/bin/bash

curdir=`dirname $0`
cd $curdir
./icnc
