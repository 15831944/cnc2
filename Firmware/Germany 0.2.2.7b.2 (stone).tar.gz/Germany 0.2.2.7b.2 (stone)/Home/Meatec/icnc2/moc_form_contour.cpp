/****************************************************************************
** Meta object code from reading C++ file 'form_contour.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../ICNC/form_contour.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'form_contour.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_FormContour_t {
    QByteArrayData data[31];
    char stringdata0[541];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_FormContour_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_FormContour_t qt_meta_stringdata_FormContour = {
    {
QT_MOC_LITERAL(0, 0, 11), // "FormContour"
QT_MOC_LITERAL(1, 12, 15), // "homePageClicked"
QT_MOC_LITERAL(2, 28, 0), // ""
QT_MOC_LITERAL(3, 29, 17), // "passesPageClicked"
QT_MOC_LITERAL(4, 47, 15), // "editPageClicked"
QT_MOC_LITERAL(5, 63, 9), // "auto_plot"
QT_MOC_LITERAL(6, 73, 15), // "helpPageClicked"
QT_MOC_LITERAL(7, 89, 9), // "file_name"
QT_MOC_LITERAL(8, 99, 17), // "on_btnBot_clicked"
QT_MOC_LITERAL(9, 117, 17), // "on_btnTop_clicked"
QT_MOC_LITERAL(10, 135, 20), // "on_btnSimple_clicked"
QT_MOC_LITERAL(11, 156, 24), // "on_btnNewContour_clicked"
QT_MOC_LITERAL(12, 181, 24), // "on_btnNewCutline_clicked"
QT_MOC_LITERAL(13, 206, 20), // "on_btnDelete_clicked"
QT_MOC_LITERAL(14, 227, 19), // "on_btnClear_clicked"
QT_MOC_LITERAL(15, 247, 21), // "on_btnReverse_clicked"
QT_MOC_LITERAL(16, 269, 14), // "onBeginClicked"
QT_MOC_LITERAL(17, 284, 21), // "onViewContoursClicked"
QT_MOC_LITERAL(18, 306, 11), // "QModelIndex"
QT_MOC_LITERAL(19, 318, 20), // "onViewContourClicked"
QT_MOC_LITERAL(20, 339, 23), // "on_actCutline_triggered"
QT_MOC_LITERAL(21, 363, 25), // "on_actExitPoint_triggered"
QT_MOC_LITERAL(22, 389, 22), // "on_actRotate_triggered"
QT_MOC_LITERAL(23, 412, 22), // "on_actResize_triggered"
QT_MOC_LITERAL(24, 435, 29), // "on_actFlipLeftRight_triggered"
QT_MOC_LITERAL(25, 465, 26), // "on_actFlipUpDown_triggered"
QT_MOC_LITERAL(26, 492, 10), // "onGenerate"
QT_MOC_LITERAL(27, 503, 16), // "setFontPointSize"
QT_MOC_LITERAL(28, 520, 8), // "QWidget*"
QT_MOC_LITERAL(29, 529, 1), // "w"
QT_MOC_LITERAL(30, 531, 9) // "pointSize"

    },
    "FormContour\0homePageClicked\0\0"
    "passesPageClicked\0editPageClicked\0"
    "auto_plot\0helpPageClicked\0file_name\0"
    "on_btnBot_clicked\0on_btnTop_clicked\0"
    "on_btnSimple_clicked\0on_btnNewContour_clicked\0"
    "on_btnNewCutline_clicked\0on_btnDelete_clicked\0"
    "on_btnClear_clicked\0on_btnReverse_clicked\0"
    "onBeginClicked\0onViewContoursClicked\0"
    "QModelIndex\0onViewContourClicked\0"
    "on_actCutline_triggered\0"
    "on_actExitPoint_triggered\0"
    "on_actRotate_triggered\0on_actResize_triggered\0"
    "on_actFlipLeftRight_triggered\0"
    "on_actFlipUpDown_triggered\0onGenerate\0"
    "setFontPointSize\0QWidget*\0w\0pointSize"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_FormContour[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x06 /* Public */,
       3,    0,  130,    2, 0x06 /* Public */,
       4,    1,  131,    2, 0x06 /* Public */,
       6,    1,  134,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,  137,    2, 0x08 /* Private */,
       9,    0,  138,    2, 0x08 /* Private */,
      10,    0,  139,    2, 0x08 /* Private */,
      11,    0,  140,    2, 0x08 /* Private */,
      12,    0,  141,    2, 0x08 /* Private */,
      13,    0,  142,    2, 0x08 /* Private */,
      14,    0,  143,    2, 0x08 /* Private */,
      15,    0,  144,    2, 0x08 /* Private */,
      16,    0,  145,    2, 0x08 /* Private */,
      17,    1,  146,    2, 0x08 /* Private */,
      19,    1,  149,    2, 0x08 /* Private */,
      20,    0,  152,    2, 0x08 /* Private */,
      21,    0,  153,    2, 0x08 /* Private */,
      22,    0,  154,    2, 0x08 /* Private */,
      23,    0,  155,    2, 0x08 /* Private */,
      24,    0,  156,    2, 0x08 /* Private */,
      25,    0,  157,    2, 0x08 /* Private */,
      26,    0,  158,    2, 0x08 /* Private */,
      27,    2,  159,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::QString,    7,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 18,    2,
    QMetaType::Void, 0x80000000 | 18,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28, QMetaType::Int,   29,   30,

       0        // eod
};

void FormContour::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FormContour *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->homePageClicked(); break;
        case 1: _t->passesPageClicked(); break;
        case 2: _t->editPageClicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->helpPageClicked((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->on_btnBot_clicked(); break;
        case 5: _t->on_btnTop_clicked(); break;
        case 6: _t->on_btnSimple_clicked(); break;
        case 7: _t->on_btnNewContour_clicked(); break;
        case 8: _t->on_btnNewCutline_clicked(); break;
        case 9: _t->on_btnDelete_clicked(); break;
        case 10: _t->on_btnClear_clicked(); break;
        case 11: _t->on_btnReverse_clicked(); break;
        case 12: _t->onBeginClicked(); break;
        case 13: _t->onViewContoursClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 14: _t->onViewContourClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 15: _t->on_actCutline_triggered(); break;
        case 16: _t->on_actExitPoint_triggered(); break;
        case 17: _t->on_actRotate_triggered(); break;
        case 18: _t->on_actResize_triggered(); break;
        case 19: _t->on_actFlipLeftRight_triggered(); break;
        case 20: _t->on_actFlipUpDown_triggered(); break;
        case 21: _t->onGenerate(); break;
        case 22: _t->setFontPointSize((*reinterpret_cast< QWidget*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 22:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FormContour::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FormContour::homePageClicked)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FormContour::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FormContour::passesPageClicked)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FormContour::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FormContour::editPageClicked)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FormContour::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&FormContour::helpPageClicked)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject FormContour::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_FormContour.data,
    qt_meta_data_FormContour,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *FormContour::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *FormContour::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_FormContour.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int FormContour::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void FormContour::homePageClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void FormContour::passesPageClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void FormContour::editPageClicked(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void FormContour::helpPageClicked(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
