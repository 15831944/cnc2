#ifndef INC_DEFINES_H_
#define INC_DEFINES_H_

#define NAME ("CNC")
#define MODEL ("0")

#define VER_TYPE (1) // 0 - stable, 1 - alpha, 2 - beta
#define FAC_VER (0)
#define FAC_REV (0)
#define VER (1)
#define REV (9) // first UV version

//#define RESEASE
//#define WDT_ENA

///////////////////////////////////////
#define FPGA_CLOCK (72e6) // Hz

#define ROLLBACK_DEFAULT	(0.3) // mm

//#define F_DEFAULT (1.0 / 1000.0 * 60) // step in 1 sec
#define F_DEFAULT_UMS	(300.0) // um/s
//#define F_DEFAULT		(F_DEFAULT_UMS / 1000.0 * 60) // 18 mm/min
#define T_DEFAULT_TICK	( FPGA_CLOCK / (F_DEFAULT_UMS * 1e-3) ) // 240,000,000 clocks/mm

#define SCALE			(1000.0) // steps / mm
#define SCALE_UV		(1000.0) // steps / mm
#define SCALE_ENC		(1000.0 / 5) // steps / mm
#define DEFAULT_STEP	(0.001) // mm
#define STEP_MIN		(0.001) // mm
#define CMP_PREC		(STEP_MIN / 2) // mm

#define PRINT

//#define SUM_IMIT_STEPS

//#define UDIV_CEIL(N, D) (N % D ? N / D + 1 : N / D)

#endif /* INC_DEFINES_H_ */
