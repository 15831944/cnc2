#include "moving_avg.h"

#include <stdio.h>

static float ar[MOVING_AVG_LEN] = {0};
static int wraddr = 0;
static int valid = 0;
static float sum = 0;

void mavg_clear() {
	wraddr = 0;
	valid = 0;
	sum = 0;
}

void mavg_add(float value) {
	float old = ar[wraddr];
	ar[wraddr++] = value;
	sum += valid ? value - old : value;

	if (wraddr >= MOVING_AVG_LEN) {
		wraddr = 0;
		valid = 1;
	}
}

float mavg_get() {
//	return valid ? sum / MOVING_AVG_LEN : 0;
	return sum / MOVING_AVG_LEN;
}


void mavg_tb() {
	printf("avg_tb:\n");
	for (int i = 0; i < 0x100; i++) {
		int x = i & 0x3f;
		mavg_add(100 + x);
		printf("%d %d\n", x, (int)mavg_get());
	}

	printf("avg clear\n");
	mavg_clear();
	for (int i = 0; i < 0x100; i++) {
		int x = i & 0x3f;
		mavg_add(-100 + x);
		printf("%d %d\n", x, (int)mavg_get());
	}
}
