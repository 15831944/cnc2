#ifndef INC_COM_TASK_H_
#define INC_COM_TASK_H_

void com_task();

#endif /* INC_COM_TASK_H_ */
