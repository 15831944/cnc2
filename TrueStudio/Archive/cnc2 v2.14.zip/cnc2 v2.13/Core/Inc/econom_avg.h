#ifndef INC_ECONOM_AVG_H_
#define INC_ECONOM_AVG_H_



#endif /* INC_ECONOM_AVG_H_ */
