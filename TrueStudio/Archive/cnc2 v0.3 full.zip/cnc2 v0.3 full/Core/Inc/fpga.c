#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>

#include "fmc.h"
#include "stm32h7xx_hal_sram.h"

#include "fpga.h"
#include "defines.h"
//#include "line.h"
//#include "cnc_task.h"
//#include "imit_fifo.h"
//
//#include "step_dir.h"

static volatile uint16_t* const BANK1_U16 = (uint16_t*)BANK1;
static volatile int16_t* const BANK1_S16 = (int16_t*)BANK1;
static volatile uint32_t* const BANK1_U32 = (uint32_t*)BANK1;
static volatile int32_t* const BANK1_S32 = (int32_t*)BANK1;
static volatile uint64_t* const BANK1_U64 = (uint64_t*)BANK1;
static volatile int64_t* const BANK1_S64 = (int64_t*)BANK1;

uint16_t fpga_read_u16(uint16_t index) { return BANK1_U16[index]; }
int16_t fpga_read_s16(uint16_t index) { return BANK1_S16[index]; }
uint32_t fpga_read_u32(uint16_t index) { return BANK1_U32[index]; }
int32_t fpga_read_s32(uint16_t index) { return BANK1_S32[index]; }
uint64_t fpga_read_u64(uint16_t index) { return BANK1_U64[index]; }
int64_t fpga_read_s64(uint16_t index) { return BANK1_S64[index]; }

uint64_t fpga_read_u48(uint16_t index) {
	uint64_t data;
	uint16_t* const p16 = (uint16_t*)&data;
	uint32_t* const p32 = (uint32_t*)&data;

	p32[0] = BANK1_U32[index<<1];
	p16[2] = BANK1_U16[(index<<2) + 2];
	p16[3] = 0;

	return data;
}

void fpga_write_u16(uint16_t index, uint16_t data) { BANK1_U16[index] = data; }
void fpga_write_s16(uint16_t index, int16_t data) { BANK1_S16[index] = data; }
void fpga_write_u32(uint16_t index, uint32_t data) { BANK1_U32[index] = data; }
void fpga_write_s32(uint16_t index, int32_t data) { BANK1_S32[index] = data; }
void fpga_write_u64(uint16_t index, uint64_t data) { BANK1_U64[index] = data; }
void fpga_write_s64(uint16_t index, int64_t data) { BANK1_S64[index] = data; }

void fpga_write_u48(uint16_t index, uint64_t data) {
	uint16_t* const p16 = (uint16_t*)&data;
	uint32_t* const p32 = (uint32_t*)&data;

	BANK1_U32[index<<1] = p32[0];
	BANK1_U16[(index<<2) + 2] = p16[2];
}

// MOTORS
void fpga_step(uint8_t i, int N, unsigned T) {
	if (i < MTR_NUM) {
		fpga_write_u32((NT32>>2) + (i << 1), N);
		fpga_write_u32((NT32>>2) + 1 + (i << 1), T);
	}
}

int32_t fpga_getN(uint8_t i) {
	uint32_t data;

	if (i < MTR_NUM) {
		data = fpga_read_u32((NT32>>2) + (i << 1));
		return *(int32_t*)&data;
	}
	return 0;
}

uint32_t fpga_getT(uint8_t i) {
	if (i < MTR_NUM) {
		return fpga_read_u32((NT32>>2) + 1 + (i << 1));
	}
	return 0;
}

void fpga_setOE(BOOL oe) { fpga_write_u16(MTR_OE>>1, oe ? 1 : 0); }
BOOL fpga_getOE() { return fpga_read_u16(MTR_OE>>1) == 1; }

uint16_t fpga_getRun() { return fpga_read_u16(MTR_WRREQ>>1); }
BOOL fpga_getStop() { return fpga_getRun() == 0; }

uint8_t fpga_getWrreq() {
	uint16_t run = fpga_getRun();
//#ifdef PRINT
//	uint16_t thld = fpga_getThld();
//	BOOL adc_ena = fpga_getAdcEnable();
//	BOOL run_ena = fpga_getRunEnable();
//	BOOL permit = fpga_getPermit();
//	printf("run=%x thld=%x adc_ena=%x run_ena=%x permit=%x\n", run, thld, adc_ena, run_ena, permit);
//#endif
	return run;
}
BOOL fpga_getWrRdy() { return fpga_getWrreq() == 0; }

BOOL fpga_isTimeout() { return (fpga_read_u16(MTR_STATUS>>1) & MTR_TIMEOUT_BIT) != 0; }

void fpga_clearTimeout() { fpga_write_u16(MTR_CONTROL>>1, MTR_TIMEOUT_BIT); }
void fpga_motorAbort() { fpga_write_u16(MTR_CONTROL>>1, MTR_ABORT_BIT); }
void fpga_motorSnapshot() { fpga_write_u16(MTR_CONTROL>>1, MTR_SNAPSHOT_BIT); }

void fpga_setTaskID(int32_t value) { fpga_write_s32(TASK_ID>>2, value); }
int32_t fpga_getTaskID() { return fpga_read_s32(TASK_ID>>2); }

void fpga_setTimeout(uint32_t value) { fpga_write_u32(TIMEOUT32>>2, value); }
uint32_t fpga_getTimeout() { return fpga_read_u32(TIMEOUT32>>2); }

void fpga_setPos(uint8_t index, int32_t value) { fpga_write_s32((POS32_DIST32>>2) + (index<<1), value); }
void fpga_setDist(uint8_t index, uint32_t value) { fpga_write_u32((POS32_DIST32>>2) + (index<<1) + 1, value); }

int32_t fpga_getPos(uint8_t index) { return fpga_read_s32((POS32_DIST32>>2) + (index<<1)); }
uint32_t fpga_getDist(uint8_t index) { return fpga_read_u32((POS32_DIST32>>2) + (index<<1) + 1); }

// Control module
uint16_t fpga_getFlags() { return fpga_read_u16(IRQ_FLAGS>>1); }
//void fpga_clearFlags(uint16_t value) { fpga_write_u16(IRQ_FLAGS>>1, value); }
void fpga_setIrqMask(uint16_t value) { fpga_write_u16(IRQ_MASK>>1, value); }
uint16_t fpga_getIrqMask() { return fpga_read_u16(IRQ_MASK>>1); }

void fpga_reset() { fpga_write_u16(FPGA_RESET>>1, 1); }

void fpga_setLimSwMask(uint16_t value) { fpga_write_u16(LIMSW_MASK>>1, value); }
uint16_t fpga_getLimSwMask() { return fpga_read_u16(LIMSW_MASK>>1); }

void fpga_setSoftAlarm() {
	fpga_write_u16(LIMSW>>1, LIM_SOFT_MSK);
//	printf("Soft alarm\n");
}
void fpga_clearSoftAlarm() {
	fpga_write_u16(LIMSW_REG>>1, LIM_SOFT_MSK);
//	printf("Clear soft alarm\n");
}


uint16_t fpga_getLimSw() { return fpga_read_u16(LIMSW>>1); }
uint16_t fpga_getLimSwReg() { return fpga_read_u16(LIMSW_REG>>1); }
void fpga_clearLimSwReg(uint16_t value) { fpga_write_u16(LIMSW_REG>>1, value); }

cnc_version_t fpga_getVersion() {
	return (cnc_version_t)fpga_read_u32(VER32>>2);
}

// ADCs
void fpga_adcSnapshop() { fpga_write_u16(ADC_SNAPSHOT>>1, 1); }

BOOL fpga_getADC(uint8_t i, uint16_t* const value) {
	if (i < ADC_NUM) {
		*value = fpga_read_u16((ADC>>1) + i);
		return *value < (1 << ADC_BITS);
	}
	*value = 0;
	return FALSE;
}

void fpga_setThld(uint16_t lim) { fpga_write_u16(ADC_THLD>>1, lim); }
uint16_t fpga_getThld() { return fpga_read_u16(ADC_THLD>>1); }
void fpga_setAdcEnable(BOOL ena) { fpga_write_u16(ADC_ENA>>1, ena ? 1 : 0); }
BOOL fpga_getAdcEnable() { return fpga_read_u16(ADC_ENA>>1) == 1; }
void fpga_setRunEnable(BOOL ena) { fpga_write_u16(RUN_ENA>>1, ena ? 1 : 0); }
BOOL fpga_getRunEnable() { return fpga_read_u16(RUN_ENA>>1) == 1; }

uint16_t fpga_getADCState() { return fpga_read_u16(PERMIT>>1); }

BOOL fpga_getPermit() { return (fpga_getADCState() & 3) == 0; }
BOOL fpga_getADCPermit() { return (fpga_getADCState() & 1) == 0; }

// High Voltage
//void setHV(uint32_t per, uint32_t t0, uint32_t t1, uint8_t code) {
//	fpga_write32(HV_PER32>>2, per);
//	fpga_write32(HV_T32_0>>2, t0);
//	fpga_write32(HV_T32_1>>2, t1);
//	fpga_write16(HV_CODE>>1, code);
//	fpga_write16(HV_UPDATE>>1, 1);
//}
//
//uint32_t getHVPeriod() { return fpga_read32(HV_PER32>>2); }
//uint32_t getHVT0() { return fpga_read32(HV_T32_0>>2); }
//uint32_t getHVT1() { return fpga_read32(HV_T32_1>>2); }
//uint8_t getHVCode() { return (uint8_t)fpga_read16(HV_CODE>>1); }

//void setHVEna(BOOL enable) { fpga_write16(HV_ENA>>1, enable ? 1 : 0); }
//BOOL getHVEna() { return fpga_read16(HV_ENA>>1) == 1; }

//////////////////////////////////

//void alt_step_valid(int str_num) {
//	ctx = str_num;
//}

#ifdef RB_TEST
static BOOL test_req = TRUE;
#endif

void roolback_ack() {
	printf("RB Start\n");
#ifdef RB_TEST
	test_req = FALSE;
#endif
}

uint32_t fpga_toTicks(double ms) {
	double res = ms * (FPGA_CLOCK / 1000);

	if (res < 0)
		res = 0;
	else if (res > INT32_MAX)
		res = INT32_MAX;

	return (uint32_t)round(res);
}

double fpga_ticksToMs(uint32_t ticks) {
	return (double)ticks * (1000.0 / FPGA_CLOCK);
}

BOOL fpga_getSpiBusy() {
	return (fpga_read_u16(SIGNAL_STATUS>>1) & 0xF) == 0;
}
void fpga_setPult(uint16_t value) { fpga_write_u16(PULT_OUT>>1, value); }
uint16_t fpga_getPult() { return fpga_read_u16(PULT_OUT>>1); }
uint16_t fpga_getPultOld() { return fpga_read_u16(PULT_OLD>>1); }

void fpga_setInputLevels(uint16_t value) { return fpga_write_u16(SIGI_LEVEL>>1, value); }
uint16_t fpga_getInputLevels() { return fpga_read_u16(SIGI_LEVEL>>1); }

uint16_t fpga_getInputs() { return fpga_read_u16(SIGI>>1); }
uint16_t fpga_getInputFlags() { return fpga_read_u16(SIGI_FLAGS>>1); }
void fpga_clearInputFlags(uint16_t value) { return fpga_write_u32(SIGI_FLAGS>>1, value); }

void fpga_setControls(uint32_t value) { fpga_write_u48(CONTROL32_OUT>>2, value); }
uint32_t fpga_getControls() { return fpga_read_u32(CONTROL32_OUT>>2); }
uint32_t fpga_getControlsOld() { return fpga_read_u32(CONTROL32_OLD>>2); }

// Encoder
void fpga_enc_clear() { fpga_write_u16(ENC_CLEAR>>1, (uint16_t)~0U); }

BOOL fpga_enc_getError() { return fpga_read_u16(ENC_STATUS>>1) != 0; }

void fpga_enc_enable() { fpga_write_u16(ENC_ENABLE>>1, (uint16_t)~0U); }
void fpga_enc_disable() { fpga_write_u16(ENC_ENABLE>>1, 0); }
uint16_t fpga_enc_isEnabled() { return fpga_read_u16(ENC_ENABLE>>1); }

void fpga_enc_setDir(uint16_t value) { fpga_write_u16(ENC_DIR>>1, value); }
uint16_t fpga_enc_getDir(uint16_t value) { return fpga_read_u16(ENC_DIR>>1); }

void fpga_enc_snapshot() { fpga_write_u16(ENC_SNAPSHOT>>1, 1); }

int32_t fpga_enc_get(size_t i) {
	switch (i) {
	case 0: return fpga_read_u32(ENC32_0>>2);
	case 1: return fpga_read_u32(ENC32_1>>2);
	}
	return 0;
}

void fpga_enc_getXY(int32_t* const x, int32_t* const y) {
	fpga_enc_snapshot();
	if (x) *x = fpga_read_u32(ENC32_0>>2);
	if (y) *y = fpga_read_u32(ENC32_1>>2);
}

void fpga_enc_set(size_t i, int32_t value) {
	uint32_t* const ptr = (uint32_t*)&value;

	fpga_enc_disable();
	switch (i) {
	case 0: fpga_write_u32(ENC32_0>>2, *ptr); break;
	case 1: fpga_write_u32(ENC32_1>>2, *ptr); break;
	}
	fpga_enc_enable();
}

void fpga_enc_setXY(int32_t x, int32_t y) {
	uint32_t* const px = (uint32_t*)&x;
	uint32_t* const py = (uint32_t*)&y;

	fpga_enc_disable();
	fpga_write_u32(ENC32_0>>2, *px);
	fpga_write_u32(ENC32_1>>2, *py);
	fpga_enc_enable();
}
