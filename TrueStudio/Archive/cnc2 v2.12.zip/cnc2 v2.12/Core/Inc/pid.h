#ifndef INC_PID_H_
#define INC_PID_H_
#include "my_types.h"

#define PID_ACC ( 1.0 * (COE_UMSEC2_TO_MMTICK2 * COE_DCODE_TO_VOLT) ) // 3 um/sec2 / V: 100V - 100 um/sec2
#define PID_DEC ( 1.0 * (COE_UMSEC2_TO_MMTICK2 * COE_DCODE_TO_VOLT) ) // 3 um/sec2 / V: 100V - 300 um/sec2

#define ADC_REF FB_VOLT_TO_ADC(80)
#define ADC_REF_LOW FB_VOLT_TO_ADC(70)

float pid(uint16_t adc, float Tnom, float dL);

void pid_setAcc(float value);
float pid_getAcc();

void pid_setDec(float value);
float pid_getDec();

void pid_setAdcRefHigh(uint16_t value);
void pid_setAdcRefLow(uint16_t value);

uint16_t pid_getAdcRefHigh();
uint16_t pid_getAdcRefLow();

void pid_clear();
void pid_reset();

#endif /* INC_PID_H_ */
