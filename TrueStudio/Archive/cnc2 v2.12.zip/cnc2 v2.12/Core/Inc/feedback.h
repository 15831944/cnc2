#ifndef SPEED_ADJ_H_
#define SPEED_ADJ_H_

#include "my_types.h"
#include "fpga.h"

//#define DIFF_GAIN (1.0 / 61.04)
#define K_DIFF (1.638 / 100)
#define V_DIOD (0.624) // V

#define V_REF (4.096) // V
#define ADC_LSB (V_REF / (1<<ADC_WIDTH))

#define FB_NOM (100) // V

#define COE_DIFF(_GAIN, _VREF, _ADC_WIDTH)			( (_VREF) / ( (_GAIN) * (1<<(_ADC_WIDTH)) ) )
#define COE_DIV(_RH, _RL, _GAIN, _VREF, _ADC_WIDTH)	( (_VREF) * ((_RH) + (_RL)) / ( (1<<(_ADC_WIDTH)) * (_RL) * (_GAIN) ) )

#define FB_PERIOD (3)

#define COE_DCODE_TO_VOLT (ADC_LSB / K_DIFF)

#define FB_VOLT_TO_ADC(VOLT) ( (VOLT * K_DIFF - V_DIOD) * (1.0 / ADC_LSB) )

void fb_reset();

void fb_enableRestore();

void fb_enableForce(BOOL value);
void fb_enable(BOOL value);

BOOL fb_isEnabledForce();
BOOL fb_isEnabled();

void fb_setLowThld(uint16_t low);
void fb_setPidThld(uint16_t high, uint16_t middle);
uint16_t fb_getLowThld();
uint16_t fb_getMiddleThld();
uint16_t fb_getHighThld();

void fb_setRollbackSpeed(float F);
float fb_getRollbackSpeed();
double fb_Trb();


float fb_getAvarageF();
void fb_clearAvarageSpeed();
double fb_T(double Tnom, uint16_t adc);
double fb_lastT(double Tnom);

uint16_t fb_getADC10mv(uint8_t i);

void fb_setRollbackTimeout(uint32_t value);
uint32_t fb_getRollbackTimeout();

uint16_t volt_to_code(double volt);

void fb_speed_task();

#endif /* SPEED_ADJ_H_ */
