#include "pid.h"

#include <math.h>
#include <float.h>
#include <stdio.h>

#include "feedback.h"
#include "moving_avg.h"
#include "defines.h"

static BOOL i_ena;
static uint16_t ref = ADC_REF;
static uint16_t ref_low = ADC_REF_LOW;
static float acc = PID_ACC, dec = PID_DEC; // mm/tick^2 / dcode
//static float gainI = PID_GAIN_I;

static float F0 = 0, F = 0; // mm / ticks
//static float I = 0;

inline static float pid_speed_range(float value) {
	return value > F_MAX ? F_MAX : value < F_MIN ? F_MIN : value;
}

void pid_setAdcRefHigh(uint16_t value) {
	ref = value;

	if (ref < ref_low)
		ref_low = ref;
}
uint16_t pid_getAdcRefHigh() { return ref; }

void pid_setAdcRefLow(uint16_t value) {
	ref_low = value;

	if (ref_low > ref)
		ref = ref_low;
}
uint16_t pid_getAdcRefLow() { return ref_low; }

void pid_stop() {
	F0 = F = 0;
	printf("F:0\n");
}

void pid_clear() {
	pid_stop();
	i_ena = FALSE;
	mavg_clear();
}

void pid_reset() {
	pid_clear();
	ref = ADC_REF;
	ref_low = ADC_REF_LOW;
	acc = PID_ACC;
	dec = PID_DEC;
//	gainI = PID_GAIN_I;
}

// um/s^2 / V
void pid_setAcc(float value) {
	acc = value * (COE_UMSEC2_TO_MMTICK2 * COE_DCODE_TO_VOLT); // mm/tick / dcode
}

// um/s^2 / V
float pid_getAcc() {
	return acc * (1.0 / (COE_UMSEC2_TO_MMTICK2 * COE_DCODE_TO_VOLT));
}

// um/s^2 / V
void pid_setDec(float value) {
	dec = value * (COE_UMSEC2_TO_MMTICK2 * COE_DCODE_TO_VOLT); // mm/tick / dcode
}

// um/s^2 / V
float pid_getDec() {
	return dec * (1.0 / (COE_UMSEC2_TO_MMTICK2 * COE_DCODE_TO_VOLT));
}

float velocity(float v0, float acc, float l) {
	static float v1_sq, v1;

	v1_sq = v0 * v0 + 2 * acc * l;
	v1 = v1_sq > 0 ? sqrt(v1_sq) : 0;
	return 0.5 * (v0 + v1);
}

int mavg_n();

float pid(uint16_t adc, float Tnom, float dL) {
	static float err, dF, Fp, Fi, Fmax, Tp, Ti, T;

	Fmax = 1.0f / Tnom;

	err = adc - ref;
	dF = err < 0 ? dec * err : acc * err;

	Fp = velocity(F0, dF, dL);

	if (i_ena && (Fp < F_MIN || Fp > Fmax)) {
		i_ena = FALSE;
		mavg_clear();

		Fp = velocity(F, dF, dL); // recalculate
	}

	if (Fp > Fmax) Fp = Fmax;
	Fp = pid_speed_range(Fp);
	Tp = 1.0f / Fp;

	Ti = mavg_get();

	if (i_ena || (mavg_ready( MS_TO_TICK(5000) ) && Ti < Tp)) {
		i_ena = TRUE;
		Fi = 1.0f / Ti;
		F = (Fi + Fp) / 2;

		if (F > Fmax) F = Fmax;
		F = pid_speed_range(F);
		T = 1.0f / F;
	}
	else {
		F = Fp;
		T = Tp;
	}

	//
	mavg_add(Tp);

	F0 = 2 * Fp - F0; // F1

	// debug
	float FF = (FPGA_CLOCK * 1000.0) * F;
	float FFp = (FPGA_CLOCK * 1000.0) * Fp;
	float FFi = (FPGA_CLOCK * 1000.0) * 1.0f / Ti;

	printf("err:%d F:%d Fp:%d Fi:%d(%x) n:%d\n", (int)err, (int)FF, (int)FFp, (int)FFi, (int)i_ena, mavg_n());

	return T;
}
