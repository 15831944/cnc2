#ifndef INC_CONTROLS_H_
#define INC_CONTROLS_H_

#include "my_types.h"

void ctrl_startButtonClick();
BOOL ctrl_startButtonClicked();

BOOL alt_bp_btn_clicked();

#endif /* INC_CONTROLS_H_ */
