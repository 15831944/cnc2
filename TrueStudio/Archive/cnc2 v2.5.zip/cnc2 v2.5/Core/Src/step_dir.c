#include "step_dir.h"

#include <stdlib.h>
#include <math.h>

#include "fpga.h"
#include "imit_fifo.h"
#include "cnc_task.h"

volatile BOOL imit_ena;

BOOL step_ready() {
#ifdef IMIT_FIFO_ENABLE
	return !imit_fifo_full() && fpga_getReady();
#else
	return fpga_getWrRdy();
#endif
}

BOOL step_isStopped() {
	uint16_t res = fpga_getRun();
	return res == 0;
}

void step_abort() { fpga_motorAbort(); }

//void step_block() { fpga_setRunEnable(FALSE); }
//void step_unblock() { fpga_setRunEnable(TRUE); }

void step_setImitEna(BOOL value) { if (!cnc_run()) imit_ena = value != 0; }
BOOL step_getImitEna() {
#ifdef IMIT_FIFO_ENABLE
	return imit_ena;
#else
	return FALSE;
#endif
}

void read_imit_fifo_task() {
#ifdef IMIT_FIFO_ENABLE
	static motor_t* m;

	if (!imit_fifo_empty()) {
		m = imit_fifo_q();
		imit_fifo_rdack();
		motor_print(m);
	}
#endif
}

// T - pause ticks, default tick - 0.1 ms
void step_writePause(uint32_t str_num, uint32_t T) {
	fpga_setTaskID(str_num);
	fpga_step(0, 0, T);
	fpga_write_u16(MTR_WRREQ>>1, 1<<0);
}

void step_writeTaskId(uint32_t str_num) {
	fpga_setTaskID(str_num);
	fpga_step(0, 0, 0);
	fpga_write_u16(MTR_WRREQ>>1, 1<<0);
}

void step_write(uint32_t str_num, BOOL frame_sync, AXIS_T axis, BOOL fin, int32_t N, uint32_t T) {
	if (!fin && N != 0)
		if (axis < MOTORS) {
			fpga_setTaskID(str_num);
			fpga_step(axis, N, T);
			fpga_write_u16(MTR_WRREQ>>1, 1<<axis);
		}

#ifdef IMIT_FIFO_ENABLE
	motor_t m;
	m.num = str_num;
	m.axis = axis;
	m.sync = frame_sync;
	m.mode = 0;
	m.last = fin;
	m.N = N;
	m.T = T;

	if (imit_ena && (N != 0 || fin)) {
#ifdef SUM_IMIT_STEPS
		static motor_t m_reg;
		static BOOL init;

		if (init) {
			if (fin) {
				m_reg.last = fin;
				imit_fifo_add(&m_reg);
				init = FALSE;
			}
			else if (m_reg.axis == axis && m_reg.num == num && m_reg.sync == frame_sync && m_reg.T == T)
				m_reg.N += N;
			else {
				imit_fifo_add(&m_reg);
				m_reg = m;
			}
		}
		else {
			m_reg = m;
			init = TRUE;
		}
#else
		imit_fifo_add(&m);
#endif
	}
#endif

//	if (axis < MOTORS)
//		motors[axis] = m;

//	if (axis == AXIS_X) {
//		pos.x += N;
//		path.x += abs(N);
//	}
//	else if (axis == AXIS_Y) {
//		pos.y += N;
//		path.y += abs(N);
//	}
}

BOOL step_write_reg(size_t index, uint32_t ts, int32_t N) {
	if (N) {
		uint32_t T = ts / abs(N);

		if (T < 2)
			T = 2;

		fpga_step(index, N, T);
		return TRUE;
	}

	return FALSE;
}

void step_write_req(uint32_t str_num) {
	fpga_setTaskID(str_num);
	fpga_write_u16(MTR_WRREQ>>1, 1);
}

void step_writeXYUV(uint32_t str_num, double ts, int32_t Nx, int32_t Ny, int32_t Nu, int32_t Nv) {
	uint8_t wrreq;

	if (Nx) {
		double T = ts / abs(Nx);
		if (T < T_MIN) T = T_MIN;
		fpga_step(0, Nx, (uint32_t)round(T));
		wrreq = 1;
	}
	else
		wrreq = 0;

	if (Ny) {
		double T = ts / abs(Ny);
		if (T < T_MIN) T = T_MIN;
		fpga_step(1, Ny, (uint32_t)round(T));
		wrreq |= 2;
	}

	if (Nu) {
		double T = ts / abs(Nu);
		if (T < T_MIN) T = T_MIN;
		fpga_step(2, Nu, (uint32_t)round(T));
		wrreq |= 4;
	}

	if (Nv) {
		double T = ts / abs(Nv);
		if (T < T_MIN) T = T_MIN;
		fpga_step(3, Nv, (uint32_t)round(T));
		wrreq |= 8;
	}

	if (wrreq) {
		fpga_setTaskID(str_num);
		fpga_write_u16(MTR_WRREQ>>1, wrreq);
	}
}

//void step_writeXY(uint32_t str_num, uint32_t ts, int32_t Nx, int32_t Ny) {
//	step_writeXYUV(str_num, ts, Nx, Ny, 0, 0);
//}

//motors_array_t* alt_step_read() { return &motors; }

// stop FPGA and set position. G92
void step_setPos(int str_num, const point_t* const pt, const point_t* const uv_pt) {
	fpga_setRunEnable(FALSE);
	fpga_setTaskID(str_num);
	fpga_setPos(0, pt->x);
	fpga_setPos(1, pt->y);
	fpga_setPos(2, uv_pt->x);
	fpga_setPos(3, uv_pt->y);
	fpga_setRunEnable(TRUE);
}

// stop FPGA and read context
context_t step_getContext() {
	context_t ctx;
	fpga_setRunEnable(FALSE);
	ctx.str_num = fpga_getTaskID();
	ctx.pt.x = fpga_getPos(0);
	ctx.pt.y = fpga_getPos(1);
	ctx.uv_pt.x = fpga_getPos(2);
	ctx.uv_pt.y = fpga_getPos(3);
	fpga_setRunEnable(TRUE);
	return ctx;
}

void step_clear() {
	fpga_setRunEnable(FALSE);

	for (int i = 0; i < 4; i++) {
		fpga_setPos(i, 0);
		fpga_setDist(i, 0);
	}

	fpga_setRunEnable(TRUE);

	fpga_enc_setXY(0, 0);
}
