#ifndef INC_FPGA_H_
#define INC_FPGA_H_

#include "my_types.h"
#include "defines.h"

#define FPGA_PERIOD (1.0 / FPGA_CLOCK) // s

#define BANK1 (0xC0000000)

#define MTR_BAR	(0)
#define ENC_BAR	(0x100)
#define CTRL_BAR (0x180)
#define ADC_BAR (0x1C0)
#define HV_BAR (0x200)

#define MTR_NUM (4)

#define NT32 (MTR_BAR)
#define MAIN_DIR (MTR_BAR + 0x40)
#define MTR_OE (MTR_BAR + 0x42)
#define TASK_ID (MTR_BAR + 0x44)
#define MTR_WRREQ (MTR_BAR + 0x48)

#define MTR_STATUS (MTR_BAR + 0x4A)
#define MTR_CONTROL (MTR_STATUS)
#define MTR_TIMEOUT_BIT (1<<0)
#define MTR_ABORT_BIT (1<<1)
#define MTR_SNAPSHOT_BIT (1<<2)

#define TIMEOUT32 (MTR_BAR + 0x4C)

#define POS32_DIST32 (MTR_BAR + 0x80)

#define ENC_NUM	(2)

#define ENC_CLEAR (ENC_BAR)
#define ENC_STATUS (ENC_BAR + 2)
#define ENC_ENABLE (ENC_BAR + 4)
#define ENC_DIR (ENC_BAR + 6)
#define ENC_SNAPSHOT (ENC_BAR + 8)

#define ENC32_Z32 (ENC_BAR + 0x10)
#define ENC32_0 (ENC_BAR + 0x10)
#define ENC_Z32_0 (ENC_BAR + 0x14)
#define ENC32_1 (ENC_BAR + 0x18)
#define ENC_Z32_1 (ENC_BAR + 0x1C)

#define IRQ_FLAGS (CTRL_BAR)
#define IRQ_MASK (CTRL_BAR + 2)
#define FLAG_LIMSW_MASK (1<<0)
#define FLAG_TIMEOUT_MASK (1<<1)

#define FPGA_RESET (CTRL_BAR + 4)

#define SIGNAL_STATUS (CTRL_BAR + 6)

#define LIMSW_MASK (CTRL_BAR + 8)
//#define LIMSW_LEVEL (CTRL_BAR + 0xA)
#define LIMSW (CTRL_BAR + 0xC)
#define LIMSW_REG (CTRL_BAR + 0xE)

//#define LIM_FWD_MSK (1<<0)
//#define LIM_REV_MSK (1<<1)

#define LIM_FWD_MSK (1<<0)
#define LIM_REV_MSK (1<<1)
#define LIM_ALARM_MSK (1<<2)
#define LIM_WIRE_MSK (1<<3)
#define LIM_POWER_OFF_MSK (1<<4)
#define LIM_SOFT_MSK (1<<5)

#define SIGI_BYTES (2)
#define CONTROL_BYTES (4)
#define PULT_BYTES (2)

#define SIGI_LEVEL (CTRL_BAR + 0x10)
#define SIGI (CTRL_BAR + 0x12)
#define SIGI_FLAGS (CTRL_BAR + 0x14)

#define SIGI_FWD_MSK (1<<0) // level
#define SIGI_REV_MSK (1<<1) // level

#define SIGI_ALARM_MSK (1<<3) // level
#define SIGI_WIRE_BREAK_MSK (1<<8) // level
#define SIGI_POWER_OFF_MSK (1<<9) // level

#define SIGI_MASK_ALL (SIGI_REV_MSK | SIGI_FWD_MSK | SIGI_ALARM_MSK | SIGI_WIRE_BREAK_MSK | SIGI_POWER_OFF_MSK)

#define CONTROL32_OUT (CTRL_BAR + 0x20)
#define CONTROL32_OLD (CTRL_BAR + 0x28)

#define PULT_OUT (CTRL_BAR + 0x30)
#define PULT_OLD (CTRL_BAR + 0x32)

#define PULT_WIRE_ENA (1<<0)

#define LED (CTRL_BAR + 0x3A)
#define VER32 (CTRL_BAR + 0x3C)

#define ADC_BITS (10)
#define ADC_NUM (6)

#define ADC_SNAPSHOT (ADC_BAR)
#define ADC (ADC_BAR)
#define ADC_THLD (ADC_BAR + 0x10)
#define ADC_ENA (ADC_BAR + 0x12)
#define RUN_ENA (ADC_BAR + 0x14)
#define PERMIT (ADC_BAR + 0x16)

#define HV_PER32 (HV_BAR)
#define HV_T32_0 (HV_BAR + 4)
#define HV_T32_1 (HV_BAR + 8)
#define HV_CODE (HV_BAR + 0xC)
#define HV_UPDATE (HV_BAR + 0xE)

#define HV_ENA (HV_BAR + 0x10)
#define HV_INV (HV_BAR + 0x12)

typedef union {
    struct {
        uint32_t rev:8;
        uint32_t ver:8;
        uint32_t fac_rev:8;
        uint32_t fac_ver:6;
        uint32_t type:2;
    } field;
    uint32_t data;
} cnc_version_t;

//
typedef struct {
	uint32_t alarm:1;
	uint32_t roolback_req:1;
} alt_status_t;

//
uint16_t fpga_read_u16(uint16_t addr);
uint32_t fpga_read_u32(uint16_t addr);

void fpga_write_u16(uint16_t addr, uint16_t data);
void fpga_write_u32(uint16_t addr, uint32_t data);

// Motors
void fpga_step(uint8_t i, int N, unsigned T);
int32_t fpga_getN(uint8_t i);
uint32_t fpga_getT(uint8_t i);

void fpga_setOE(BOOL oe);
BOOL fpga_getOE();
uint16_t fpga_getRun();
uint8_t fpga_getWrreq();
BOOL fpga_getWrRdy();
BOOL fpga_getStop();

BOOL fpga_isTimeout();
void fpga_clearTimeout();

void fpga_setTimeout(uint32_t value);
uint32_t fpga_getTimeout();

void fpga_motorSnapshot();

void fpga_setTaskID(int32_t value);
int32_t fpga_getTaskID();

void fpga_setPos(uint8_t index, int32_t value);
void fpga_setEnc(uint8_t index, int32_t value);
void fpga_setDist(uint8_t index, uint32_t value);

int32_t fpga_getPos(uint8_t index);
int32_t fpga_getEnc(uint8_t index);
uint32_t fpga_getDist(uint8_t index);

// Control module
uint16_t fpga_getFlags();
//void fpga_clearFlags(uint16_t value);
void fpga_setIrqMask(uint16_t value);
uint16_t fpga_getIrqMask();

BOOL fpga_getSpiBusy();

void fpga_setLimSwMask(uint16_t value);
uint16_t fpga_getLimSwMask();

void fpga_setSoftAlarm();
void fpga_clearSoftAlarm();

uint16_t fpga_getLimSw();
uint16_t fpga_getLimSwReg();
void fpga_clearLimSwReg(uint16_t value);

void fpga_setPult(uint16_t value);
uint16_t fpga_getPult();
uint16_t fpga_getPultOld();

void fpga_setInputLevels(uint16_t value);
uint16_t fpga_getInputLevels();

uint16_t fpga_getInputs();
uint16_t fpga_getInputFlags();
void fpga_clearInputFlags(uint16_t value);

void fpga_setControls(uint32_t value);
uint32_t fpga_getControls();
uint32_t fpga_getControlsOld();

cnc_version_t fpga_getVersion();

// ADCs
void fpga_adcSnapshop();
BOOL fpga_getADC(uint8_t i, uint16_t* const value);
void fpga_setThld(uint16_t lim);
uint16_t fpga_getThld();
void fpga_setAdcEnable(BOOL ena);
BOOL fpga_getAdcEnable();
void fpga_setRunEnable(BOOL ena);
BOOL fpga_getRunEnable();

uint16_t fpga_getADCState();
BOOL fpga_getPermit();
BOOL fpga_getADCPermit();

//
//int alt_read_ctx(point_t* const pt);
//void alt_clear();

uint32_t fpga_toTicks(double ms);
double fpga_ticksToMs(uint32_t ticks);

void fpga_reset();
void fpga_init();

void fpga_motorAbort();

// Encoder
void fpga_enc_clear();
BOOL fpga_enc_getError();

void fpga_enc_enable();
void fpga_enc_disable();
uint16_t fpga_enc_isEnabled();

void fpga_enc_setDir(uint16_t value);
uint16_t fpga_enc_getDir(uint16_t value);

void fpga_enc_snapshot();

int32_t fpga_enc_get(size_t i);
void fpga_enc_getXY(int32_t* const x, int32_t* const y);

void fpga_enc_set(size_t i, int32_t value);
void fpga_enc_setXY(int32_t x, int32_t y);

#endif /* INC_FPGA_H_ */
