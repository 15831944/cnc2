#include "cnc_func.h"
#include "defines.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <ctype.h>
#include <fpga_gpo.h>
#include <math.h>
#include <limits.h>

int32_t double_to_int32(double value) {
	value = round(value);

	if (value > (int32_t)INT32_MAX)
		return (int32_t)INT32_MAX;

	if (value < (int32_t)INT32_MIN)
		return (int32_t)INT32_MIN;

	return (int32_t)value;
}

// scale - steps / mm
double fmm_to_steps(double value, double scale) {
	return value * scale;
}

// scale - steps / mm
int32_t mm_to_steps(double value, double scale) {
	return double_to_int32( value * scale );
}

// scale - steps / mm
double fsteps_to_mm(double value, double scale) {
	return value / scale;
}

// scale - steps / mm
double steps_to_mm(int32_t value, double scale) {
	return (double)value / scale;
}

fpoint_t steps_to_fpoint_mm(const point_t* const mtr_pt, const scale_t* const scale) {
	fpoint_t res = { steps_to_mm(mtr_pt->x, scale->x), steps_to_mm(mtr_pt->y, scale->y) };
	return res;
}

point_t fpoint_mm_to_steps(const fpoint_t* const pt_mm, const scale_t* const scale) {
	point_t res = { mm_to_steps(pt_mm->x, scale->x), mm_to_steps(pt_mm->y, scale->y) };
	return res;
}

// Tick per MM
// F - mm / min
double speed_to_period(double F) {
	if (F < F_MIN_MMM || F > F_MAX_MMM) {
//		printf("T:%d (default)\n", (int)T_DEFAULT_TICK);
		return T_MIN_TICK;
	}

	double res = (FPGA_CLOCK * 60.0) / F;
//	printf("T:%d (default)\n", (int)res);
	return res; // ticks / mm
}
