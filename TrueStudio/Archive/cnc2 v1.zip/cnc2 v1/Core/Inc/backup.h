#ifndef INC_BACKUP_H_
#define INC_BACKUP_H_

#include "my_types.h"

void bkp_clearContext();
void bkp_saveContext(cnc_context_t* const ctx);
BOOL bkp_readContext(cnc_context_t* const ctx);
uint32_t bkp_readUInt32(size_t index);

void bkp_test();

#endif /* INC_BACKUP_H_ */
