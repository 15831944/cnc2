#ifndef INC_CNC_FUNC_H_
#define INC_CNC_FUNC_H_

#include "my_types.h"

double fmm_to_steps(double value, double scale);
int32_t mm_to_steps(double value, double scale);

double fsteps_to_mm(double value, double scale);
double steps_to_mm(int32_t value, double scale);

fpoint_t steps_to_fpoint_mm(const point_t* const mtr_pt, double scale_x, double scale_y);
point_t fpoint_mm_to_steps(const fpoint_t* const pt_mm, double scale_x, double scale_y);

double speed_to_period(double F);

#endif /* INC_CNC_FUNC_H_ */
