#ifndef INC_LINE_H_
#define INC_LINE_H_

#include "my_types.h"

typedef struct {
	BOOL valid;
	fpoint_t A, B;
} gline_t;

typedef struct {
//	AXIS_T lead_axis;
	BOOL valid;
	fpoint_t A, B;
	int dx, dy;
	double c;
	double k, b, k_rev, b_rev;
	double length, step;
} line_t;

void gline_clear(gline_t* const gline);

void line_clear(line_t* const line);
void line_init(line_t* const line, int32_t Ax, int32_t Ay, int32_t Bx, int32_t By, BOOL reverse, double step);
void line_set_step_ratio(line_t* const line, double base_length);
void line_swap(line_t* const line);
size_t line_setPoint(const line_t* const line, point_t* pt);
BOOL line_empty(const line_t* const line);
BOOL line_is_point(const line_t* const line);

fpoint_t line_get_point(const line_t* const line, size_t step_id, BOOL* const is_last, BOOL* const valid);
size_t line_get_pos(const line_t* const line, const fpoint_t* const pt);

double line_y(const line_t* const line, const double x);
double line_x(const line_t* const line, const double y);

//fpoint_t line_err(const line_t* const line, const point_t* const cur_pos);
//
//DIRECTION_T line_getDirX(const line_t* const line, const point_t* const pt);
//DIRECTION_T line_getDirY(const line_t* const line, const point_t* const pt);
//
//DIRECTION_T line_getMainDirX(const line_t* const line);
//DIRECTION_T line_getMainDirY(const line_t* const line);

void gline_print(const gline_t* const gline);

void line_test();

#endif /* INC_LINE_H_ */
