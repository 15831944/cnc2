#ifndef INC_KEY_TASK_H_
#define INC_KEY_TASK_H_

#include "my_types.h"

#define KEY_PERIOD (500)
#define KEY_HALF_PERIOD (KEY_PERIOD / 2)

#define KEY_NUM (5)
#define KEY_CNT_MAX (0xFF)

typedef union {
	uint8_t data;
	struct {
		uint8_t inc:1;
		uint8_t dec:1;
		uint8_t drum:1;
		uint8_t pump:1;
		uint8_t wire:1;
	} key;
} keys_t;

typedef struct {
	uint8_t cnt;
	BOOL state;
} key_counter_t;

void key_task();
void key_task_reset();

#endif /* INC_KEY_TASK_H_ */
