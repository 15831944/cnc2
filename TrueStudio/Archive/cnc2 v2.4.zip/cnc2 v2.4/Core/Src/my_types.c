#include "my_types.h"
#include <stdio.h>

#include "aux_func.h"

void point_clear(point_t* const pt) {
	memset(pt, 0, sizeof(point_t));
}

void fpoint_clear(fpoint_t* const pt) {
	memset(pt, 0, sizeof(fpoint_t));
}

void path_clear(path_t* const path) {
	memset(path, 0, sizeof(path_t));
}

void dir_clear(dir_t* const dir) {
	memset(dir, 0, sizeof(dir_t));
}

void context_clear(context_t* const ctx) {
	memset(ctx, 0, sizeof(context_t));
}

void pos_clear(pos_t* const pos) {
	memset(pos, 0, sizeof(pos_t));
}

void point_print(const point_t* const pt) {
	printf("(%d, %d)\n", (int)pt->x, (int)pt->y);
}

void fpoint_print(const fpoint_t* const pt) {
	double x = pt->x * 1000; // um
	double y = pt->y * 1000;

	decimal_t x2 = float2fix(x);
	decimal_t y2 = float2fix(y);

	printf("(%s%d.%d, %s%d.%d)\n", x2.sign ? "-" : "", x2.value, x2.rem, y2.sign ? "-" : "", y2.value, y2.rem);
}
