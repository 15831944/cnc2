#include "backup.h"
#include <stdio.h>

#include "stm32h7xx_hal.h"

#define BKP_SIZE (4 * 1024) // 4KB
static volatile uint8_t* const bkpSram = (volatile uint8_t*)D3_BKPSRAM_BASE;
static volatile uint32_t* const bkpSram_u32 = (volatile uint32_t*)D3_BKPSRAM_BASE;

void enableBkpSram() {
    /*DBP : Enable access to Backup domain */
    HAL_PWR_EnableBkUpAccess();
    /*PWREN : Enable backup domain access  */
//    __HAL_RCC_PWR_CLK_ENABLE();
    /*BRE : Enable backup regulator
      BRR : Wait for backup regulator to stabilize */
    HAL_PWREx_EnableBkUpReg();
   /*DBP : Disable access to Backup domain */
//    HAL_PWR_DisableBkUpAccess();
}

void writeBkpSram(size_t pos, uint8_t data) {
   /* Enable clock to BKPSRAM */
//  __HAL_RCC_BKPSRAM_CLK_ENABLE();
  /* Pointer write on specific location of backup SRAM */
  bkpSram[pos] = data;
 /* Disable clock to BKPSRAM */
// __HAL_RCC_BKPSRAM_CLK_DISABLE();
}

uint8_t readBkpSram(size_t index) {
   uint8_t res;

  /* Enable clock to BKPSRAM */
//  __HAL_RCC_BKPSRAM_CLK_ENABLE();
  /* Pointer write from specific location of backup SRAM */
  res =  bkpSram[index];
  /* Disable clock to BKPSRAM */
//  __HAL_RCC_BKPSRAM_CLK_DISABLE();
  return res;
}

void bkp_clear() {
//	__HAL_RCC_BKPSRAM_CLK_ENABLE();

	for (int i = 0; i < BKP_SIZE; i++)
		bkpSram[i] = 0;

//	__HAL_RCC_BKPSRAM_CLK_DISABLE();
}

void bkp_print_string(size_t pos, size_t N) {
//	__HAL_RCC_BKPSRAM_CLK_ENABLE();

	size_t end = pos + N;

	if (end > BKP_SIZE)
		end = BKP_SIZE;

	for (int i = pos; i < end && bkpSram[i] != '\0'; i++)
		printf("%c", (char)bkpSram[i]);

	printf("\n");

//	__HAL_RCC_BKPSRAM_CLK_DISABLE();
}

void bkp_print_bytes(size_t pos, size_t N) {
//	__HAL_RCC_BKPSRAM_CLK_ENABLE();

	size_t end = pos + N;

	if (end > BKP_SIZE)
		end = BKP_SIZE;

	for (int i = pos; ; ) {
		printf("%02x", (int)bkpSram[i++]);

		if (i >= end) {
			printf("\n");
			break;
		}
		else if ((i & 0xf) == 0)
			printf("\n");
		else
			printf(" ");
	}

//	__HAL_RCC_BKPSRAM_CLK_DISABLE();
}

void bkp_write_string(size_t pos, const char* str, size_t N) {
//	__HAL_RCC_BKPSRAM_CLK_ENABLE();

	size_t end = pos + N;

	if (end > BKP_SIZE)
		end = BKP_SIZE;

	for (int i = pos; i < end; i++)
		bkpSram[i] = *str++;

//	__HAL_RCC_BKPSRAM_CLK_DISABLE();
}

void bkp_clearContext() {
	for (int i = 0; i < sizeof(cnc_context_t) / sizeof(uint32_t); i++)
		bkpSram_u32[i] = 0;
}

void bkp_saveContext(cnc_context_t* const ctx) {
	ctx->field.valid = 1;

	for (int i = 0; i < CNC_CONTEX_SIZE32; i++)
		bkpSram_u32[i] = ctx->data[i];
}

BOOL bkp_readContext(cnc_context_t* const ctx) {
	for (int i = 0; i < CNC_CONTEX_SIZE32; i++)
		ctx->data[i] = bkpSram_u32[i];

	return ctx->field.valid;
}

uint32_t bkp_readUInt32(size_t index) {
	if (index >= BKP_SIZE / sizeof(uint32_t))
		index = BKP_SIZE / sizeof(uint32_t) - 1;

	return bkpSram_u32[index];
}

void bkp_test() {
	//static const char __date__[16] = __DATE__;
	static const char __time__[16] = __TIME__;
	size_t base = 0, N = 64;

	printf("Backup Test\n");

	enableBkpSram();

	printf("Read\n");
	bkp_print_string(base, N);
	bkp_print_bytes(base, N);

	printf("Clear\n");
	bkp_clear(base, N);
	bkp_print_bytes(base, N);

	printf("Write\n");
	bkp_write_string(base, __time__, sizeof(__time__));
	bkp_print_string(base, N);
	bkp_print_bytes(base, N);

	HAL_PWREx_DisableBkUpReg();
	HAL_PWR_DisableBkUpAccess();
}
