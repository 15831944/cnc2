#include <stdio.h>

#include "stm32h7xx_hal.h"

#include "defines.h"
#include "rw_ad.h"
#include "aux_func.h"
#include "prog_array.h"
#include "cnc_task.h"
#include "fpga.h"
#include "fpga_gpo.h"
#include "tx_buf.h"
#include "imit_fifo.h"
#include "step_dir.h"
#include "debug_fifo.h"
#include "backup.h"

uint32_t test_reg = 0x12345678;

void reset() {
	cnc_reset();
	test_reg = 0x12345678;
	imit_fifo_clear();
	debug_fifo_clear();
}

void ad_writeRegs(size_t addr, size_t len, const uint8_t buf[], size_t N) {
	uint32_t addr32;
	size_t len32;
	size_t pos = 5;

	size_t len_max = N - 9;
	if (len > len_max) len = len_max;

	if ((addr & ADDR_MASK) == PA_BAR) {
		pa_writeBytes(addr & ~ADDR_MASK, len, buf, N, pos);
		tx_wrack(addr, len);
	}
	else if ((addr & ADDR_MASK) == MCU_BAR && (addr & 3) == 0 && (len & 3) == 0) {
		addr32 = (addr & ~ADDR_MASK) >> 2;
		len32 = len >> 2;

		for (int i = 0; i < len32; i++, addr32++, pos += sizeof(uint32_t)) {
			uint32_t wrdata = read_u32(buf, N, pos);
			const float* const pfloat = (float*)&wrdata;
			const int32_t* const s32 = (int32_t*)&wrdata;

			switch (addr32) {
				case 0:
//					printf("W: A0 %08x\n", wrdata);
					if (wrdata & 1) cnc_runReq();

					if (wrdata & 1<<8) cnc_revReq();

					if (wrdata & 1<<16) step_setImitEna(TRUE);
					break;
				case 1:
					if (wrdata & 1) cnc_reset();
					if (wrdata & 1<<1) cnc_stopReq();

					if (wrdata & 1<<16) step_setImitEna(FALSE);
					break;

				case 0x20: gpo_setControlsEnable((uint16_t)wrdata, (uint16_t)(wrdata>>16)); break;
				case 0x21: gpo_setDrumVel(wrdata); break;
				case 0x22: gpo_setVoltageLevel(wrdata); break;
				case 0x23: gpo_setCurrentIndex(wrdata); break;
				case 0x24: gpo_setPulseWidth(wrdata); break;
				case 0x25: gpo_setPulseRatio(wrdata); break;
				case 0x26: cnc_setSpeed( (double)(*pfloat) ); break;
				case 0x27: cnc_setStep(*pfloat); break;
				case 0x28: cnc_enableUV(wrdata != 0); break;
				case 0x29: cnc_goto(wrdata); break;

				case 0x30:
					cnc_reset();
					fpga_setInputLevel(wrdata);
					printf("WR inLvl:%x\n", (unsigned)wrdata);
					break;

				case 0x40: cnc_setDirectParam(0, *s32); break;
				case 0x41: cnc_setDirectParam(1, *s32); break;
				case 0x42: cnc_setDirectParam(2, *s32); break;
				case 0x43: cnc_setDirectParam(3, *s32); break;
				case 0x44: cnc_setDirectParam(4, *s32); break;
				case 0x45: cnc_setDirectParam(5, *s32);
					cnc_reqG92();
					break;

				case 0x50: cnc_setDirectParam(0, *s32); break;
				case 0x51: cnc_setDirectParam(1, *s32); break;
				case 0x52: cnc_setDirectParam(2, *s32); break;
				case 0x53: cnc_setDirectParam(3, *s32); break;
				case 0x54: cnc_setDirectParam(4, *s32); break;
				case 0x55: cnc_setDirectParam(5, *s32); break;
				case 0x56: cnc_setDirectParam(6, *s32); break;
				case 0x57: cnc_setDirectParam(7, *s32);
					cnc_reqG1();
					break;

				case 0xFF: test_reg = wrdata; break;

//				case 0x100: if (!cnc_run()) pa_setBegin(wrdata); break;
				case 0x101: pa_setWraddr(wrdata); break;
//				case 0x102: if (!cnc_run()) pa_setRev(wrdata); break;
				default: break;
			}
		}

		if (!gpo_getValid())
			gpo_apply();

		tx_wrack(addr, len);
	}
	else if ((addr & ADDR_MASK) == FPGA_BAR && (addr & 1) == 0 && (len & 1) == 0) {
		uint32_t addr16 = (addr & ~ADDR_MASK) >> 1;
		size_t len16 = len >> 1;
		pos = 0;

		for (int i = 0; i < len16; i++, addr16++, pos += sizeof(uint16_t)) {
			uint16_t wrdata16 = read_u16(buf, N, pos);
			fpga_write_u16(addr16, wrdata16);
		}

		tx_wrack(addr, len);
	}
}

const char __date__[16] = __DATE__;
const char __time__[16] = __TIME__;

const uint32_t* __date32__ = (uint32_t*)__date__;
const uint32_t* __time32__ = (uint32_t*)__time__;

static cnc_context_t cnc_ctx;

static void readControlsIf() {
	static fpga_controls_t data32_reg;
	static fpga_lim_switch_t limsw_mask_reg;

	if (!cnc_ctx.field.valid) {
		cnc_ctx.field.valid = TRUE;

		fpga_motorSnapshot();
		fpga_enc_snapshot(); // todo: one snapshort for all

		cnc_ctx.field.state = cnc_getState();
		cnc_ctx.field.rev = cnc_isRev();
		cnc_ctx.field.uv_ena = cnc_getUVEnabled();
		cnc_ctx.field.id = fpga_getTaskID();

		cnc_ctx.field.x = fpga_getPos(0);
		cnc_ctx.field.y = fpga_getPos(1);
		cnc_ctx.field.u = fpga_getPos(2);
		cnc_ctx.field.v = fpga_getPos(3);

		cnc_ctx.field.enc_x = fpga_enc_get(0);
		cnc_ctx.field.enc_y = fpga_enc_get(1);

		data32_reg.data = fpga_getControls();
		limsw_mask_reg.data = fpga_getLimSwMask();
		BOOL hold_ena = fpga_getMotorOE();

		cnc_ctx.field.pump_ena = data32_reg.field.pump_ena;
		cnc_ctx.field.drum_state = data32_reg.field.drum_state;
		cnc_ctx.field.wire_ena = limsw_mask_reg.field.wire_ctrl;
		cnc_ctx.field.voltage_ena = data32_reg.field.voltage_ena;
		cnc_ctx.field.hold_ena = hold_ena;

		cnc_ctx.field.drum_vel = data32_reg.field.drum_vel;
		cnc_ctx.field.voltage_level = data32_reg.field.voltage_level;
		cnc_ctx.field.current_index = getCurrentIndex(data32_reg.data);

		cnc_ctx.field.pulse_width = data32_reg.field.pulse_width;
		cnc_ctx.field.pulse_ratio = data32_reg.field.pulse_ratio;

		cnc_ctx.field.T = cnc_getT();
		cnc_ctx.field.step = cnc_getStep();
	}
}

void ad_readRegs(uint32_t addr, size_t len) {
	static uint32_t rddata;
	static int32_t* const s32 = (int32_t*)&rddata;
	size_t pos = 5;

	if (len > sizeof(tx_buf) - 9) len = sizeof(tx_buf) - 9;

	if ((addr & ADDR_MASK) == PA_BAR) {
		pa_readBytes(addr & ~ADDR_MASK, len, tx_buf, sizeof(tx_buf), pos);
	}
	else if ((addr & ADDR_MASK) == MCU_BAR && (addr & 3) == 0 && (len & 3) == 0) {
		uint32_t addr32 = (addr & ~ADDR_MASK) >> 2;
		size_t len32 = len >> 2;

		for (int i = 0; i < len32; i++, addr32++, pos += sizeof(uint32_t)) {
			switch (addr32) {
				case 0: rddata = step_getImitEna()<<16 | cnc_isRev()<<8 | cnc_error()<<3 | cnc_pause()<<2 | cnc_stop()<<1 | cnc_run(); break;

				case 0x10:
					readControlsIf();
					rddata = cnc_ctx.data[0];
					break;
				case 0x11:
					readControlsIf();
					rddata = cnc_ctx.data[1];
					break;
				case 0x12:
					readControlsIf();
					rddata = cnc_ctx.data[2];
					break;
				case 0x13:
					readControlsIf();
					rddata = cnc_ctx.data[3];
					break;
				case 0x14:
					readControlsIf();
					rddata = cnc_ctx.data[4];
					break;
				case 0x15:
					readControlsIf();
					rddata = cnc_ctx.data[5];
					break;
				case 0x16:
					readControlsIf();
					rddata = cnc_ctx.data[6];
					break;
				case 0x17:
					readControlsIf();
					rddata = cnc_ctx.data[7];
					break;
				case 0x18:
					readControlsIf();
					rddata = cnc_ctx.data[8];
					break;
				case 0x19:
					readControlsIf();
					rddata = cnc_ctx.data[9];
					break;
				case 0x1A:
					readControlsIf();
					rddata = cnc_ctx.data[10];
					break;

				case 0x30:
					rddata = fpga_getInputLevel();
					printf("RD inLvl:%x\n", (unsigned)rddata);
					break;

				case 0x40: *s32 = cnc_getDirectParam(0); break;
				case 0x41: *s32 = cnc_getDirectParam(1); break;
				case 0x42: *s32 = cnc_getDirectParam(2); break;
				case 0x43: *s32 = cnc_getDirectParam(3); break;
				case 0x44: *s32 = cnc_getDirectParam(4); break;
				case 0x45: *s32 = cnc_getDirectParam(5); break;

				case 0x50: *s32 = cnc_getDirectParam(0); break;
				case 0x51: *s32 = cnc_getDirectParam(1); break;
				case 0x52: *s32 = cnc_getDirectParam(2); break;
				case 0x53: *s32 = cnc_getDirectParam(3); break;
				case 0x54: *s32 = cnc_getDirectParam(4); break;
				case 0x55: *s32 = cnc_getDirectParam(5); break;
				case 0x56: *s32 = cnc_getDirectParam(6); break;
				case 0x57: *s32 = cnc_getDirectParam(7); break;

				case 0x60: rddata = bkp_readUInt32(0); break;
				case 0x61: rddata = bkp_readUInt32(1); break;
				case 0x62: rddata = bkp_readUInt32(2); break;
				case 0x63: rddata = bkp_readUInt32(3); break;
				case 0x64: rddata = bkp_readUInt32(4); break;
				case 0x65: rddata = bkp_readUInt32(5); break;
				case 0x66: rddata = bkp_readUInt32(6); break;
				case 0x67: rddata = bkp_readUInt32(7); break;
				case 0x68: rddata = bkp_readUInt32(8); break;

				case 0xF0: rddata = __date32__[0]; break;
				case 0xF1: rddata = __date32__[1]; break;
				case 0xF2: rddata = __date32__[2]; break;
				case 0xF3: rddata = __date32__[3]; break;
				case 0xF4: rddata = __time32__[0]; break;
				case 0xF5: rddata = __time32__[1]; break;
				case 0xF6: rddata = __time32__[2]; break;
				case 0xF7: rddata = __time32__[3]; break;
				case 0xF8: rddata = SystemCoreClock; break;
				case 0xF9: rddata = VER_TYPE << 30 | FAC_VER << 24 | FAC_REV << 16 | VER << 8 | REV; break;

				case 0xFF: rddata = test_reg; break;

				case 0x100: rddata = pa_getPos(); break;
				case 0x101: rddata = pa_getWraddr(); break;
				case 0x102: rddata = PA_SIZE; break;
				case 0x103: rddata = imit_fifo_count(); break;
				case 0x104: rddata = (uint32_t)cnc_getState(); break;
				case 0x105: *s32 = pa_getStrNum(); break;

				case 0x110:
				{
					motor_t* const m = imit_fifo_q();
					m->valid = !imit_fifo_empty();
					const uint32_t* const ptr32 = (uint32_t*)m;
					rddata = ptr32[0];
				}
					break;
				case 0x111:
				{
					const motor_t* const m = imit_fifo_q();
					const uint32_t* const ptr32 = (const uint32_t*)m;
					rddata = ptr32[1];
				}
					break;
				case 0x112:
				{
					const motor_t* const m = imit_fifo_q();
					const uint32_t* const ptr32 = (const uint32_t*)m;
					rddata = ptr32[2];
					imit_fifo_rdack();
				}
					break;

				default: rddata = 0; break;
			}

			write_u32(tx_buf, sizeof(tx_buf), pos, rddata);
		}
	}
	else if ((addr & ADDR_MASK) == FPGA_BAR && (addr & 1) == 0 && (len & 1) == 0) {
		uint32_t addr16 = (addr & ~ADDR_MASK) >> 1;
		size_t len16 = len >> 1;

		for (int i = 0; i < len16; i++, addr16++, pos += sizeof(uint16_t)) {
			uint16_t rddata16 = fpga_read_u16(addr16);
			write_u16(tx_buf, sizeof(tx_buf), pos, rddata16);
		}
	}
	else
		memset(&tx_buf[pos], 0, len);

	tx_readRegsAck(addr, len);
	cnc_ctx.field.valid = FALSE;
}

void ad_readFifo(uint32_t addr, size_t len) {
	uint32_t rddata;
	if (len > sizeof(tx_buf) - 9) len = sizeof(tx_buf) - 9;

	size_t pos = 5;

	if ((addr & ADDR_MASK) == MCU_BAR && (addr & 3) == 0 && (len & 3) == 0) {
		uint32_t addr32 = (addr & ~ADDR_MASK) >> 2;
		size_t len32 = len >> 2;

		if (addr32 == 0x110) {
			size_t new_len32 = 3 * imit_fifo_count();

			if (new_len32 > len32)
				len32 = (len32 / 3) * 3; // aligned number
			else
				len32 = new_len32;

			size_t cnt = 0;

			for (int i = 0; i < len32; i++, pos += sizeof(uint32_t)) {
				motor_t* const m = imit_fifo_q();
				m->valid = !imit_fifo_empty();
				const uint32_t* const ptr32 = (uint32_t*)m;

				if (cnt > 2) cnt = 0;
				rddata = ptr32[cnt++];

				if (cnt == 3 && m->valid) imit_fifo_rdack();

				write_u32(tx_buf, sizeof(tx_buf), pos, rddata);
			}

			tx_readFifoAck(addr, len32<<2);
			return;
		}
	}

	memset(&tx_buf[pos], 0, len);
	tx_readFifoAck(addr, len);
}
