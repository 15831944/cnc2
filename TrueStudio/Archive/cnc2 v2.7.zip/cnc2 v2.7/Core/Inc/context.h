#ifndef INC_CONTEXT_H_
#define INC_CONTEXT_H_

#include "my_types.h"

cnc_context_t* cnc_ctx_get(BOOL valid_ena);
const cnc_context_t* cnc_ctx_getIf();
void cnc_ctx_clear();

#endif /* INC_CONTEXT_H_ */
