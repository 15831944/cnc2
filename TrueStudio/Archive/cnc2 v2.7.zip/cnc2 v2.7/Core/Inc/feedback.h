#ifndef SPEED_ADJ_H_
#define SPEED_ADJ_H_

#include "my_types.h"

#define DIFF_GAIN (1.0 / 61.04)

#define COE_DIFF(_GAIN, _VREF, _ADC_WIDTH)			( (_VREF) / ( (_GAIN) * (1<<(_ADC_WIDTH)) ) )
#define COE_DIV(_RH, _RL, _GAIN, _VREF, _ADC_WIDTH)	( (_VREF) * ((_RH) + (_RL)) / ( (1<<(_ADC_WIDTH)) * (_RL) * (_GAIN) ) )

void fb_reset();

void fb_storeEnable();
void fb_restoreEnable();
void fb_enable(BOOL value);
BOOL fb_isEnabled();

void fb_setThld(uint16_t low, uint16_t high);
uint16_t fb_getLowThld();
uint16_t fb_getHighThld();

void fb_setRollbackSpeed(float F);
float fb_getRollbackSpeed();

double fb_T(double Tnom, uint16_t adc);

uint16_t fb_getADC10mv(uint8_t i);

void fb_setRollbackTimeout(uint32_t value);
uint32_t fb_getRollbackTimeout();

#endif /* SPEED_ADJ_H_ */
