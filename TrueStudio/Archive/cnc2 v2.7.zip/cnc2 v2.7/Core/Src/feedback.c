#include "feedback.h"
#include "defines.h"
#include "fpga.h"
#include "cnc_func.h"
#include "math.h"

static BOOL fb_ena = FALSE, fb_ena_reg = FALSE;
static uint16_t low_thld = 0, high_thld = ADC_MAX;
static uint16_t adc_nom = 100.0 / COE_DIFF(DIFF_GAIN, ADC_VREF, ADC_WIDTH);
static double Trb = T_ROLLBACK_DEFAULT_TICK;

static const double coe[ADC_NUM] = {
	COE_DIFF(DIFF_GAIN, ADC_VREF, ADC_WIDTH),
	COE_DIFF(1.0, ADC_VREF, ADC_WIDTH), // unused
	COE_DIFF(1.0 / 111.08, 4.096, 10), // back
	COE_DIFF(1.0, 4.096, 10), // unused
	COE_DIV(1e6, 20e3, 1, 4.096, 10), // workpeice
	COE_DIV(1e6, 20e3, 1, 4.096, 10), // wire
	COE_DIV(1e6, 20e3, 1, 4.096, 10), // hv
	COE_DIFF(10, 4.096, 10) // shunt
};

inline static double range(double value) {
	return value > T_MAX_TICK ? T_MAX_TICK : value < T_MIN_TICK ? T_MIN_TICK : value;
}

void fb_reset() {
	fb_ena = fb_ena_reg = FALSE;
	fpga_setFeedbackEnable(FALSE);

	low_thld = 0;
	fpga_setLowThld(0);

	high_thld = ADC_MAX;
	fpga_setHighThld(ADC_MAX);

	adc_nom = 100.0 / COE_DIFF(DIFF_GAIN, ADC_VREF, ADC_WIDTH);
	Trb = T_ROLLBACK_DEFAULT_TICK;
}

// Feedback
void fb_storeEnable() {
	fb_ena_reg = fb_ena;
}

void fb_restoreEnable() {
	fb_ena = fb_ena_reg;
	fpga_setFeedbackEnable(fb_ena);
}

void fb_enable(BOOL value) {
	fb_ena = value;
	fpga_setFeedbackEnable(fb_ena);
}
BOOL fb_isEnabled() {
	return fb_ena = fpga_getFeedbackEnable();
}

void fb_setThld(uint16_t low, uint16_t high) {
	low_thld = low > ADC_MAX ? ADC_MAX : low;
	high_thld = high > ADC_MAX ? ADC_MAX : high;

	if (high_thld < low_thld)
		high_thld = low_thld;

	fpga_setLowThld(low_thld);
	fpga_setHighThld(high_thld);
}

uint16_t fb_getLowThld() {
	return low_thld = fpga_getLowThld();
}
uint16_t fb_getHighThld() {
	return high_thld = fpga_getHighThld();
}

void fb_setRollbackSpeed(float F) {
	Trb = speed_to_period(F);
}

float fb_getRollbackSpeed() {
	return period_to_speed(Trb);
}

double fb_T(double Tnom, uint16_t adc) {
	if (!fb_ena || adc >= adc_nom)
		return Tnom;

	if (adc <= low_thld)
		return Trb > Tnom ? Trb : Tnom;

	return range( Tnom * (adc_nom - low_thld) / (adc - low_thld) );
}

// ADC
// return: 1 bit - 10mV
uint16_t fb_getADC10mv(uint8_t i) {
	if (i < ADC_NUM) {
		uint16_t adc = fpga_getADC(i);

		if (adc <= ADC_MAX) {
			double data = round(coe[i] * adc * 100);

			if (data < UINT16_MAX)
				return (uint16_t)data;
		}
	}

	return UINT16_MAX;
}

// msec
void fb_setRollbackTimeout(uint32_t value) {
	uint32_t timeout = fpga_MsToPauseTicks(value);

	fpga_setTimeoutEnable(FALSE);

	if (timeout <= TIMEOUT_MAX) {
		fpga_setTimeout(timeout);
		fpga_setTimeoutEnable(TRUE);
	}
	else
		fpga_setTimeout(TIMEOUT_MAX);
}

// msec
uint32_t fb_getRollbackTimeout() {
	BOOL enable = fpga_getTimeoutEnable();

	if (enable)
		return (uint32_t)round( fpga_pauseTicksToMs( fpga_getTimeout() ) );
	else
		return UINT32_MAX;
}
