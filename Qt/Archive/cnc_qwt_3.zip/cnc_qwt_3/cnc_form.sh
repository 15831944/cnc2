cd /home/cnc/Work/cnc-001/Qt/Main/build-cnc_form-Desktop-Release
./cnc_form
