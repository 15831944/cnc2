#include "run_widget.h"
#include <QDebug>
#include <QList>
#include "program_param.h"
#include <cmath>
#include "aux_func.h"

using namespace std;

RunWidget::RunWidget(QWidget *parent) : QWidget(parent), plotView(QwtPlotView()) {
    createButtons();
    createTextBoxes();
    createState();

//    setFontPointSize(14);

    gridMain = new QGridLayout;
//    gridMain->addWidget(plotView.give(), 0, 0, Qt::AlignLeft | Qt::AlignTop);
    gridMain->addWidget(plotView.give(), 0, 0);
    gridMain->addLayout(gridState, 0, 1, Qt::AlignRight | Qt::AlignTop);
    gridMain->addLayout(gridText, 1, 0);
    gridMain->addLayout(gridButton, 1, 1, Qt::AlignRight | Qt::AlignTop);

    this->setLayout(gridMain);

    qDebug() << "RunWidget constractor: " << size();
}

void RunWidget::createButtons() {
    btnStart = new QPushButton;
    btnReverse = new QPushButton;
    btnCancel = new QPushButton;

    setButtonsEnabled(1, 0, 0);
    setButtonsText({tr("Start"), tr("Reverse"), tr("Cancel")});

    btnHold = new QPushButton;
    btnHold->setText(tr("Hold"));
    btnHold->setCheckable(true);

    labelSpeed = new QLabel(tr("Speed:"));

    numSpeed = new QDoubleSpinBox;
    numSpeed->setRange(0, 100);
    numSpeed->setSingleStep(0.1);

    speedMMM = new QRadioButton(tr("mm/min"));
    speedUMS = new QRadioButton(tr("um/sec"));

    groupSpeed = new QGroupBox;
    groupSpeed->setLayout(new QHBoxLayout);
    groupSpeed->layout()->addWidget(speedMMM);
    groupSpeed->layout()->addWidget(speedUMS);

    groupSpeed->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    speedMMM->click();

    gridButton = new QGridLayout;
    gridButton->addWidget(btnStart, 0, 0, 1, 2);
    gridButton->addWidget(btnReverse, 1, 0);
    gridButton->addWidget(btnCancel, 1, 1);
    gridButton->addWidget(btnHold, 2, 0, 1, 2);
    gridButton->addWidget(labelSpeed, 3, 0);
    gridButton->addWidget(numSpeed, 3, 1);
    gridButton->addWidget(groupSpeed, 4, 0, 1, 2);

    //
    buttons = {btnStart, btnReverse, btnCancel, btnHold};
    labels = {labelSpeed};
    nums = {numSpeed};
    radio = {speedMMM, speedUMS};
}

void RunWidget::createTextBoxes() {
    txtCode = new CodeEditor;
    txtCode->setReadOnly(true);

    int h = txtCode->fontMetrics().lineSpacing();
    h *= 5;
//    h += txtCode->fontMetrics().leading();

    QTextDocument* pdoc = txtCode->document();
    QMargins margins = txtCode->contentsMargins();
    h += static_cast<int>(pdoc->documentMargin()) + margins.top() + margins.bottom();

    txtCode->setFixedHeight(h);

    txtMsg = new QTextEdit;
    txtMsg->setReadOnly(true);

    txtMsg->setFixedHeight(h);

    gridText = new QGridLayout;
    gridText->addWidget(txtCode, 0, 0);
    gridText->addWidget(txtMsg, 0, 1);
}

void RunWidget::createState() {
    gridState = new QGridLayout;

    labelX = new QLabel(R"(<font color=blue>X</font>)");
    labelY = new QLabel(R"(<font color=blue>Y</font>)");
    labelU = new QLabel(R"(<font color=blue>U</font>)");
    labelV = new QLabel(R"(<font color=blue>V</font>)");
    labelTime = new QLabel(R"(<font color=blue>)" + tr("Time") + R"(</font>)");
    labelETA = new QLabel(R"(<font color=blue>)" + tr("Remain") + R"(</font>)");

    posLabels = {new QLabel, new QLabel, new QLabel, new QLabel, new QLabel, new QLabel, labelX, labelY, labelU, labelV, labelTime, labelETA};

    for (size_t i = 0; i < posLabels.size(); i++) {
        if (i < ProgramParam::AXES_NUM)
            setPositionLabels(i, 0);
    }
    setElapsedTime(0, 0, 0);
    setEstimatedTime(0, 0, 0);

    gridState->addWidget(labelX, 0, 0);
    gridState->addWidget(posLabels[0], 0, 1, Qt::AlignRight);

    gridState->addWidget(labelY, 1, 0);
    gridState->addWidget(posLabels[1], 1, 1, Qt::AlignRight);

    gridState->addWidget(labelU, 2, 0);
    gridState->addWidget(posLabels[2], 2, 1, Qt::AlignRight);

    gridState->addWidget(labelV, 3, 0);
    gridState->addWidget(posLabels[3], 3, 1, Qt::AlignRight);

    gridState->addWidget(labelTime, 4, 0);
    gridState->addWidget(posLabels[4], 4, 1, Qt::AlignRight);

    gridState->addWidget(labelETA, 5, 0);
    gridState->addWidget(posLabels[5], 5, 1, Qt::AlignRight);

    gridState->setSizeConstraint(QLayout::SetFixedSize);
}

RunWidget::~RunWidget() {}

void RunWidget::setButtonsEnabled(bool start_ena, bool reverse_ena, bool cancel_ena) {
    btnStart->setEnabled(start_ena);
    btnReverse->setEnabled(reverse_ena);
    btnCancel->setEnabled(cancel_ena);
}

void RunWidget::setButtonsText(const QString (&text)[3]) {
    if (text[0].length() != 0) btnStart->setText(text[0]);
    if (text[1].length() != 0) btnReverse->setText(text[1]);
    if (text[2].length() != 0) btnCancel->setText(text[2]);
}

void RunWidget::setPositionLabels(size_t axis_num, int value) {
    if (axis_num < ProgramParam::AXES_NUM) {        
        bool sign = value < 0;
        value = std::abs(value);

        double scale = 1;
        switch (axis_num) {
            case 0: scale = X_SCALE; break;
            case 1: scale = Y_SCALE; break;
            case 2: scale = U_SCALE; break;
            case 3: scale = V_SCALE; break;
        }

        uint32_t value_um = static_cast<uint32_t>( std::round(double(value) / scale * 1e3) );
        QString s = QString::asprintf("%c%04d.%03d", sign ? '-' : ' ', value_um / 1000, value_um % 1000);
        posLabels[axis_num]->setText(R"(<font color=red>)" + s + R"(</font>)");
    }
}

void RunWidget::setElapsedTime(int h, int m, int s) {
    QString str = QString::asprintf("%02d:%02d:%02d", h, m, s);
    posLabels[4]->setText(R"(<font color=red>)" + str + R"(</font>)");
//    qDebug("%s\n", str.toStdString().c_str());
}

void RunWidget::setElapsedTime(qint64 ms) {
    using namespace aux_func;
    HMS hms(ms);
    setElapsedTime(int(hms.h), int(hms.m), int(hms.s));
//    qDebug("%d ms\n", int(ms));
}

void RunWidget::setEstimatedTime(int h, int m, int s) {
    QString str = QString::asprintf("%02d:%02d:%02d", h, m, s);
    posLabels[5]->setText(R"(<font color=red>)" + str + R"(</font>)");
}

void RunWidget::setEstimatedTime(qint64 ms) {
    using namespace aux_func;
    HMS hms(ms);
    setEstimatedTime(int(hms.h), int(hms.m), int(hms.s));
}

void RunWidget::setFontPointSize(int pointSize) {
    for (QPushButton* o: buttons) {
        QFont font = o->font();
        font.setPointSize(pointSize);
        o->setFont(font);
    //        o->setStyleSheet("font: bold");
    }

    for (QLabel* o: labels) {
        QFont font = o->font();
        font.setPointSize(pointSize);
        o->setFont(font);
    }

    for (QDoubleSpinBox* o: nums) {
        QFont font = o->font();
        font.setPointSize(pointSize);
        o->setFont(font);
    }

    for (QRadioButton* o: radio) {
        QFont font = o->font();
        font.setPointSize(static_cast<int>( round(pointSize * 0.8) ));
        o->setFont(font);
    }

    for (size_t i = 0; i < posLabels.size(); i++) {
        QLabel*& label = posLabels[i];

        label->setSizePolicy( QSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum) );
        QFont font = label->font();
        font.setPointSize(pointSize * 2);
        font.setBold(true);
        label->setFont(font);
    }
}

//void RunWidget::setETA(int value) {
////        bool sign = value < 0;
////        value = std::abs(value);
////        uint32_t value_um = static_cast<uint32_t>( std::round(double(value) / CNC_SCALE * 1e3) );
////        QString s = QString::asprintf("%c%04d.%03d", sign ? '-' : ' ', value_um / 1000, value_um % 1000);
////        posLabels[axis_num]->setText(R"(<font color=red>)" + s + R"(</font>)");
//}

void RunWidget::plot(const ContourList& contourList) {
    plotView.plot(contourList);
}

QSize RunWidget::plotViewSize() const {
    return plotViewSize(size());
}

QSize RunWidget::plotViewSize(const QSize& formSize) const {
    int codeHeight = gridText->sizeHint().height();
    int stateWidth = gridState->sizeHint().width();

    int w = formSize.width() - stateWidth;
    int h = formSize.height() - codeHeight;

    QSize res(w, h);

    qDebug() << "Widget size: " << size() << ", plot size:" << res << ", msg height: " << codeHeight << ", state width: " << stateWidth;

    return res;
}

void RunWidget::resizeEvent(QResizeEvent* event) {
    if (!plotView.onResizeEvent( plotViewSize(event->size()) ))
        event->ignore();
}
