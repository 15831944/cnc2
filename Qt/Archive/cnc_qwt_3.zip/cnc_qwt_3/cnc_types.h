#ifndef CNC_TYPES_H
#define CNC_TYPES_H

#include <cstdint>
#include <vector>
#include <QObject>

enum class TAB_MODE : uint8_t { TAB_NONE, TAB_SINGLE, TAB_MULTI };
enum class OFFSET_SIDE : bool { LEFT, RIGHT };

OFFSET_SIDE operator~(const OFFSET_SIDE& side);

struct GeneratorMode {
    float drum_velocity, pulse_width, pulse_ratio, voltage_level, current_index;

    GeneratorMode(float drumVelocity = 7, float pulseWidth = 36, float pulseRatio = 8, float voltageLevel = 0, float currentIndex = 7) :
        drum_velocity(drumVelocity), pulse_width(pulseWidth), pulse_ratio(pulseRatio), voltage_level(voltageLevel), current_index(currentIndex) {}
};

struct offset_t {
    uint8_t mode_id;
    double offset;

    offset_t(uint8_t mode_id = 0, double offset = 0) : mode_id(mode_id), offset(offset)  {}
};

struct cut_t {
    constexpr static const uint32_t MAX_TIMES = 7;

    uint8_t times;
    uint8_t cutline_mode_id;
    OFFSET_SIDE offset_side;
    bool tab_multi_pass, tab_pause;
    uint16_t pump_delay; // sec
    bool pump_pause;
    double tab, overlap;

    std::vector<offset_t> offsets;
    offset_t tab_offset;    
//    offset_t overlap_offset;
//    offset_t out_offset;

    cut_t() :
        times(1),
        cutline_mode_id(0),
        offset_side(OFFSET_SIDE::LEFT),
        tab_multi_pass(true),
        tab_pause(true),
        pump_delay(60),
        pump_pause(true),
        tab(0),
        overlap(0),
        tab_offset(offset_t())
//        overlap_offset(offset_t()),
//        out_offset(offset_t())
    {
        offsets.resize(MAX_TIMES);
    }

    uint8_t getTimes() const;
    std::vector<offset_t> getOffsets() const;
    std::vector<offset_t> getTabOffsets() const;
    offset_t getOverlapOffset() const;
    offset_t getOutOffset() const;
};

#endif // CNC_TYPES_H
