#ifndef AUX_FUNC_H
#define AUX_FUNC_H

#include <cstdint>
#include <vector>
#include <list>
#include <string>

#include <memory>
#include <cstdio>
#include <cstdlib>

#include <cstdarg>
//#include <cstring>

#include <iostream>
#include <sstream>

#include <QTextEdit>

namespace aux_func {
    void byte_reverse(uint32_t& data);
    void swap(uint8_t& a, uint8_t& b);

    void print_vector(const std::vector<uint8_t>& bytes);
    void print_strings(const std::list<std::string>& ss);

    void push_back_range(std::vector<uint8_t>& v, const std::vector<uint8_t>& src, const size_t& src_begin, const size_t& src_length);
    void push_back_range(std::vector<uint8_t>& v, const std::string& s);
    void push_back_range(std::vector<uint8_t>& v, const int32_t& value);

    std::string string_format(const char *format, ...);
//    template<typename ... Args> std::string string_format(const std::string& format, Args ... args) {
//        size_t size = snprintf( nullptr, 0, format.c_str(), args ... ) + 1; // Extra space for '\0'
//        std::unique_ptr<char[]> buf( new char[ size ] );
//        snprintf( buf.get(), size, format.c_str(), args ... );
//        return std::string( buf.get(), buf.get() + size - 1 ); // We don't want the '\0' inside
//    }

    uint32_t crc32(const uint8_t buf[], size_t len);

    bool vector_compare(const std::vector<uint8_t>& a, const std::vector<uint8_t>& b);
    std::vector<uint8_t> gen_rnd(size_t size);

    class BitConverter {
    public:
        static uint32_t toUInt32Rev(const std::vector<uint8_t>& v, size_t pos);
        static uint16_t toUInt16(const std::vector<uint8_t>& v, size_t pos);
        static uint32_t toUInt32(const std::vector<uint8_t>& v, size_t pos);
        static int32_t toInt32(const std::vector<uint8_t>& v, size_t pos);
        static float toFloat(const std::vector<uint8_t>& v, size_t pos);
        static uint64_t toUInt48(const std::vector<uint8_t>& v, size_t pos);
        static uint64_t toUInt64(const std::vector<uint8_t>& v, size_t pos);
    };

    std::string toString(const bool& value) noexcept;

    template<typename T> std::string toHex(const T& value) {
        const size_t BUF_SIZE = 64;
        std::string res;

        char* buf = new char[BUF_SIZE];

        if (buf) {
            int n = snprintf(buf, BUF_SIZE, "%X", value);
            if (n > 0) res = std::string(buf, BUF_SIZE);
            delete[] buf;
        }
        return res;
    }

    class MyException {
        std::ostringstream stream;
    public:
        MyException(std::string s = std::string()) { stream << s; }
        MyException(MyException& other) {
            stream<<other.toString();
        }
        std::ostringstream& Stream() { return stream; }
        std::string toString() { return stream.str(); }
    };

    class ReportWriter {
        QTextEdit* txt;
    public:
        ReportWriter(QTextEdit* const txt = nullptr);
        ReportWriter(const ReportWriter& other);

        ReportWriter& operator=(const ReportWriter& other);

        inline void removeTextEdit() { txt = nullptr; }
        void clear();
        void write(const QString& s);
        void write(const char* s);
        void write(const std::string s);
    };

    void print_strings(ReportWriter* const txt, const std::list<std::string>& ss);

    class HMS {
    public:
        uint8_t m, s;
        int32_t h;

        HMS() : m(0), s(0), h(0) {}
        HMS(qint64 ms) {
            fromMS(ms);
        }

        void fromMS(qint64 ms) {
            if (ms < 0)
                ms = 0;

            qint64 h = ms / (1000 * 60 * 60);
            ms -= h * (60 * 60 * 1000);

            qint64 m = ms / (1000 * 60);
            ms -= m * (60 * 1000);

            qint64 s = ms / 1000;
            ms -= s * 1000;
            if (ms >= 500)
                s++;

            if (h > INT32_MAX)
                h = INT32_MAX;

            this->h = int32_t(h);
            this->m = uint8_t(m);
            this->s = uint8_t(s);
        }
    };
}

#endif // AUX_FUNC_H
