#include "form_contour.h"

#include <QFileDialog>
//#include <QSizePolicy>
#include <QLineEdit>
#include <QHeaderView>

#include <new_cutline_dialog.h>
#include "contour_pass.h"

using namespace std;
//using namespace QtCharts;

FormContour::FormContour(ProgramParam& par, QWidget *parent) :
    QWidget(parent),
    par(par), plotView(QwtPlotView()),
    m_contour_num(0), m_row(0), m_column(0)
{
    createButtons();

    txtMsg = new QTextEdit();
    txtMsg->setReadOnly(true);

//    QSizePolicy spMsg(QSizePolicy::Maximum, QSizePolicy::Maximum);
//    spMsg.setHeightForWidth(true);
//    txtMsg->setSizePolicy(spMsg);

    createGridView();

    buttons = {btnHome, btnPasses, btnOpen, btnSave, btnSaveAs, btnBot, btnTop, btnGenerate,
               btn8, btn9, btn10, btn11, btn12, btnHelp, btnNewContour, btnNewCutline,
               btnDelete, btnClear, btnBegin, btnChangeDir, btnEdit
              };

    setFontPointSize(14);

    gridPlot = new QGridLayout();
    gridPlot->addLayout(gridView, 0, 0);
//    gridPlot->addWidget(plotView.give(), 0, 1, Qt::AlignLeft | Qt::AlignBottom);
    gridPlot->addWidget(plotView.give(), 0, 1);
    gridPlot->addWidget(txtMsg, 1, 0, 1, 2);

    m_plot_view_pct = (14.0 - 5) / 14;

    gridPlot->setColumnStretch(0, 5);
    gridPlot->setColumnStretch(1, 14 - 5);

    gridPlot->setRowStretch(0, 9);
    gridPlot->setRowStretch(1, 1);

    mainLayout = new QVBoxLayout;
    mainLayout->addLayout(gridPlot);
    mainLayout->addLayout(gridButtons);

    this->setLayout(mainLayout);
}

void FormContour::createButtons() {
    btnHome = new QPushButton(tr("Home"));

    btnOpen = new QPushButton(tr("Open"));
    btnOpen->setEnabled(false);

    btnSave = new QPushButton(tr("Save"));
    btnSave->setEnabled(false);

    btnSaveAs = new QPushButton(tr("Save as"));
    btnSaveAs->setEnabled(false);

    btnBot = new QPushButton(tr("Load BOT"));

    btnTop = new QPushButton(tr("Load TOP"));
    btnTop->setEnabled(false);

    btnPasses = new QPushButton(tr("Passes"));

    btnGenerate = new QPushButton(tr("Generate"));

    btn8 = new QPushButton;
    btn8->setEnabled(false);

    btn9 = new QPushButton;
    btn9->setEnabled(false);

    btn10 = new QPushButton;
    btn10->setEnabled(false);

    btn11 = new QPushButton;
    btn11->setEnabled(false);

    btn12 = new QPushButton;
    btn12->setEnabled(false);

    btnHelp = new QPushButton(tr("Help"));

    gridButtons = new QGridLayout();

    gridButtons->addWidget(btnHome, 0, 0);    
    gridButtons->addWidget(btnOpen, 0, 1);
    gridButtons->addWidget(btnSave, 0, 2);
    gridButtons->addWidget(btnSaveAs, 0, 3);
    gridButtons->addWidget(btnBot, 0, 4);
    gridButtons->addWidget(btnTop, 0, 5);
    gridButtons->addWidget(btnPasses, 0, 6);
    gridButtons->addWidget(btnGenerate, 0, 7);
    gridButtons->addWidget(btn8, 0, 8);
    gridButtons->addWidget(btn9, 0, 9);
    gridButtons->addWidget(btn10, 0, 10);
    gridButtons->addWidget(btn11, 0, 11);
    gridButtons->addWidget(btn12, 0, 12);

    gridButtons->addWidget(btnHelp, 0, 13);

    connect(btnHome, &QPushButton::clicked, [&]() { emit homePageClicked(); });    
    connect(btnBot, &QPushButton::clicked, this, &FormContour::on_btnBot_clicked);

    connect(btnPasses, &QPushButton::clicked, [&]() { emit passesPageClicked(); });
    connect(btnGenerate, &QPushButton::clicked, this, &FormContour::onGenerate);
    connect(btnHelp, &QPushButton::clicked, this, [&](){ emit helpPageClicked(help_file); });
}

void FormContour::createGridView() {
    gridView = new QGridLayout;

    lineContour = new QLineEdit;
    lineContours = new QLineEdit;

    viewContours = new QTableView;
    viewContour = new QTableView;

    ContourTableModel* model = new ContourTableModel();

    viewContours->setModel(new ContoursModel());
    viewContours->horizontalHeader()->hide();

    viewContour->setModel(model);

    groupContours = new QGroupBox(tr("Contours"));
    groupContour = new QGroupBox(tr("Current"));

    groupContours->setLayout(new QVBoxLayout());
    groupContours->layout()->addWidget(lineContours);
    groupContours->layout()->addWidget(viewContours);

    groupContour->setLayout(new QVBoxLayout());
    groupContour->layout()->addWidget(lineContour);
    groupContour->layout()->addWidget(viewContour);

    createViewControl();

    gridView->addWidget(groupContours, 0, 0);
    gridView->addWidget(groupContour, 0, 1);
    gridView->addLayout(vLayoutLeft, 1, 0, Qt::AlignLeft | Qt::AlignTop);
    gridView->addLayout(vLayoutRight, 1, 1, Qt::AlignLeft | Qt::AlignTop);

    gridView->setColumnStretch(0, 1);
    gridView->setColumnStretch(1, 2);

    viewContours->show();
    viewContour->show();

    connect(viewContours, SIGNAL(clicked(const QModelIndex&)), this, SLOT(onViewContoursClicked(const QModelIndex&)));
    connect(viewContour, SIGNAL(clicked(const QModelIndex&)), this, SLOT(onViewContourClicked(const QModelIndex&)));    
}

void FormContour::createViewControl() {
    vLayoutLeft = new QVBoxLayout();

    btnNewContour = new QPushButton(tr("New Contour"));
    btnNewContour->setEnabled(false);
    btnNewCutline = new QPushButton(tr("New Cutline"));
    btnDelete = new QPushButton(tr("Delete"));
    btnClear = new QPushButton(tr("Clear"));

    vLayoutLeft->addWidget(btnNewContour);
    vLayoutLeft->addWidget(btnNewCutline);
    vLayoutLeft->addWidget(btnDelete);
    vLayoutLeft->addWidget(btnClear);
    vLayoutLeft->setSizeConstraint(QLayout::SetFixedSize);

    vLayoutRight = new QVBoxLayout();

    btnBegin = new QPushButton(tr("Top"));
    btnChangeDir = new QPushButton(tr("Change direction"));

    btnEdit = new QPushButton();
    btnEdit->setText(tr("Edit"));

    menuEdit = new QMenu;

    actCutline = new QAction(tr("Use as Cutline"));
    actExitPoint = new QAction(tr("Set as exit point"));
    actExitPoint->setEnabled(false);

    menuEdit->addAction(actCutline);
    menuEdit->addAction(actExitPoint);

    btnEdit->setMenu(menuEdit);

    vLayoutRight->addWidget(btnBegin);
    vLayoutRight->addWidget(btnChangeDir);
    vLayoutRight->addWidget(btnEdit);

    connect(btnNewContour, &QPushButton::clicked, this, &FormContour::on_btnNewContour_clicked);
    connect(btnNewCutline, &QPushButton::clicked, this, &FormContour::on_btnNewCutline_clicked);
    connect(btnDelete, &QPushButton::clicked, this, &FormContour::on_btnDelete_clicked);
    connect(btnClear, &QPushButton::clicked, this, &FormContour::on_btnClear_clicked);

    connect(btnBegin, &QPushButton::clicked, this, &FormContour::onBeginClicked);
    connect(btnChangeDir, &QPushButton::clicked, this, &FormContour::on_btnReverse_clicked);

    connect(actCutline, &QAction::triggered, this, &FormContour::on_actCutline_triggered);
    connect(actExitPoint, &QAction::triggered, this, &FormContour::on_actExitPoint_triggered);
}

FormContour::~FormContour() {}

void FormContour::setFontPointSize(int pointSize) {
    for (QPushButton* b: buttons) {
        QFont font = b->font();
        font.setPointSize(pointSize);
        b->setFont(font);
    }
}

void FormContour::init() {
    if (m_contour_num >= par.contours.count()) m_contour_num = 0;
    m_row = 0;
    m_column = 0;

    plot();
    initView();
}

void FormContour::on_btnBot_clicked() {
    if (openDxfFileDialog(par.fileDir, par.contourFileName)) {
        Dxf bot;
        bot.init(par.fileDir.toStdString(), par.contourFileName.toStdString());

        if (bot.parse()) {
            txtMsg->setText("Parse bottom layer complete successfully\n");

            if (!bot.sort())
                txtMsg->setText(txtMsg->toPlainText() + "Sort error: " + bot.error().c_str() + "\n");

            par.contours.new_back();
            par.contours.back()->setBot(bot);

            init();            
        }
        else {
            txtMsg->setText("Parse bottom layer error: " + QString(bot.error().c_str()));
            plot(bot);
        }
    }
}

void FormContour::on_btnTop_clicked() {

}

void FormContour::on_btnSimple_clicked() {

}

void FormContour::on_btnNewContour_clicked() {
    par.contours.new_back();
    initView();
}

void FormContour::on_btnNewCutline_clicked() {
    if (!par.contours.empty()) {
        const ContourPair* pair = par.contours.at(m_contour_num);
        const fvalid_point_t entry_pt = pair ? pair->bot().first_point() : fvalid_point_t(false);

        if (pair->type() == CONTOUR_TYPE::CONTOUR_MAIN && entry_pt.valid) {
            bool insert_before = m_contour_num == 0 || par.contours.at(m_contour_num - 1)->type() == CONTOUR_TYPE::CONTOUR_MAIN;

            const fvalid_point_t exit_pt = pair->bot().last_point();
            bool insert_after = !insert_before && exit_pt.valid;

            if (insert_before || insert_after) {
                NewCutlineDialog* dialog = new NewCutlineDialog(this);

                if (insert_before) {
                    dialog->set(0, entry_pt.x, 0, entry_pt.y);
                    dialog->enable(0x5);
                }
                else if (insert_after) {
                    dialog->set(exit_pt.x, 0, exit_pt.y, 0);
                    dialog->enable(0xA);
                }

                dialog->exec();

                if (dialog->result() == QDialog::Accepted) {
                    double x0, x1, y0, y1;
                    dialog->get(x0, x1, y0, y1);

                    DxfLine line;
                    if (dialog->isRel()) {
                        if (insert_after) {
                            line.setX0(entry_pt.x);
                            line.setX1(entry_pt.x + x1);
                            line.setY0(entry_pt.y);
                            line.setY1(entry_pt.y + y1);
                        }
                        else { // before
                            line.setX0(entry_pt.x + x0);
                            line.setX1(entry_pt.x);
                            line.setY0(entry_pt.y + y0);
                            line.setY1(entry_pt.y);
                        }
                    }
                    else {
                        line.setX0(x0);
                        line.setX1(x1);
                        line.setY0(y0);
                        line.setY1(y1);
                    }

                    qDebug() << "Dialog OK";

                    ContourPair new_pair(CONTOUR_TYPE::CONTOUR_CUTLINE);
                    new_pair.bot().push_back(line);

                    if (insert_before)
                        par.contours.insert(m_contour_num, new_pair);
                    else {
                        par.contours.insert_after(m_contour_num, new_pair);
                        m_contour_num++;
                    }

                    init();

                    viewContours->selectRow(int(m_contour_num));
                    viewContour->selectRow(0);
                    par.contours.select(m_contour_num, 0, 0);
                    plot();
                }

                delete dialog;
            }
        }
    }
}

void FormContour::on_btnDelete_clicked() {
    par.contours.remove(m_contour_num);
    init();
}

void FormContour::on_btnClear_clicked() {
    qDebug() << "Clear all contours:";
    qDebug() << par.contours.toString().c_str();

    setEmptyModel();

    par.contours.clear();

    qDebug() << par.contours.toString().c_str();

    init();
}

void FormContour::on_btnReverse_clicked() {
    if (m_contour_num < par.contours.count()) {
        par.contours.at(m_contour_num)->reverse();
        par.contours.clearSelected();
        init();

        viewContour->selectRow(0);
        par.contours.select(m_contour_num, 0, 0);
        plot();
    }
}

void FormContour::onBeginClicked() {
    if (m_contour_num < par.contours.count()) {
        ContourPair* pair = par.contours.at(m_contour_num);
        qDebug() << pair->toStringShort().c_str();
        pair->setFirst(m_column, m_row);
        qDebug() << pair->toStringShort().c_str();
        init();

        viewContours->selectRow(int(m_contour_num));
        viewContour->selectRow(0);
    }
}

void FormContour::onViewContoursClicked(const QModelIndex &index) {
    if (index.isValid()) {
        m_contour_num = index.row() < 0 ? 0 : size_t(index.row());
        if (m_contour_num >= par.contours.count()) m_contour_num = par.contours.count() - 1;

        initContourView();

        const ContourPair* pair = par.contours.at(m_contour_num);

        if (pair && !pair->empty())
            if (pair->type() == CONTOUR_TYPE::CONTOUR_MAIN)
                lineContours->setText(QString("%1 Contour (%2)").arg(m_contour_num + 1).arg(pair->count()));
            else
                lineContours->setText(QString("%1 Cutline (%2)").arg(m_contour_num + 1).arg(pair->count()));
        else
            lineContours->clear();

        txtMsg->setText(par.contours.toString().c_str());

//        viewContours->selectRow(int(m_contour_num));
        viewContour->selectRow(0);
        par.contours.select(m_contour_num, 0, 0);
        plot();
    }
}

void FormContour::onViewContourClicked(const QModelIndex& index) {
    if (index.isValid()) {
        m_row = index.row() < 0 ? 0 : size_t(index.row());
        m_column = index.column() < 0 ? 0 : size_t(index.column());

        const Dxf* const bot = par.contours.at(m_contour_num) ? &par.contours.at(m_contour_num)->bot() : nullptr;

        switch (m_column) {
        case 0:
            if (m_row < bot->count()) {
                lineContour->setText(QString("%1 Line XY").arg(m_row + 1));
                txtMsg->setText(bot->at(m_row)->toString().c_str());
                par.contours.select(m_contour_num, m_row, m_column);
                plot();
            }

            break;
        case 1:

            break;
        }
    }
}

// only for single contour
void FormContour::on_actCutline_triggered() {
//    if (m_contour_num == 0 && m_contour_num < par.contours.count()) {
    if (par.contours.count() == 1) {
        ContourPair incut(CONTOUR_TYPE::CONTOUR_CUTLINE);
        const ContourPair* const pair = par.contours.front();
//        ContourPair* pair = par.contours.at(m_contour_num);

        if (pair && !pair->empty()) {
            if (!pair->emptyBot() && !pair->bot().isLoop()) {
                if (m_row == 0)
                    incut.setBot( Dxf(pair->bot().cut_front()) );
                else if (m_row == pair->countBot() - 1) {
                    incut.setBot( Dxf(pair->bot().cut_back()) );
                    incut.bot().reverse();
                }
            }

            if (!pair->emptyTop() && !pair->top().isLoop()) {
                if (m_row == 0)
                    incut.setTop( Dxf(pair->top().cut_front()) );
                else if (m_row == pair->countTop() - 1) {
                    incut.setTop( Dxf(pair->top().cut_back()) );
                    incut.top().reverse();
                }
            }

            if (!incut.emptyBot() || !incut.emptyTop()) {
                ContourPair outcut(incut);
                outcut.reverse();

//                par.contours.insert(m_contour_num, incut);
                par.contours.push_front(incut);
                par.contours.push_back(outcut);

                m_row = 0;
                m_column = 0;
                par.contours.clearSelected();
                init();
            }
        }
    }
    else {
        txtMsg->setText("It works only for single unloop contour");
    }
}

void FormContour::on_actExitPoint_triggered() {

}

void FormContour::onGenerate() {
    // for loop with incut automatic add outcut
    const size_t count = par.contours.count();
    const bool isCutLine = par.contours.at(0)->type() == CONTOUR_TYPE::CONTOUR_CUTLINE;
    const bool isLoop = par.contours.at(1)->isLoop();
    const bool hasOut = par.contours.at(1)->hasOut();

    if (count == 2 && isCutLine && isLoop && !hasOut) {
        ContourPair* incut = par.contours.at(0);
        ContourPair outcut(*incut);
        outcut.reverse();
        par.contours.push_back(std::move(outcut));
    }

    par.contours.shift(); // to (0,0)
    par.contours.setCut(par.cut, par.genModeList);
    ContourPass pass(par.contours);

    pass.generate();

    if (par.gcode.generate( pass.contours() )) {
        par.gcodeText = par.gcode.toText().c_str();
        emit editPageClicked();
    }
    else
        txtMsg->setText(par.gcode.lastError().c_str());
}

bool FormContour::openDxfFileDialog(QString& fileDir, QString& fileName) {
    QFileDialog dialog(nullptr, tr("Open DXF file"), fileName, tr("DXF Files (*.dxf)"));
    dialog.setAcceptMode(QFileDialog::AcceptMode::AcceptOpen);
    dialog.setFileMode(QFileDialog::FileMode::ExistingFile);
    dialog.setOption(QFileDialog::ReadOnly);
    dialog.setDirectory(fileDir);

    if (dialog.exec()) {
        QStringList list = dialog.selectedFiles();
        fileDir = dialog.directory().path();
        QFile file(list[0]);

        QFileInfo fInfo(list[0]);
        fileName = fInfo.fileName();
        return true;
    }

    return false;
}

void FormContour::initView() {
    qDebug() << "Init. " << "Contours: " << par.contours.count();

    QItemSelectionModel* m = viewContours->selectionModel();
    viewContours->setModel(new ContoursModel(&par.contours));
    delete m;

    viewContours->resizeColumnsToContents();
    lineContours->clear();

    initContourView();
}

void FormContour::setEmptyModel() {
    QItemSelectionModel* m = viewContour->selectionModel();
    viewContour->setModel(new ContourTableModel());
    delete m;
}

void FormContour::initContourView() {
    qDebug() << "Init. " << "Contours: " << par.contours.count();

    QItemSelectionModel* m = viewContour->selectionModel();
    viewContour->setModel(new ContourTableModel(par.contours.at(m_contour_num)));
    delete m;

    viewContour->resizeColumnsToContents();
    lineContour->clear();
}

void FormContour::plot() {
//    plotView.plot(par.contours, plotViewSize());
    plotView.plot(par.contours);
}

void FormContour::plot(const Dxf& contour) {
    plotView.plot(contour);
}

QSize FormContour::plotViewSize() const {
    return plotViewSize(size());
}

QSize FormContour::plotViewSize(const QSize& formSize) const {
    QSize btnSize = gridButtons->sizeHint();
    QSize txtSize = txtMsg->size();

    int w = int(formSize.width() * m_plot_view_pct);
    int h = formSize.height() - btnSize.height() - txtSize.height();

    qDebug() << "Widget size: " << formSize << ", plot width:" << w << ", msg height: " << txtSize.height() << ", buttons height: " << btnSize.height();

    return QSize(w, h);
}

void FormContour::resizeEvent(QResizeEvent* event) {
    if (!plotView.onResizeEvent( plotViewSize(event->size()) ))
        event->ignore();
//    updateGeometry();
//    update();
}
