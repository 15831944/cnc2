#ifndef RUN_PLOT_WIDGET_H
#define RUN_PLOT_WIDGET_H

#include <QWidget>
#include <QTextEdit>
#include <QGridLayout>
#include <QPushButton>
#include <QLabel>
#include <QDoubleSpinBox>
#include <QRadioButton>
#include <QGroupBox>

#include "gcode.h"
#include "plot_view.h"
#include "code_editor.h"
#include "qwt_plot_view.h"

class RunWidget : public QWidget {
    Q_OBJECT

public:
    CodeEditor* txtCode;
    QTextEdit* txtMsg;
    QPushButton *btnStart, *btnReverse, *btnCancel, *btnHold;

    std::vector<QPushButton*> buttons;
    std::vector<QLabel*> labels;
    std::vector<QDoubleSpinBox*> nums;
    std::vector<QRadioButton*> radio;

    QLabel* labelSpeed;
    QDoubleSpinBox* numSpeed;

    QRadioButton *speedMMM, *speedUMS;
    QGroupBox* groupSpeed;

private:
    QwtPlotView plotView;

    QLabel *labelX, *labelY, *labelU, *labelV, *labelTime, *labelETA;
    std::vector<QLabel*> posLabels;
    QGridLayout *gridText, *gridState, *gridButton, *gridMain;

    void createButtons();
    void createTextBoxes();
    void createState();

    QSize plotViewSize() const;
    QSize plotViewSize(const QSize& formSize) const;

protected:
    virtual void resizeEvent(QResizeEvent *event);

public:
    explicit RunWidget(QWidget *parent = nullptr);
    ~RunWidget();

    void plot(const ContourList& contourList);
    void setButtonsEnabled(bool start_ena, bool reverse_ena, bool cancel_ena);
    void setButtonsText(const QString (&text)[3]);
    void setPositionLabels(size_t axis, int value);
    void setElapsedTime(int h, int m, int s);
    void setElapsedTime(qint64 ms);
    void setEstimatedTime(int h, int m, int s);
    void setEstimatedTime(qint64 ms);

    void setFontPointSize(int pointSize);
};

#endif // RUN_PLOT_WIDGET_H
