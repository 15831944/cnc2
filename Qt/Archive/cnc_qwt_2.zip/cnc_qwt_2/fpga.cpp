#include "fpga.h"
//#include <cstdio>
//#include <cstdlib>
//#include <climits>
#include <cmath>

Fpga::Fpga::Fpga() : com(nullptr) {}

void Fpga::Fpga::bind(CncCom** const com) {
    this->com = com;
}
void Fpga::Fpga::unbind() { com = nullptr; }

uint16_t Fpga::Fpga::read_u16(uint16_t addr) {
    if (com && *com) return (*com)->read16(BAR + addr);
    return static_cast<uint16_t>(~0U);
}
int16_t Fpga::Fpga::read_s16(uint16_t addr) {
    if (com && *com) {
        uint16_t value = (*com)->read16(BAR + addr);
        return *reinterpret_cast<int16_t*>(&value);
    }
    return -1;
}
uint32_t Fpga::Fpga::read_u32(uint16_t addr) {
    if (com && *com) return (*com)->read32(BAR + addr);
    return ~0U;
}
int32_t Fpga::Fpga::read_s32(uint16_t addr) {
    if (com && *com) {
        uint32_t value = (*com)->read32(BAR + addr);
        return *reinterpret_cast<int32_t*>(&value);
    }
    return -1;
}
uint64_t Fpga::Fpga::read_u64(uint16_t addr) {
    if (com && *com) return (*com)->read64(BAR + addr);
    return ~0ULL;
}
int64_t Fpga::Fpga::read_s64(uint16_t addr) {
    if (com && *com) {
        uint64_t value = (*com)->read64(BAR + addr);
        return *reinterpret_cast<int64_t*>(&value);
    }
    return -1;
}
uint64_t Fpga::Fpga::read_u48(uint16_t addr) {
    if (com && *com) return (*com)->read48(BAR + addr);
    return ~0ULL;
}

void Fpga::Fpga::write_u16(uint16_t addr, uint16_t data) {
    if (com && *com) (*com)->write16(BAR + addr, data);
}
void Fpga::Fpga::write_s16(uint16_t addr, int16_t data) {
    if (com && *com) (*com)->write16(BAR + addr, *reinterpret_cast<uint16_t*>(data));
}
void Fpga::Fpga::write_u32(uint16_t addr, uint32_t data) {
    if (com && *com) (*com)->write32(BAR + addr, data);
}
void Fpga::Fpga::write_s32(uint16_t addr, int32_t data) {
    if (com && *com) (*com)->write32(BAR + addr, *reinterpret_cast<uint32_t*>(data));
}
void Fpga::Fpga::write_u64(uint16_t addr, uint64_t data) {
    if (com && *com) (*com)->write64(BAR + addr, data);
}
void Fpga::Fpga::write_s64(uint16_t addr, int64_t data) {
    if (com && *com) (*com)->write64(BAR + addr, *reinterpret_cast<uint64_t*>(data));
}
void Fpga::Fpga::write_u48(uint16_t addr, uint64_t data) {
    if (com && *com) (*com)->write48(BAR + addr, data);
}

// MOTORS
void Fpga::Fpga::step(uint8_t i, int N, unsigned T) {
    if (i < MTR_NUM) {
        write_s32(NT32 + i * sizeof(uint64_t), N);
        write_u32(NT32 + i * sizeof(uint64_t) + sizeof(uint32_t), T);
        write_u16(MTR_WRREQ, 1 << 3);
    }
}

int32_t Fpga::Fpga::getN(uint8_t i) {
    if (i < MTR_NUM) return read_s32(NT32 + i * sizeof(uint64_t));
    return 0;
}

uint32_t Fpga::Fpga::getT(uint8_t i) {
    if (i < MTR_NUM) return read_u32(NT32 + i * sizeof(uint64_t)) + sizeof(uint32_t);
    return 0;
}

void Fpga::Fpga::setOE(bool oe) { write_u16(MTR_OE, oe ? 1 : 0); }
bool Fpga::Fpga::getOE() { return read_u16(MTR_OE) == 1; }

uint16_t Fpga::Fpga::getRun() { return read_u16(MTR_WRREQ); }
bool Fpga::Fpga::getStop() { return getRun() == 0; }

void Fpga::Fpga::motorSnapshot() { write_u16(MTR_CONTROL, MTR_SNAPSHOT_BIT); }

uint8_t Fpga::Fpga::getWrreq() { return static_cast<uint8_t>(getRun() & 0xFF); }
bool Fpga::Fpga::getReady() { return getWrreq() == 0; }

void Fpga::Fpga::setTaskID(int32_t value) { write_s32(TASK_ID, value); }
int32_t Fpga::Fpga::getTaskID() { return read_s32(TASK_ID); }

void Fpga::Fpga::setPos(uint8_t index, int32_t value) { write_s32(POS32_DIST32 + index * sizeof(uint64_t), value); }
void Fpga::Fpga::setDist(uint8_t index, uint32_t value) { write_u32(POS32_DIST32 + index * sizeof(uint64_t) + sizeof(uint32_t), value); }

int32_t Fpga::Fpga::getPos(uint8_t index) { return read_s32(POS32_DIST32 + index * sizeof(uint64_t)); }
uint32_t Fpga::Fpga::getDist(uint8_t index) { return read_u32(POS32_DIST32 + index * sizeof(uint64_t) + sizeof(uint32_t)); }

// Control module
uint16_t Fpga::Fpga::getIrqFlags() { return read_u16(IRQ_FLAGS); }
void Fpga::Fpga::clearIrqFlags(uint16_t value) { write_u16(IRQ_FLAGS, value); }
void Fpga::Fpga::setIrqMask(uint16_t value) { write_u16(IRQ_MASK, value); }
uint16_t Fpga::Fpga::getIrqMask() { return read_u16(IRQ_MASK); }

void Fpga::Fpga::reset() { write_u16(RESET, 1); }

uint16_t Fpga::Fpga::getLimitSwitches() { return read_u16(LIMSW); }
bool Fpga::Fpga::getAlarm() { return getLimitSwitches() != 0; }

void Fpga::Fpga::setDato(uint64_t dato) { write_u48(DATO, dato); }
uint64_t Fpga::Fpga::getDatoOld() { return read_u48(DATO_OLD); }
uint16_t Fpga::Fpga::getDati() { return read_u16(DATI); }

// ADCs
void Fpga::Fpga::adcSnapshot() { write_u16(ADC_SNAPSHOT, 1); }

bool Fpga::Fpga::getADC(uint8_t i, uint16_t* const value) {
    if (i < ADC_NUM) {
        *value = read_u16(ADC + i * sizeof(uint16_t));
        return *value < (1 << ADC_BITS);
    }
    *value = 0;
    return false;
}

void Fpga::Fpga::setThld(uint16_t lim) { write_u16(THLD, lim); }
uint16_t Fpga::Fpga::getThld() { return read_u16(THLD); }
void Fpga::Fpga::setAdcEnable(bool ena) { write_u16(ADC_ENA, ena ? 1 : 0); }
bool Fpga::Fpga::getAdcEnable() { return read_u16(ADC_ENA) == 1; }
void Fpga::Fpga::setRunEnable(bool ena) { write_u16(RUN_ENA, ena ? 1 : 0); }
bool Fpga::Fpga::getRunEnable() { return read_u16(RUN_ENA) == 1; }
bool Fpga::Fpga::getPermit() { return read_u16(PERMIT) == 1; }

// Control
cnc_version_t Fpga::Fpga::version() { return read_u32(VER32); }

std::string Fpga::Fpga::readVersion() {
    cnc_version_t fpga_ver = version();
    std::string fpga_s = fpga_ver.toString();
    std::string res = "FPGA: " + fpga_s;
    qDebug("%s", res.c_str());
    return res;
}

void Fpga::Fpga::setKeyLevel(uint32_t value) { return write_u32(KEYS_LEVEL32, value); }
uint32_t Fpga::Fpga::getKeyLevel() { return read_u32(KEYS_LEVEL32); }

// Aux
uint32_t Fpga::Fpga::toTicks(double ms) {
    double res = ms * (CLOCK / 1000);

    if (res < 0)
        res = 0;
    else if (res > UINT_MAX)
        res = UINT_MAX;

    return static_cast<uint32_t>(round(res));
}
