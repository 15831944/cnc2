#include "cnc_program.h"

//void CncProgram::ParseGCode(const QString& txt) {
//    QStringList list = txt.split(QRegExp("(\\n|\\r\\n|\\n\\r)"));
//    uint32_t i = 0;
//    for (auto it = list.begin(); it != list.end(); ++it, i++) {
//        const QString& s = *it;
//    }
//}
