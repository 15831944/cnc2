<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>ContourTableModel</name>
    <message>
        <location filename="contour_table_model.cpp" line="44"/>
        <source>XY Plane</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="contour_table_model.cpp" line="46"/>
        <source>UV Plane</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormContour</name>
    <message>
        <location filename="form_contour.cpp" line="60"/>
        <location filename="form_contour.cpp" line="115"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="62"/>
        <location filename="form_contour.cpp" line="117"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="65"/>
        <location filename="form_contour.cpp" line="120"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="68"/>
        <location filename="form_contour.cpp" line="123"/>
        <source>Save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="71"/>
        <source>Load XY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="73"/>
        <source>Load UV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="76"/>
        <source>Passes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="78"/>
        <location filename="form_contour.cpp" line="133"/>
        <source>Generate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="95"/>
        <location filename="form_contour.cpp" line="152"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="126"/>
        <source>Load DXF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="131"/>
        <source>Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="134"/>
        <location filename="form_contour.cpp" line="135"/>
        <source>Generate G-code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="197"/>
        <source>Contours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="198"/>
        <source>Current</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="228"/>
        <source>New Contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="230"/>
        <source>Add Cutline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="231"/>
        <source>Add new cutline before first segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="232"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="233"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="243"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="244"/>
        <location filename="form_contour.cpp" line="245"/>
        <source>Set as first segment in contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="246"/>
        <source>Change direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="249"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="253"/>
        <source>Set as Cutline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="254"/>
        <source>Set segment as Cutline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="255"/>
        <source>Set as last segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="308"/>
        <source>Open DXF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="308"/>
        <source>DXF Files (*.dxf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="340"/>
        <source>Bottom layer loaded successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="343"/>
        <source>Bottom layer DXF segments sorting error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="351"/>
        <source>Bottom layer DXF parsing error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="607"/>
        <source>No contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="614"/>
        <source>No contour. Only cutline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormEdit</name>
    <message>
        <location filename="form_edit.cpp" line="75"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="76"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="77"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="78"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="80"/>
        <source>Save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="81"/>
        <source>Plot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="87"/>
        <source>to Contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="102"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="103"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <source>Open G-code file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <location filename="form_edit.cpp" line="295"/>
        <source>G-code (*.nc *.NC)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <source>All files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="293"/>
        <source>Save G-code file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="309"/>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="315"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormHelp</name>
    <message>
        <location filename="form_help.cpp" line="32"/>
        <source>Help file not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_help.cpp" line="48"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormHome</name>
    <message>
        <location filename="formhome.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="89"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="96"/>
        <source>Contour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="103"/>
        <source>G-code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="110"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="123"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="133"/>
        <location filename="formhome.ui" line="139"/>
        <location filename="formhome.ui" line="142"/>
        <source>G-code Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="145"/>
        <source>Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="158"/>
        <source>Pult</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="195"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="205"/>
        <source>Minimize Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="208"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="218"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="228"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="33"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="121"/>
        <source>Info: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="121"/>
        <source>Connecting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="127"/>
        <location filename="form_home.cpp" line="133"/>
        <source>Error: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="127"/>
        <source>UART port is not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="133"/>
        <source>No connection. Check conection between computer and CNC board</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.h" line="17"/>
        <source>Meatec CNC Machine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.h" line="18"/>
        <source>MODEL_NAME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_home.h" line="20"/>
        <source>Model</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormPasses</name>
    <message>
        <location filename="form_passes.cpp" line="15"/>
        <source>Cutting settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="55"/>
        <source>Left Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="56"/>
        <source>Right Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="65"/>
        <source>Cut Times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="82"/>
        <source>Overlap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="85"/>
        <location filename="form_passes.cpp" line="108"/>
        <location filename="form_passes.cpp" line="134"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="90"/>
        <source>Tab Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="105"/>
        <source>Offset in pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="114"/>
        <source>Mode in pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="122"/>
        <source>Onepass Cutting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="123"/>
        <source>Multipass Cutting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="125"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="131"/>
        <source>Tab Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="139"/>
        <source>Cutline Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="143"/>
        <source>Tab Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="147"/>
        <source>Tab Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="149"/>
        <source>Pump Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="152"/>
        <source>sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="156"/>
        <source>Pump Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="330"/>
        <source>Generator Operation Modes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="342"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="343"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="344"/>
        <location filename="form_passes.cpp" line="528"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="345"/>
        <location filename="form_passes.cpp" line="531"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="347"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="348"/>
        <source>Factory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="408"/>
        <source>Open modes file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="410"/>
        <location filename="form_passes.cpp" line="472"/>
        <source>Modes file (*.xmd *.XMD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="420"/>
        <source>Modes: Open File Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="426"/>
        <source>Modes: Parse File Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="460"/>
        <source>Modes: Save File Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="470"/>
        <source>Save modes file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="500"/>
        <source>Cutting: Save File Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="510"/>
        <source>Save cutting settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="512"/>
        <source>Cutting settings file (*.xct *.XCT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="526"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="534"/>
        <source>Save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="537"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="564"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="595"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormPassesStone</name>
    <message>
        <location filename="form_passes_stone.cpp" line="15"/>
        <source>Contour Adjustments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="57"/>
        <source>Additional Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="60"/>
        <location filename="form_passes_stone.cpp" line="90"/>
        <location filename="form_passes_stone.cpp" line="133"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="68"/>
        <location filename="form_passes_stone.cpp" line="98"/>
        <source>Left Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="69"/>
        <location filename="form_passes_stone.cpp" line="99"/>
        <source>Right Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="87"/>
        <source>Cutting Offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="130"/>
        <source>Overlapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="138"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="146"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="148"/>
        <source>Last segment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="206"/>
        <source>Tab Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="209"/>
        <source>Pump On Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="212"/>
        <source>sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="216"/>
        <source>Pump On Pause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="218"/>
        <source>Cutting Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="221"/>
        <source>mm/min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="675"/>
        <source>Cutting: Save File Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="685"/>
        <source>Save cutting settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="687"/>
        <source>Cutting settings file (*.xct *.XCT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="701"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="703"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="706"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="709"/>
        <source>Save as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="712"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="738"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormPult</name>
    <message>
        <location filename="form_pult.cpp" line="18"/>
        <source>Pult</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="67"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="70"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="73"/>
        <source>Wire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="77"/>
        <source>Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="81"/>
        <source>Drum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="85"/>
        <location filename="form_pult.cpp" line="100"/>
        <location filename="form_pult.cpp" line="114"/>
        <location filename="form_pult.cpp" line="128"/>
        <location filename="form_pult.cpp" line="142"/>
        <source>DEC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="88"/>
        <location filename="form_pult.cpp" line="107"/>
        <location filename="form_pult.cpp" line="121"/>
        <location filename="form_pult.cpp" line="135"/>
        <location filename="form_pult.cpp" line="149"/>
        <source>INC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="92"/>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="256"/>
        <source>Drum: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="258"/>
        <source>Width: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="260"/>
        <source>Ratio: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="262"/>
        <source>Voltage: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="264"/>
        <source>Current: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormRun</name>
    <message>
        <location filename="form_run.cpp" line="75"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="78"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="81"/>
        <source>Wire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="85"/>
        <source>Pump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="89"/>
        <source>Drum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="93"/>
        <location filename="form_run.cpp" line="108"/>
        <location filename="form_run.cpp" line="122"/>
        <location filename="form_run.cpp" line="136"/>
        <location filename="form_run.cpp" line="150"/>
        <source>DEC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="96"/>
        <location filename="form_run.cpp" line="115"/>
        <location filename="form_run.cpp" line="129"/>
        <location filename="form_run.cpp" line="143"/>
        <location filename="form_run.cpp" line="157"/>
        <source>INC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="101"/>
        <source>Voltage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="265"/>
        <source>Drum: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="267"/>
        <source>Width: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="269"/>
        <source>Ratio: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="271"/>
        <source>Voltage: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="273"/>
        <source>Current: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="435"/>
        <location filename="form_run.cpp" line="447"/>
        <location filename="form_run.cpp" line="456"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="435"/>
        <source>No G-code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="447"/>
        <source>G-code error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="456"/>
        <source>No CNC connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="495"/>
        <location filename="form_run.cpp" line="500"/>
        <location filename="form_run.cpp" line="510"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="495"/>
        <location filename="form_run.cpp" line="500"/>
        <location filename="form_run.cpp" line="510"/>
        <source>Reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="495"/>
        <location filename="form_run.cpp" line="500"/>
        <location filename="form_run.cpp" line="510"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="505"/>
        <location filename="form_run.cpp" line="515"/>
        <location filename="form_run.cpp" line="525"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="520"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="530"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormSettings</name>
    <message>
        <location filename="form_settings.cpp" line="53"/>
        <source>&lt;h2&gt;Options&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="54"/>
        <source>&lt;h3&gt;CNC parameters&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="65"/>
        <source>Input Levels, bits: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="78"/>
        <source>Metal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="79"/>
        <source>Stone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="80"/>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="82"/>
        <source>Step, mm: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="96"/>
        <source>Scale (steps/mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="97"/>
        <source>Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="98"/>
        <source>Encoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="268"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="271"/>
        <source>Read</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="274"/>
        <source>Write</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="317"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FormTest</name>
    <message>
        <location filename="formtest.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="31"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="38"/>
        <source>Quick Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="45"/>
        <source>Full Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="52"/>
        <source>Imitation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="59"/>
        <source>Read CNC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="115"/>
        <source>G-code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="122"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="form_test.cpp" line="112"/>
        <location filename="form_test.cpp" line="118"/>
        <source>Error: No G-code program
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="105"/>
        <source>Warning: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="110"/>
        <source>Error: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="143"/>
        <source>Meatec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="205"/>
        <source>Load DXF contours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="211"/>
        <source>Code Edit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="217"/>
        <source>Run Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="223"/>
        <source>CNC Settigns</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="228"/>
        <source>CNC Pult</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="234"/>
        <source>Test Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="241"/>
        <source>Home Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="246"/>
        <source>Passes Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="251"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModeTableModel</name>
    <message>
        <location filename="mode_table_model.cpp" line="16"/>
        <source>Drum Velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="17"/>
        <source>Pulse Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="18"/>
        <source>Pulse Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="19"/>
        <source>Voltage Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="20"/>
        <source>Current Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="27"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewCutlineDialog</name>
    <message>
        <location filename="new_cutline_dialog.cpp" line="43"/>
        <source>Abs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="new_cutline_dialog.cpp" line="44"/>
        <source>Rel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PultWidget</name>
    <message>
        <location filename="pult_widget.cpp" line="129"/>
        <location filename="pult_widget.cpp" line="247"/>
        <source>Motor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="130"/>
        <location filename="pult_widget.cpp" line="248"/>
        <source>Encoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="131"/>
        <location filename="pult_widget.cpp" line="421"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="132"/>
        <location filename="pult_widget.cpp" line="422"/>
        <source>steps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="157"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="161"/>
        <source>Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="246"/>
        <source>Scale (steps/mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="259"/>
        <source>Move</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="260"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="261"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="434"/>
        <source>Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="440"/>
        <source>mm/min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="441"/>
        <source>um/sec</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="36"/>
        <source>Meatec CNC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RunWidget</name>
    <message>
        <location filename="run_widget.cpp" line="35"/>
        <source>Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="39"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="39"/>
        <source>Reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="39"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="41"/>
        <source>Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="47"/>
        <source>mm/min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="48"/>
        <source>um/sec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="110"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="111"/>
        <source>Remain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
