#include "cnc_types.h"

using namespace std;

uint8_t cut_t::getTimes() const {
    return times <= offsets.size() ? times : uint8_t(offsets.size());
}

vector<offset_t> cut_t::getOffsets() const {
    vector<offset_t> res(offsets);
    uint8_t times = getTimes();

    if (times <= res.size()) {
        res.resize(times);
        return res;
    }
    else
        return res;
}

vector<offset_t> cut_t::getTabOffsets() const {
    if (tab_multi_pass)
        return getOffsets();
    else {
        uint8_t times = getTimes();

        if (times & 1)
            return vector<offset_t>(1, tab_offset);
        else
            return vector<offset_t>(2, tab_offset);
    }
}

offset_t cut_t::getOverlapOffset() const {
    vector<offset_t> offsets = getOffsets();
    return !offsets.empty() ? getOffsets().back() : offset_t();
}

offset_t cut_t::getOutOffset() const {
    return getOverlapOffset();
}

OFFSET_SIDE operator~(const OFFSET_SIDE &side) {
    return side == OFFSET_SIDE::LEFT ? OFFSET_SIDE::RIGHT : OFFSET_SIDE::LEFT;
}
