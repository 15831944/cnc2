#ifndef FORMHOME_H
#define FORMHOME_H

#include <QWidget>
#include <vector>
#include <QPushButton>
#include "program_param.h"

namespace Ui {
class FormHome;
}

class FormHome : public QWidget
{
    Q_OBJECT

    const QString TITLE = tr("Meatec CNC Machine");
    const QString MODEL_NAME = tr("MODEL_NAME");
    const QString info_header = R"(<h1 style="color:black; text-align:center;">)" + TITLE + R"(</h1>)"
                            + R"(<h2 style="color:black; text-align:center;">)" + tr("Model") + ": " + MODEL_NAME + R"(</h2>)";

    const QString help_file = "home.html";

public:
//    explicit FormHome(QWidget *parent = nullptr);
    FormHome(ProgramParam& par, QWidget *parent = nullptr);
    ~FormHome();

    void setFontPointSize(int pointSize);

signals:
    void dxfPageClicked();
    void editPageClicked();
    void runPageClicked();
    void testPageClicked();
    void settingsPageClicked();
    void pultPageClicked();
    void helpPageClicked(const QString& file_name);

private slots:
    void on_btnGCode_clicked();
    void on_btnContour_clicked();
    void on_btnRun_clicked();
    void on_btnSettings_clicked();
    void on_btnTest_clicked();

    void on_btnPult_clicked();

    void on_btnShutdown_clicked();

    void on_btnRec_clicked();

    void on_btnHelp_clicked();

public slots:
    void connectCnc();

private:
    Ui::FormHome *ui;
    ProgramParam& par;
    std::vector<QPushButton*> buttons;

    void showConnecting();
    void showComNotFound();
    void showNoConnection();
    void showVersion(const std::string &mcu, const std::string &fpga);
};

#endif // FORMHOME_H
