#ifndef CNC_H
#define CNC_H

#include <float.h>
#include <string>
#include <deque>

#include "cnc_com.h"
#include "fpga.h"
#include "motor_record.h"
#include "aux_func.h"
#include "defines.h"

namespace ADDR {
    const uint32_t STATUS       = 0;
    const uint32_t CLEAR        = 1 << 2;

    const uint32_t CONTEXT      = 0x10 << 2;

    const uint32_t CONTROLS_ENABLE  = 0x20 << 2;
    const uint32_t DRUM_VEL         = 0x21 << 2;
    const uint32_t VOLTAGE_LEVEL    = 0x22 << 2;
    const uint32_t CURRENT_INDEX    = 0x23 << 2;
    const uint32_t PULSE_WIDTH      = 0x24 << 2;
    const uint32_t PULSE_RATIO      = 0x25 << 2;
    const uint32_t SPEED            = 0x26 << 2;
    const uint32_t STEP             = 0x27 << 2;
    const uint32_t UV_ENABLE        = 0x28 << 2;
    const uint32_t GOTO             = 0x29 << 2;

    const uint32_t KEY_LEVEL        = 0x30 << 2;

    const uint32_t SET_X        = 0x40 << 2;
    const uint32_t SET_Y        = 0x41 << 2;
    const uint32_t SET_U        = 0x42 << 2;
    const uint32_t SET_V        = 0x43 << 2;
    const uint32_t ENC_X        = 0x44 << 2;
    const uint32_t ENC_Y        = 0x45 << 2;
    const uint32_t SET_REQ      = 0x46 << 2;

    const uint32_t MOVE_X       = 0x50 << 2;
    const uint32_t MOVE_Y       = 0x51 << 2;
    const uint32_t MOVE_U       = 0x52 << 2;
    const uint32_t MOVE_V       = 0x53 << 2;
    const uint32_t MOVE_REQ     = 0x54 << 2;

    const uint32_t VER_DATE     = 0xF0 << 2;
    const uint32_t VER_TIME     = 0xF4 << 2;
    const uint32_t SYS_CLOCK    = 0xF8 << 2;
    const uint32_t VER          = 0xF9 << 2;

    const uint32_t TEST_REG     = 0xFF << 2;

    const uint32_t PA_RDADDR    = 0x100 << 2;
    const uint32_t PA_WRADDR    = 0x101 << 2;
    const uint32_t PA_SIZE      = 0x102 << 2;
    const uint32_t IMIT_FIFO_COUNT  = 0x103 << 2;

    const uint32_t IMIT_FIFO_Q  = 0x110 << 2; // 3 * 32 bits

    const uint32_t PA           = 0x08000000;

    const uint32_t RUN_MASK     = 1U << 0;
    const uint32_t STOP_MASK    = 1U << 1;
    const uint32_t REV_MASK     = 1U << 8;
    const uint32_t IMIT_MASK    = 1U << 16;
}

struct point_t {
    int32_t x, y, u, v;
    inline std::string toString() const { return "(" + std::to_string(x) + "," + std::to_string(y) + "," + std::to_string(u) + "," + std::to_string(v) + ")"; }
};

struct path_t {
    uint32_t x, y, u, v;
    inline std::string toString() const { return "(" + std::to_string(x) + "," + std::to_string(y) + "," + std::to_string(u) + "," + std::to_string(v) + ")"; }
};

class WireSpeed {
public:
    enum class Mode: bool {UMS, MMM}; // mm/min, um/sec

    static constexpr double FPGA_FREQ = 72e6; // Hz
    static constexpr double MIN = 0;
    static constexpr double MAX = 300 * 60 / 1000; // mm/min

private:
    double value; // mm/min
    Mode mode;

public:
    WireSpeed(double value = MAX, WireSpeed::Mode mode = WireSpeed::Mode::MMM) {
        setMode(mode);
        set(value);
    }

    void setMode(WireSpeed::Mode value) { mode = value; }
    void set(double value) { this->value = (mode == Mode::MMM) ? value : toMMM(value); }
    void set(double value, WireSpeed::Mode mode) {
        setMode(mode);
        set(value);
    }
    double get() {
        double res = (mode == Mode::MMM) ? value : toUMS(value);

        if (res < min())
            return min();
        else if (res > max())
            return max();

        return res;
    }

    double getMMM() {
        if (value < MIN)
            return MIN;
        else if (value > MAX)
            return MAX;

        return value;
    }

    // result - mm/min
    // T - clock/mm
    static double TtoSpeed(float T) { return (FPGA_FREQ * 60.0) / double(T); }
    void setClockPerMM(float T) { value = TtoSpeed(T); }

    float getClockPerMM() { return float( (FPGA_FREQ * 60.0) / value ); }

    double min() { return mode == Mode::MMM ? MIN : toUMS(MIN); }
    double max() { return mode == Mode::MMM ? MAX : toUMS(MAX); }

    static double toUMS(double value) { return value * (1000.0 / 60.0); }
    static double toMMM(double value) { return value * (60.0 / 1000.0); }
    static float toMMM(float value) { return value * (60.0f / 1000.0f); }
};

//////////////////////////////
enum class cnc_state_t: uint8_t {ST_IDLE, ST_DIRECT, ST_READ, ST_SEGMENT, ST_WAIT, ST_PAUSE, ST_STOP, ST_WAIT_BUTTON, ST_END, ST_ERROR};
enum class drum_state_t: uint8_t {DRUM_DIS, DRUM_FWD, DRUM_REV, DRUM_ANY, DRUM_ERROR};

struct CncParam {
    static constexpr uint16_t KEY_LEVEL_METAL = 0x000;
    static constexpr uint16_t KEY_LEVEL_STONE = 0x001;
    static constexpr uint16_t KEY_LEVEL_TEST = 0x300;
    static constexpr uint16_t KEY_LEVEL_DEFAULT = KEY_LEVEL_STONE;

    static constexpr double DEFAULT_STEP = 0.001; // mm
    static constexpr double DEFAULT_SCALE_XY = 1000; // steps/mm
    static constexpr double DEFAULT_SCALE_UV = 1000; // steps/mm
    static constexpr double DEFAULT_ENC_SCALE = 200; // steps/mm

    uint32_t key_level = KEY_LEVEL_DEFAULT;
    double step = DEFAULT_STEP; // mm
    double scale_x = DEFAULT_SCALE_XY, scale_y = DEFAULT_SCALE_XY, scale_u = DEFAULT_SCALE_UV, scale_v = DEFAULT_SCALE_UV;
    double enc_scale_x = DEFAULT_ENC_SCALE, enc_scale_y = DEFAULT_ENC_SCALE;
};

#define CNC_CONTEX_SIZE32 (11)

typedef union {
    uint32_t data[CNC_CONTEX_SIZE32];
    uint8_t bytes[CNC_CONTEX_SIZE32 * sizeof(uint32_t)];

    struct {
        uint32_t pump_ena:1;
        uint32_t drum_state:2;
        uint32_t wire_ena:1;
        uint32_t voltage_ena:1;
        uint32_t hold_ena:1;
        uint32_t :2;

        uint32_t drum_vel:8;

        uint32_t uv_ena:1;
        uint32_t rev:1;
        uint32_t :5;
        uint32_t valid:1;

        uint32_t state:8;

        uint32_t pulse_width:8;
        uint32_t pulse_ratio:8;
        uint32_t voltage_level:8;
        uint32_t current_index:8;

        int32_t id, x, y, u, v;
        int32_t enc_x, enc_y;
        float T; // clocks/mm
        float step; // mm
    } field;
} cnc_context_t;

Q_DECLARE_METATYPE(cnc_context_t) // for QVariant

struct CncContext {
    static constexpr size_t SIZE32 = CNC_CONTEX_SIZE32;
    static constexpr size_t SIZE = CNC_CONTEX_SIZE32 * sizeof(uint32_t);
    static constexpr float STEP_MIN  = 0.001f; // mm
    static constexpr float STEP_MAX  = 1.0f; // mm

    cnc_context_t m_context;

    static cnc_context_t defaultContext() {
        cnc_context_t ctx;

        ctx.field.pump_ena = false;
        ctx.field.drum_state = static_cast<uint8_t>(drum_state_t::DRUM_DIS);
        ctx.field.wire_ena = false;
        ctx.field.voltage_ena = false;
        ctx.field.hold_ena = false;

        ctx.field.drum_vel = 0;

        ctx.field.uv_ena = false;
        ctx.field.rev = false;
        ctx.field.valid = false;

        ctx.field.state = static_cast<uint8_t>(cnc_state_t::ST_IDLE);

        ctx.field.pulse_width = 0;
        ctx.field.pulse_ratio = 0;
        ctx.field.voltage_level = 0;
        ctx.field.current_index = 0;

        ctx.field.id = -1;
        ctx.field.x = 0;
        ctx.field.y = 0;
        ctx.field.u = 0;
        ctx.field.v = 0;
        ctx.field.enc_x = 0;
        ctx.field.enc_y = 0;
        ctx.field.T = FLT_MAX;
        ctx.field.step = STEP_MIN;

        return ctx;
    }

    CncContext() { m_context = defaultContext(); }
    void setDefault() { m_context = defaultContext(); }

    static cnc_state_t to_cnc_state(uint8_t value) {
        if (value > static_cast<uint8_t>(cnc_state_t::ST_ERROR))
            return cnc_state_t::ST_ERROR;

        return static_cast<cnc_state_t>(value);
    }

    static drum_state_t to_drum_state(uint8_t value) {
        if (value > static_cast<uint8_t>(drum_state_t::DRUM_ERROR))
            return drum_state_t::DRUM_ERROR;

        return static_cast<drum_state_t>(value);
    }

    static cnc_context_t parse(const std::vector<uint8_t>& v) {
        using namespace aux_func;
        cnc_context_t ctx;

        if (v.size() >= SIZE) {
            ctx.field.pump_ena = (v[0] & 1) != 0;
            ctx.field.drum_state = static_cast<uint8_t>(to_drum_state(v[0]>>1 & 3));
            ctx.field.wire_ena = (v[0] & 8) != 0;
            ctx.field.voltage_ena = (v[0] & 0x10) != 0;
            ctx.field.hold_ena = (v[0] & 0x20) != 0;

            ctx.field.drum_vel = v[1];

            ctx.field.uv_ena = (v[2] & 1) != 0;
            ctx.field.rev = (v[2] & 2) != 0;
            ctx.field.valid = (v[2] & 0x80) != 0;

            ctx.field.state = static_cast<uint8_t>(to_cnc_state(v[3]));

            ctx.field.pulse_width = v[4];
            ctx.field.pulse_ratio = v[5];
            ctx.field.voltage_level = v[6];
            ctx.field.current_index = v[7];

            ctx.field.id = BitConverter::toInt32(v, 2 * sizeof(uint32_t));
            ctx.field.x = BitConverter::toInt32(v, 3 * sizeof(uint32_t));
            ctx.field.y = BitConverter::toInt32(v, 4 * sizeof(uint32_t));
            ctx.field.u = BitConverter::toInt32(v, 5 * sizeof(uint32_t));
            ctx.field.v = BitConverter::toInt32(v, 6 * sizeof(uint32_t));
            ctx.field.enc_x = BitConverter::toInt32(v, 7 * sizeof(uint32_t));
            ctx.field.enc_y = BitConverter::toInt32(v, 8 * sizeof(uint32_t));
            ctx.field.T = BitConverter::toFloat(v, 9 * sizeof(uint32_t));
            ctx.field.step = BitConverter::toFloat(v, 10 * sizeof(uint32_t));
        }

        return ctx;
    }

    static cnc_context_t parse(const QByteArray& ar) {
        cnc_context_t ctx;

        if (ar.size() == sizeof(cnc_context_t))
            memcpy(ctx.bytes, ar.data(), sizeof(cnc_context_t));
        else
            ctx = CncContext::defaultContext();

        return ctx;
    }

    static QByteArray getByteArray(const cnc_context_t& ctx) {
        QByteArray bytes(sizeof(cnc_context_t), 0);
        memcpy(bytes.data(), ctx.bytes, sizeof(cnc_state_t));
        return bytes;
    }

    void set(const cnc_context_t& ctx) { m_context = ctx; }
    CncContext(const cnc_context_t& ctx) { m_context = ctx; }
    CncContext(const std::vector<uint8_t>& v) { m_context = parse(v); }
    const cnc_context_t& context() const { return m_context; }

    bool pumpEnabled() const { return m_context.field.pump_ena; }
    drum_state_t drumState() const { return static_cast<drum_state_t>(m_context.field.drum_state); }
    bool wireControlEnabled() const { return m_context.field.wire_ena; }
    bool voltageEnabled() const { return m_context.field.voltage_ena; }
    bool hold() const { return m_context.field.hold_ena; }

    uint8_t drumVelocity() const { return m_context.field.drum_vel; }

    bool uvEnabled() const { return m_context.field.uv_ena; }
    bool reverse() const { return m_context.field.rev; }
    bool valid() const { return m_context.field.valid; }

    cnc_state_t cncState() const {
        return m_context.field.state > static_cast<uint8_t>(cnc_state_t::ST_ERROR) ? cnc_state_t::ST_ERROR : static_cast<cnc_state_t>(m_context.field.state);
    }

    uint8_t pulseWidth() const { return m_context.field.pulse_width; }
    uint8_t pulseRatio() const { return m_context.field.pulse_ratio; }
    uint8_t voltageLevel() const { return m_context.field.voltage_level; }
    uint8_t currentIndex() const { return m_context.field.current_index; }

    int32_t frameNum() const { return m_context.field.id; }
    int32_t x() const { return m_context.field.x; }
    int32_t y() const { return m_context.field.y; }
    int32_t u() const { return m_context.field.u; }
    int32_t v() const { return m_context.field.v; }
    int32_t encoderX() const { return m_context.field.enc_x; }
    int32_t encoderY() const { return m_context.field.enc_y; }

    // clocks/mm
    double speed() const { return WireSpeed::TtoSpeed(m_context.field.T); }
    double step() const { return static_cast<double>(m_context.field.step); } // mm

    inline bool isWork() const {
        return m_context.field.state > static_cast<uint8_t>(cnc_state_t::ST_IDLE) && m_context.field.state < static_cast<uint8_t>(cnc_state_t::ST_ERROR);
    }
    inline bool isError() const {
        return m_context.field.state >= static_cast<uint8_t>(cnc_state_t::ST_ERROR);
    }
    inline bool isIdle() const {
        return m_context.field.state == static_cast<uint8_t>(cnc_state_t::ST_IDLE);
    }

    inline bool isDrumEnable() const {
        return m_context.field.drum_state == static_cast<uint8_t>(drum_state_t::DRUM_FWD) || m_context.field.drum_state == static_cast<uint8_t>(drum_state_t::DRUM_REV);
    }

    inline void setDrumEnable(bool value) {
        m_context.field.drum_state = value ? static_cast<uint8_t>(drum_state_t::DRUM_ANY) : static_cast<uint8_t>(drum_state_t::DRUM_DIS);
    }

    inline std::string toString() const {
        return  "State: " + std::to_string(static_cast<uint8_t>(m_context.field.state)) + "\n" +
                "Frame Number: " + std::to_string(m_context.field.id) + "\n" +
                "Position: (" +  std::to_string(m_context.field.x) + ", " + std::to_string(m_context.field.y) + ", " +
                            std::to_string(m_context.field.u) + ", " + std::to_string(m_context.field.v) + ") " + "\n" +
                "Encoder: (" +  std::to_string(m_context.field.enc_x) + ", " + std::to_string(m_context.field.enc_y) + ")" + "\n" +
                "Pump Enable: " + std::to_string(m_context.field.pump_ena) + "\n" +
                "Drum State: " + std::to_string(m_context.field.drum_state) + "\n" +
                "Wire Control: " + std::to_string(m_context.field.wire_ena) + "\n" +
                "Voltage Enable: " + std::to_string(m_context.field.voltage_ena) + "\n" +
                "Motor Hold Enable: " + std::to_string(m_context.field.hold_ena) + "\n" +
                "Drum Velocity: " + std::to_string(m_context.field.drum_vel) + "\n" +
                "Pulse Width: " + std::to_string(m_context.field.pulse_width) + " Ratio: " + std::to_string(m_context.field.pulse_ratio) + "\n" +
                "Voltage Level: " + std::to_string(m_context.field.voltage_level) + "\n" +
                "Current Index: " + std::to_string(m_context.field.current_index) + "\n" +
                "Period : " + std::to_string(m_context.field.T) + "clock/mm\n" +
                "UV Enable: " + std::to_string(m_context.field.uv_ena) + "\n" +
                "Valid: " + std::to_string(m_context.field.valid) + "\n";
    }
};

class Cnc {
    CncParam* p_cnc_param = nullptr;
    static CncCom* com;

    std::deque<MotorRecord> imit_list;
    aux_func::ReportWriter msg;

public:
    Fpga::Fpga fpga;    

    Cnc();
    ~Cnc();

    void bindCncParam(CncParam* const ptr);
    void setReportWriter(aux_func::ReportWriter msg);

    bool open(std::string portName = DEFAULT_COM);
    inline bool isOpen() const { return com && com->isOpen(); }
    bool close();
    inline CncCom* getCom() { return com; }

    void reset();

    bool writeProgArray(const std::vector<uint8_t>& bytes);
    std::vector<uint8_t> readProgArray();
    bool write(const std::list<std::string>& frames);
    bool writeFromFile(const std::string& fileName = "test.nc");
    void printGCode();
    std::list<std::string> read();

    bool directMoveOn(int32_t nx, double scale_x, int32_t ny, double scale_y, int32_t nu, double scale_u, int32_t nv, double scale_v, double speed);
    bool directSetPos(int32_t nx, int32_t ny, int32_t nu, int32_t nv, int32_t enc_x, int32_t enc_y);

    bool runReq();
    bool revReq();

    bool abortReq();
    bool stopReq();

    bool isRun();

    cnc_context_t readCncContext() const;
    void writeCncContext(const cnc_context_t& ctx, const CncParam& par);

    void imitEna(bool value);
    bool isImitEna();
    void readImitFifo();
    void saveImitData(std::string fileName = "motor_xy.dat");

    std::string versionDate();
    uint32_t sysClock();
    cnc_version_t version();
    std::string readVersion();

    bool testRegs();
    bool testProgArray();
    bool testFpga();

    bool writeUInt32(uint32_t addr, uint32_t data);
    bool writeFloat(uint32_t addr, float data);
    bool writeSetBits(uint32_t addr, unsigned bit, unsigned width, uint16_t data);

    bool writePumpEnable(bool ena);
    bool writeDrumEnable(bool ena);
    bool writeWireEnable(bool ena);
    bool writeVoltageEnable(bool ena);
    bool writeHoldEnable(bool ena);

    bool writeDrumVel(unsigned value);
    bool writeVolgateLevel(unsigned value);
    bool writeCurrentIndex(size_t index);
    bool writePulseWidth(unsigned value);
    bool writePulseRatio(unsigned value);
    bool writeSpeed(float value);
    bool writeSpeed(WireSpeed value);

    bool writeStep(float value);
    bool writeUV(bool ena);
    bool writeGoto(int32_t frame_num);

    bool writeInLevels(uint32_t value);
    uint32_t readInLevels(bool* err = nullptr);
};

#endif // CNC_H
