#include "linenumberarea.h"

LineNumberArea::LineNumberArea()
{

}
