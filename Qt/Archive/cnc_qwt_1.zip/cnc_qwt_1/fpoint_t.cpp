#include "fpoint_t.h"

using namespace std;

fpoint_t::fpoint_t(double x, double y) : x(x), y(y) {}
fpoint_t::fpoint_t(const fpoint_t &other) : x(other.x), y(other.y) {}

fpoint_t& fpoint_t::operator=(const fpoint_t& other) {
    if (this != &other) {
        x = other.x;
        y = other.y;
    }
    return *this;
}

bool fpoint_t::operator==(const fpoint_t& other) const {
    return x > other.x - CMP_PRECISION && x <= other.x + CMP_PRECISION && y > other.y - CMP_PRECISION && y <= other.y + CMP_PRECISION;
}

bool fpoint_t::operator!=(const fpoint_t& other) const {
    return !this->operator==(other);
}

fpoint_t fpoint_t::operator-() const {
    return fpoint_t(-x, -y);
}
fpoint_t fpoint_t::operator+(const fpoint_t &other) const {
    return fpoint_t(x + other.x, y + other.y);
}
fpoint_t fpoint_t::operator-(const fpoint_t &other) const {
    return fpoint_t(x - other.x, y - other.y);
}

void fpoint_t::shift(const fpoint_t& offset) {
    x += offset.x;
    y += offset.y;
}
void fpoint_t::shift(double dx, double dy) {
    x += dx;
    y += dy;
}

string fpoint_t::toString() const { return "(" + std::to_string(x) + ", " + std::to_string(y) + ")"; }

fvalid_point_t& fvalid_point_t::operator=(const fvalid_point_t& other) {
    if (this != &other) {
        x = other.x;
        y = other.y;
        valid = other.valid;
    }
    return *this;
}

bool fvalid_point_t::operator==(const fvalid_point_t& other) const {
    return static_cast<fpoint_t>(*this) == static_cast<fpoint_t>(other) && valid && other.valid;
}

bool fvalid_point_t::operator!=(const fvalid_point_t &other) const {
    return !this->operator==(other);
}

fvalid_point_t fvalid_point_t::operator-() const {
    return static_cast<fpoint_t>(*this).operator-();
}

string fvalid_point_t::toString() const {
    return valid ? static_cast<fpoint_t>(*this).toString() : "Null";
}
