#include "qwt_plot_view.h"

#include <qwt_legend.h>
#include <qwt_plot_curve.h>
#include <qwt_symbol.h>
#include <qwt_plot_magnifier.h>
#include <qwt_plot_panner.h>
#include <qwt_picker_machine.h>

using namespace std;

QwtPlotView::QwtPlotView() :
    margin(40),
    owner(true),
    qwtPlot(new QwtPlot),
    grid(nullptr),
    picker(nullptr),
    m_range(ContourRange(0, 100, 0, 100))
{
    qwtPlot->setMinimumSize(200, 200);
    emptyPlot();
}

QwtPlotView::QwtPlotView(const QwtPlotView& other) :
    margin(other.margin),
    owner(true),
    qwtPlot(new QwtPlot(other.qwtPlot)),
    m_range(other.m_range)
{
    qwtPlot->setMinimumSize(QSize(200, 200));
}

QwtPlotView::QwtPlotView(QwtPlotView&& other) :
    margin(other.margin),
    owner(other.owner),
    qwtPlot(other.qwtPlot),
    m_range(other.m_range)
{
    if (qwtPlot)
        qwtPlot->setMinimumSize(200, 200);

    other.owner = false;
    other.qwtPlot = nullptr;
}

QwtPlotView::~QwtPlotView() {
    if (owner)
        delete qwtPlot;
}

QwtPlot* QwtPlotView::give() {
    owner = false;
    return qwtPlot;
}

void QwtPlotView::emptyPlot(const QSize& frameSize) {
    if (!qwtPlot) return;

//    QSizePolicy sp(QSizePolicy::Fixed, QSizePolicy::Fixed);
    QSizePolicy sp(QSizePolicy::Preferred, QSizePolicy::Preferred);
//    sp.setHeightForWidth(true);
    qwtPlot->setSizePolicy(sp);

    qwtPlot->detachItems();
    qwtPlot->setCanvasBackground(Qt::white);

    m_range = ContourRange(0, 100, 0, 100);
    setAxis(frameSize);

    qwtPlot->replot();
}

void QwtPlotView::emptyPlot() {
    emptyPlot(qwtPlot->size());
}

void QwtPlotView::plot(const ContourList& contourList, const QSize& frameSize) {
    ContourRange range;
    QVector<QPointF> pts_bot, pts_top;

    if (!qwtPlot) return;

    qwtPlot->detachItems(QwtPlotItem::Rtti_PlotItem, true); // it's default

    int i = 0, j = 0, k = 0;
    bool passed_bot_reg = true, passed_top_reg = true;

    for (const ContourPair& pair: contourList.contours()) {
        for (const DxfEntity* ent: pair.bot().entities()) {
            bool passed = i < contourList.currentContourNumber() || (i == contourList.currentContourNumber() && j <= contourList.currentSegmentNumber());

            if (passed ^ passed_bot_reg) {
                if (!pts_bot.empty()) {
                    addPlot(qwtPlot, range, pts_bot, passed_bot_reg ? Qt::GlobalColor::red : Qt::GlobalColor::blue);
                    pts_bot.clear();
                }
                passed_bot_reg = passed;
            }

            copy_back(pts_bot, ent->getPoints());

            j++;
        }

        for (const DxfEntity* ent: pair.top().entities()) {
            bool passed = i < contourList.currentContourNumber() || (i == contourList.currentContourNumber() && k <= contourList.currentSegmentNumber());

            if (passed ^ passed_top_reg) {
                if (!pts_top.empty()) {
                    addPlot(qwtPlot, range, pts_top, passed_top_reg ? Qt::GlobalColor::darkRed : Qt::GlobalColor::darkBlue);
                    pts_top.clear();
                }
                passed_top_reg = passed;
            }

            copy_back(pts_top, ent->getPoints());

            k++;
        }

        i++;
    }

    if (!pts_bot.empty()) {
        addPlot(qwtPlot, range, pts_bot, passed_bot_reg ? Qt::GlobalColor::red : Qt::GlobalColor::blue);
        pts_bot.clear();
    }

    if (!pts_top.empty()) {
        addPlot(qwtPlot, range, pts_top, passed_top_reg ? Qt::GlobalColor::darkRed : Qt::GlobalColor::darkBlue, 2);
        pts_top.clear();
    }

    addPlot(qwtPlot, range, contourList.selectedBot());
    addPlot(qwtPlot, range, contourList.selectedTop());

//    fpoint_t pt(0,0);
//    range.append({pt});
//    addPoint(newChart, &pt, nullptr);

    addPoint(qwtPlot, contourList.botPos(), contourList.topPos());
    addLine(qwtPlot, contourList.botPos(), contourList.topPos());

    tweakPlot(qwtPlot, range, frameSize);
}

void QwtPlotView::plot(const ContourList& contourList) {
    plot(contourList, qwtPlot->size());
}

void QwtPlotView::plot(const Dxf& ctr, const QSize& frameSize) {
    ContourRange range;
    QVector<QPointF> pts;

    if (!qwtPlot) return;
    qwtPlot->detachItems();

    if (ctr.empty()) return;

    copy_back(pts, ctr.getPoints());
    addPlot(qwtPlot, range, pts);
    tweakPlot(qwtPlot, range, frameSize);
}

void QwtPlotView::plot(const Dxf& ctr) {
    plot(ctr, qwtPlot->size());
}

void QwtPlotView::tweakPlot(QwtPlot* const newPlot, const ContourRange& range, const QSize& frameSize) {
    static QSize frameSize_old = {0, 0};

    bool print_new = frameSize != frameSize_old || !range.equal(m_range);
    frameSize_old = frameSize;

    if (newPlot && !newPlot->itemList().empty()) {
        qwtPlot->setCanvasBackground( Qt::white );

        grid = new QwtPlotGrid();
        grid->setMajorPen(QPen( Qt::gray, 1 ));
        grid->setMinorPen(Qt::black, 1, Qt::PenStyle::DotLine);
        grid->enableXMin(true);
        grid->enableYMin(true);
        grid->attach(qwtPlot);

        // todo: delete picker
//        QwtPlotPicker* picker = new QwtPlotPicker(
//            QwtPlot::xBottom, QwtPlot::yLeft, QwtPlotPicker::CrossRubberBand, QwtPicker::ActiveOnly, qwtPlot->canvas()
//        );
//        picker->setRubberBandPen( QColor(Qt::red) );
//        picker->setTrackerPen( QColor(Qt::black) );
//        picker->setStateMachine( new QwtPickerDragPointMachine );

        m_range = range;

        if (print_new) qDebug() << "Plot items: " << newPlot->itemList().count();

        setAxis(frameSize);

        newPlot->updateGeometry();
        newPlot->update();
        newPlot->show();

        if (print_new) qDebug() << "Plot size: " << newPlot->size();
    }
    else
        emptyPlot(frameSize);

    newPlot->replot();
}

void QwtPlotView::setAxis(const QSize& frameSize) {
    static ContourRange range_old;
    static QSize frameSize_old = {0, 0};

    if (!m_range.valid || frameSize.width() == 0 || frameSize.height() == 0) return;

    bool print_new = !m_range.equal(range_old) || frameSize != frameSize_old;
    range_old = m_range;
    frameSize_old = frameSize;

    double width = m_range.width();
    double height = m_range.height();

    if (print_new) qDebug() << "Aspect ratio " << frameSize.width() << ":" << frameSize.height();
    if (print_new) qDebug() << "Plot ratio " << width << ":" << height;

    double aspect_ratio = static_cast<double>(frameSize.width() - D_WIRE_PX) / static_cast<double>(frameSize.height() - D_WIRE_PX);

    double scale; // mm / pixel

    if (width < 0.001 && height < 0.001)
        scale = 1;
    else {
        double plot_ratio = width / height;

        if (plot_ratio > aspect_ratio)
            scale = width / (frameSize.width() - D_WIRE_PX);
        else
            scale = height / (frameSize.height() - D_WIRE_PX);
    }

    if (print_new) qDebug() << "Scale " << scale << " mm / pixel";

    width = frameSize.width() * scale; // mm
    height = frameSize.height() * scale; // mm
    double wire_mm = D_WIRE_PX * scale;

    if (print_new) qDebug() << "New plot ratio " << width << ":" << height;

    qwtPlot->setAxisScale(QwtPlot::xBottom, m_range.x_min - wire_mm / 2, m_range.x_min + width + wire_mm / 2);
    qwtPlot->setAxisScale(QwtPlot::yLeft, m_range.y_min - wire_mm / 2, m_range.y_min + height + wire_mm / 2);
    qwtPlot->updateAxes();
}

void QwtPlotView::addPlot(QwtPlot* const newPlot, ContourRange& newRange, const QVector<QPointF>& pts, const QColor& color, int width, Qt::PenStyle style) {
    if (!newPlot || pts.empty()) return;

    newRange.append(pts);

    QwtPlotCurve* curve = new QwtPlotCurve;
    curve->setPen(color, width, style);
    curve->setRenderHint(QwtPlotItem::RenderAntialiased, true);

    curve->setSamples(pts);
    curve->attach(newPlot);
}

void QwtPlotView::addPlot(QwtPlot* const newPlot, ContourRange& newRange, const Dxf* const dxf, const QColor& color, int width, Qt::PenStyle style) {
    QVector<QPointF> pts;

    if (newPlot && dxf && !dxf->empty()) {
        copy_back(pts, dxf->getPoints());
        addPlot(newPlot, newRange, pts, color, width, style);
    }
}

void QwtPlotView::addPlot(QwtPlot* const newPlot, ContourRange& newRange, const DxfEntity* const entity, const QColor& color, int width, Qt::PenStyle style) {
    QVector<QPointF> pts;

    if (newPlot && entity) {
        copy_back(pts, entity->getPoints());
        addPlot(newPlot, newRange, pts, color, width, style);
    }
}

void QwtPlotView::addPoint(QwtPlot* const newPlot, const fpoint_t* const bot, const fpoint_t* const top, const QColor& botColor, const QColor& topColor, int size) {
    if (!newPlot)
        return;

    int width = size / 2;

    if (bot) {
        QwtPlotCurve* curve = new QwtPlotCurve;
        curve->setPen(botColor, width);
        curve->setRenderHint(QwtPlotItem::RenderAntialiased, true);

        QwtSymbol* symbol = new QwtSymbol( QwtSymbol::Style::Ellipse, QBrush(botColor), QPen(botColor, width), QSize(width, width) );
        curve->setSymbol(symbol);

        curve->setSamples( {QPointF(bot->x, bot->y)} );
        curve->attach(newPlot);
    }

    if (top) {
        QwtPlotCurve* curve = new QwtPlotCurve;
        curve->setPen(topColor, width);
        curve->setRenderHint(QwtPlotItem::RenderAntialiased, true);

        QwtSymbol* symbol = new QwtSymbol( QwtSymbol::Style::Ellipse, QBrush(topColor), QPen(topColor, width), QSize(width, width) );
        curve->setSymbol(symbol);

        curve->setSamples( {QPointF(top->x, top->y)} );
        curve->attach(newPlot);
    }
}

void QwtPlotView::addLine(QwtPlot* const newPlot, const fpoint_t* const bot, const fpoint_t* const top, const QColor& color, int width, Qt::PenStyle style) {
    if (top && bot && newPlot) {
        QVector<QPointF> pts = {QPointF(bot->x, bot->y), QPointF(top->x, top->y)};

        QwtPlotCurve* curve = new QwtPlotCurve;
        curve->setPen(color, width, style);
        curve->setRenderHint(QwtPlotItem::RenderAntialiased, true);

        curve->setSamples(pts);
        curve->attach(newPlot);
    }
}

bool QwtPlotView::onResizeEvent(const QSize& newFrameSize) {
    if (!m_range.valid) return false;

    setAxis(newFrameSize);
    qwtPlot->updateGeometry();
    qwtPlot->update();
    return true;
}

void QwtPlotView::copy_back(vector<fpoint_t>& pts, const vector<fpoint_t>& ent_pts) { // to template with float, or uint16_t and scale
    fpoint_t cur;

    for (const fpoint_t& pt: ent_pts) {
        if (pts.empty()) {
            pts.push_back(pt);
            cur = pt;
        }
        else if (pt != cur) {
            pts.push_back(pt);
            cur = pt;
        }
    }
}

void QwtPlotView::copy_back(QVector<QPointF>& pts, const vector<fpoint_t>& ent_pts) {
    fpoint_t cur;

    for (const fpoint_t& pt: ent_pts) {
        if (pts.empty()) {
            pts.push_back(QPointF(pt.x, pt.y));
            cur = pt;
        }
        else if (pt != cur) {
            pts.push_back(QPointF(pt.x, pt.y));
            cur = pt;
        }
    }
}

