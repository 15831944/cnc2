#include "cnc_context.h"

void toDebug(const cnc_context_t * const ctx) {
    qDebug("pump:%x drumSt:%x wire:%x hv:%x hold:%x\n",
           ctx->field.pump_ena, ctx->field.drum_state, ctx->field.wire_ena, ctx->field.voltage_ena, ctx->field.hold_ena);
    qDebug("drumVel:%x\n",
           ctx->field.drum_vel);
    qDebug("uv:%x rev:%x enc:%x\n",
           ctx->field.uv_ena, ctx->field.rev, ctx->field.enc_ena);
    qDebug("St:%x\n",
           ctx->field.state);
    qDebug("pW:%d pR:%d hvLvl:%x I:%x\n",
           ctx->field.pulse_width, ctx->field.pulse_ratio, ctx->field.voltage_level, ctx->field.current_index);
    qDebug("ID:%d X:%d Y:%d U:%d V:%d\n",
           (int)ctx->field.id, (int)ctx->field.x, (int)ctx->field.y, (int)ctx->field.u, (int)ctx->field.v);
    qDebug("encX:%d encY:%d\n",
           (int)ctx->field.enc_x, (int)ctx->field.enc_y);
    qDebug("T:%g\n",
           ctx->field.T);
    qDebug("T:%g\n",
           ctx->field.step);
    qDebug("bkp:%x read:%x\n",
           ctx->field.backup_valid, ctx->field.read_valid);
}

#ifdef CNC2
const double cnc_adc_volt_t::coe[6] {
    volt(1.0 / 61.04, 4.096, 10),
    volt(1.0 / 111.08, 4.096, 10),
    volt(1e6, 20e3, 1, 4.096, 10),
    volt(1e6, 20e3, 1, 4.096, 10),
    volt(1e6, 20e3, 1, 4.096, 10),
    volt(10, 4.096, 10),
};
#else
//const double cnc_adc_volt_t::coe[6] {
//    volt(100e3, 3.01e3, 1, 4.096, 10), // diff
//    volt(10e3, 100e3, 10, 4.096, 10), // shunt
//    volt(100e3, 3.01e3, 1, 4.096, 10), // back
//    volt(100e3, 3.01e3, 1, 4.096, 10), // HV
//    volt(100e3, 3.01e3, 1, 4.096, 10), // Workpiece+
//    volt(100e3, 3.01e3, 1, 4.096, 10) // Wire-
//};
#endif
