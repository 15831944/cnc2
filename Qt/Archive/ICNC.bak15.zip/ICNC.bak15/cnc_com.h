#ifndef CNCCOM_H
#define CNCCOM_H

#include <QSerialPort>
#include <QSerialPortInfo>
#include <vector>
#include <string>
#include "aux_func.h"

//#define PRINT_CNC_COM_DEBUG

class CncCom
{
    const size_t MAX_PACKET_SIZE = 4 + 1 + 255 + 4;
    std::vector<uint8_t> tx_buf = std::vector<uint8_t>(MAX_PACKET_SIZE), rx_buf = std::vector<uint8_t>(MAX_PACKET_SIZE);
    QSerialPort* port = nullptr;
//    FILE* pFile = nullptr;
    aux_func::ReportWriter txt;

    static void push_back_u32_rev(std::vector<uint8_t>& v, uint32_t data);
    int readPort(std::vector<uint8_t>& rx_buf, int timeout_ms = 30000);
//    static void delay(int timeout);
public:
    enum Commands : uint8_t { CMD_IDLE, CMD_READ, CMD_WRITE, CMD_READ_FIFO, CMD_ERROR = 0xF };

    CncCom(aux_func::ReportWriter txt);
    ~CncCom();

//    bool open(const std::string& portName); // Linux: "/dev/ttyACM0" || Win: "COM6"
    bool open(); // STM vendor ID
    inline bool isOpen() {
//        return pFile != nullptr;
        return port && port->isOpen();
    }
    bool close();

    void writeBytes(uint32_t addr, const std::vector<uint8_t>& bytes, size_t begin, uint8_t len);
    void writeBytes(uint32_t addr, const uint8_t* bytes, size_t size, size_t begin, uint8_t length);

    void write(uint32_t addr, const std::vector<uint8_t>& bytes);
    void write(uint32_t addr, const void* data, size_t size);
    void write16(uint32_t addr, uint16_t data);
    void write32(uint32_t addr, uint32_t data);
    void write48(uint32_t addr, uint64_t data);
    void write64(uint32_t addr, uint64_t data);

    std::vector<uint8_t> readBytes(uint32_t addr, uint8_t len);
    std::vector<uint8_t> readFifo(uint32_t addr, uint8_t len);
    std::vector<uint8_t> read(uint32_t addr, size_t len);
    uint16_t read16(uint32_t addr);
    uint32_t read32(uint32_t addr);
    uint64_t read48(uint32_t addr);
    uint64_t read64(uint32_t addr);

    std::vector<uint32_t> readArray32(uint32_t addr, size_t len);
};

#endif // CNCCOM_H
