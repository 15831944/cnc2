#include "form_center.h"
#include <QDebug>
#include <QTimer>

using namespace std;

FormCenter::FormCenter(ProgramParam& par, QWidget *parent) :
    QWidget(parent), par(par), cncReaderEna(false), adcEnable(false), wireSpeedMode(WireSpeed::Mode::MMM)
{
    centerWidget = new CenterWidget(this);
    addButtons();

    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(centerWidget);
    mainLayout->addLayout(gridButtons);

    this->setLayout(mainLayout);

//    bindNumberButtons(numWidth, btnWidthInc, btnWidthDec);

//    connect(sender, &Sender::valueChanged,
//        [=]( const QString &newValue ) { receiver->updateValue( "senderValue", newValue ); }
//    );
}

FormCenter::~FormCenter() {
    stopCncReader();
    stopAdc();
}

void FormCenter::addButtons() {
    btnHome = new QPushButton(tr("Home"));
    btnHome->setStatusTip(tr("Go to Home panel"));

    btnXDec = new QPushButton(tr("X-"));
    btnXDec->setStatusTip(tr("Decrease X"));

    btnXInc = new QPushButton(tr("X+"));
    btnXInc->setStatusTip(tr("Increase X"));

    btnYDec = new QPushButton(tr("Y-"));
    btnYDec->setStatusTip(tr("Decrease Y"));

    btnYInc = new QPushButton(tr("Y+"));
    btnYInc->setStatusTip(tr("Increase Y"));

    btnCenter = new QPushButton(tr("Center"));
    btnCenter->setStatusTip(tr("Find the center"));

    btn6 = new QPushButton;

    btn7 = new QPushButton;

    btn8 = new QPushButton;

    btn9 = new QPushButton;

    btn10 = new QPushButton;

    btnHold = new QPushButton(tr("Hold"));
    btnHold->setCheckable(true);

    btnCancel = new QPushButton(tr("Cancel"));

    btnHelp = new QPushButton(tr("Help"));

    buttons = {btnHome, btnXDec, btnXInc, btnYDec, btnYInc, btnCenter, btn6, btn7, btn8,\
               btn9, btn10, btnHold, btnCancel, btnHelp};

    gridButtons = new QGridLayout;

    gridButtons->addWidget(btnHome, 0, 0);
    gridButtons->addWidget(btnXDec, 0, 1);
    gridButtons->addWidget(btnXInc, 0, 2);
    gridButtons->addWidget(btnYDec, 0, 3);
    gridButtons->addWidget(btnYInc, 0, 4);
    gridButtons->addWidget(btnCenter, 0, 5);
    gridButtons->addWidget(btn6, 0, 6);
    gridButtons->addWidget(btn7, 0, 7);
    gridButtons->addWidget(btn8, 0, 8);
    gridButtons->addWidget(btn9, 0, 9);
    gridButtons->addWidget(btn10, 0, 10);
    gridButtons->addWidget(btnHold, 0, 11);
    gridButtons->addWidget(btnCancel, 0, 12);
    gridButtons->addWidget(btnHelp, 0, 13);

    connect(btnHome, &QPushButton::clicked, this, &FormCenter::on_btnHome_clicked);

    connect(btnXDec, &QPushButton::clicked, this, [&]() { on_btnXYForward_clicked(-1, AXIS::AXIS_X); });
    connect(btnXInc, &QPushButton::clicked, this, [&]() { on_btnXYForward_clicked(1, AXIS::AXIS_X); });
    connect(btnYDec, &QPushButton::clicked, this, [&]() { on_btnXYForward_clicked(-1, AXIS::AXIS_Y); });
    connect(btnYInc, &QPushButton::clicked, this, [&]() { on_btnXYForward_clicked(1, AXIS::AXIS_Y); });
    connect(btnCenter, &QPushButton::clicked, this, &FormCenter::on_btnCenter_clicked);

    connect(btnCancel, &QPushButton::clicked, this, &FormCenter::on_btnCancel_clicked);

    connect(btnHold, &QPushButton::clicked, this, [&]() {
        try {
            par.cnc.writeHoldEnable( btnHold->isChecked() );
        }
        catch (...) {}
    });

    connect(btnHelp, &QPushButton::clicked, this, [&]() { emit helpPageClicked(help_file); });
}

void FormCenter::init() {
    initButtons();
    startCncReader();
    startAdc();
}

void FormCenter::on_btnHome_clicked() {
    stopCncReader();
    stopAdc();
    emit homePageClicked();
}

void FormCenter::on_btnXYForward_clicked(int dir, AXIS axis) {
    centerWidget->emptyPlot();

    par.cnc.writeHoldEnable(true);
    par.cnc.writeFeedback(true, centerWidget->thresholdLow(), centerWidget->thresholdHigh());

    par.cnc.centering(
                axis == AXIS::AXIS_X ? CENTER_MODE_T::CENTER_X : CENTER_MODE_T::CENTER_Y, centerWidget->attempts(), centerWidget->fineZonePct(), centerWidget->drumVel(),
                dir < 0 ? -centerWidget->radius() : centerWidget->radius(),
                dir < 0 ? centerWidget->rollback() : -centerWidget->rollback(),
                centerWidget->speedCoarse(), centerWidget->speedFine());
}

void FormCenter::on_btnCenter_clicked() {
    centerWidget->emptyPlot();

    par.cnc.writeHoldEnable(true);
    par.cnc.writeFeedback(true, centerWidget->thresholdLow(), centerWidget->thresholdHigh());

    par.cnc.centering(
                CENTER_MODE_T::CENTER_CIRCLE, centerWidget->attempts(), centerWidget->fineZonePct(), centerWidget->drumVel(),
                fabs(centerWidget->radius()), 0,
                centerWidget->speedCoarse(), centerWidget->speedFine());
}

void FormCenter::on_btnCancel_clicked() {
    par.cnc.abortReq();
}

void FormCenter::startCncReader() {
    if (par.cnc.isOpen()) {
        qDebug()<<"CNC reader: Start";

        if (!cncReaderEna) {
            cncReaderEna = true;
            readCutState();
        }
    }
}

void FormCenter::stopCncReader() {
    qDebug()<<"CNC reader: Stop";
    cncReaderEna = false;
}

void FormCenter::readCutState() {
    if (cncReaderEna) {
//        qDebug()<<"CNC reader: Reading...";

        try {
            CncContext ctx = par.cnc.readCncContext();
//            qDebug() << "CNC reader: " + QString(cut_state.toString().c_str());


            centerWidget->setX(ctx.x());
            centerWidget->setY(ctx.y());
//            centerWidget->addPlot(ctx.x(), ctx.y());

            centerWidget->setSpeed(ctx.speed());

            centerWidget->setLimitSwitches(ctx.limitSwitches());

            btnHold->blockSignals(true);
            btnHold->setChecked(ctx.hold());
            btnHold->blockSignals(false);

            if (ctx.isWork()) {
                btnHome->setEnabled(false);
                btnXDec->setEnabled(false);
                btnXInc->setEnabled(false);
                btnYDec->setEnabled(false);
                btnYInc->setEnabled(false);
                btnCenter->setEnabled(false);
                btnCancel->setEnabled(true);
                btnHelp->setEnabled(false);
            }
            else if (ctx.isError()) {
                par.cnc.abortReq();
                initButtons();
            }
            else
                initButtons();
        }
        catch (...) {
            initButtons();
        }

        QTimer::singleShot(POLLING_TIME, this, &FormCenter::readCutState);
    }
}

void FormCenter::initButtons() {
    btnHome->setEnabled(true);
    btnXDec->setEnabled(true);
    btnXInc->setEnabled(true);
    btnYDec->setEnabled(true);
    btnYInc->setEnabled(true);
    btnCenter->setEnabled(true);
    btnCancel->setEnabled(false);
    btnHelp->setEnabled(true);
}

void FormCenter::startAdc() { // on init
    if (par.cnc.isOpen()) {
        qDebug()<<"ADC: Start";

        if (!adcEnable) {
            adcEnable = true;
            readAdc();
        }
    }
    else
        adcEnable = false;
}

void FormCenter::stopAdc() { // on home
    qDebug()<<"ADC: Stop";
    adcEnable = false;
}

void FormCenter::readAdc() {
    if (adcEnable) {
        cnc_adc_volt_t adc = par.cnc.readADCVolt();
        centerWidget->setAdc(adc);
        QTimer::singleShot(ADC_POLLING_TIME, this, &FormCenter::readAdc);
    }
}

void FormCenter::setFontPointSize(int pointSize) {
    centerWidget->setFontPointSize(pointSize);

    for (QPushButton* b: buttons) {
        QFont font = b->font();
        font.setPointSize(pointSize);
        b->setFont(font);
//        b->setStyleSheet("font: bold");
    }
}
