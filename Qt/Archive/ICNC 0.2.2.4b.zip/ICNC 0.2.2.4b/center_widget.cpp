#include "center_widget.h"

#include <qwt_legend.h>
#include <qwt_plot_curve.h>
#include <qwt_symbol.h>
#include <qwt_plot_magnifier.h>
#include <qwt_plot_panner.h>
#include <qwt_picker_machine.h>
#include <qwt_scale_engine.h>
#include <qwt_plot_rescaler.h>
#include <qwt_plot_layout.h>

#include "main.h"
#include "cnc.h"

using namespace std;

CenterWidget::CenterWidget(QWidget *parent):
    QWidget(parent),
    gridPlot(nullptr),
    pickerPlot(nullptr)
{
    qwtPlot = new QwtPlot;
    qwtPlot->setMinimumSize(200, 200);
    qwtPlot->setCanvasBackground( Qt::white );

    checkAdvanced = new QCheckBox(tr("Advanced settings"));
    checkAdvanced->setCheckState(Qt::CheckState::Checked);
    checkAdvanced->setEnabled(false);

    labelRadius = new QLabel(tr("Search radius") + ": ");
    fnumRadius = new QDoubleSpinBox;
    fnumRadius->setRange(1, 200);
    fnumRadius->setSingleStep(1);
    fnumRadius->setAccelerated(true);
    fnumRadius->setSuffix(" " + tr("mm"));
    fnumRadius->setValue(100);

    labelFineZone = new QLabel(tr("Fine zone") + ": ");
    numFineZone = new QSpinBox;
    numFineZone->setRange(0, 100);
    numFineZone->setSingleStep(1);
    numFineZone->setValue(20);
    numFineZone->setSuffix(" %");

    labelRollback = new QLabel(tr("Rollback") + ": ");
    fnumRollback = new QDoubleSpinBox;
    fnumRollback->setRange(0, 200);
    fnumRollback->setSingleStep(1);
    fnumRollback->setAccelerated(true);
    fnumRollback->setSuffix(" " + tr("mm"));
    fnumRollback->setValue(0);

    labelHighThld = new QLabel(tr("High Threshold") + ": ");
    numHighThld = new QSpinBox;
    numHighThld->setRange(1, 100);
    numHighThld->setSingleStep(1);
    numHighThld->setAccelerated(true);
    numHighThld->setSuffix(" " + tr("V"));
    numHighThld->setValue(30);

    labelLowThld = new QLabel(tr("Low Threshold") + ": ");
    numLowThld = new QSpinBox;
    numLowThld->setRange(1, 100);
    numLowThld->setSingleStep(1);
    numLowThld->setAccelerated(true);
    numLowThld->setSuffix(" " + tr("V"));
    numLowThld->setValue(30);

    labelAttempts = new QLabel(tr("Attempts") + ": ");
    numAttempts = new QSpinBox;
    numAttempts->setRange(1, 5);
    numAttempts->setSingleStep(1);
    numAttempts->setValue(1);

    labelX = new QLabel(tr("X") + ": ");
    fnumX = new QDoubleSpinBox;
    fnumX->setRange(-9999, 9999);
    fnumX->setDecimals(3);
    fnumX->setSuffix(" " + tr("mm"));
    fnumX->setReadOnly(true);

    labelY = new QLabel(tr("Y") + ": ");
    fnumY = new QDoubleSpinBox;
    fnumY->setRange(-9999, 9999);
    fnumY->setDecimals(3);
    fnumY->setSuffix(" " + tr("mm"));
    fnumY->setReadOnly(true);

    labelVolt = new QLabel(tr("Voltage") + ": ");
    fnumVolt = new QDoubleSpinBox;
    fnumVolt->setRange(0, 999);
    fnumVolt->setDecimals(0);
    fnumVolt->setSuffix(" " + tr("V"));
    fnumVolt->setReadOnly(true);

    labelSpeed = new QLabel(tr("Speed") + ": ");
    fnumSpeed = new QDoubleSpinBox;
    fnumSpeed->setRange(0, 999);
    fnumSpeed->setDecimals(0);
    fnumSpeed->setSuffix(" " + tr("mm/min"));
    fnumSpeed->setReadOnly(true);

    createSpeed();

    labelDrumVel = new QLabel(tr("Drum Velocity") + ": ");
    numDrumVel = new QSpinBox;
    numDrumVel->setRange(0, 7);
    numDrumVel->setSingleStep(1);
    numDrumVel->setValue(0);

    btnResetPos = new QPushButton(tr("Reset position"));
    btnResetPos->setStatusTip(tr("G92 X0 Y0"));

    QGridLayout *gridControl = new QGridLayout;
    gridControl->addWidget(checkAdvanced, 0, 0);
    gridControl->addWidget(groupLabelNum(labelRadius, fnumRadius), 1, 0);
    gridControl->addWidget(groupLabelNum(labelFineZone, numFineZone), 2, 0);
    gridControl->addWidget(groupLabelNum(labelRollback, fnumRollback), 3, 0);
    gridControl->addLayout(gridSpeed, 4, 0);
    gridControl->addWidget(groupLabelNum(labelDrumVel, numDrumVel), 5, 0);
    gridControl->addWidget(groupLabelNum(labelHighThld, numHighThld), 6, 0);
    gridControl->addWidget(groupLabelNum(labelLowThld, numLowThld), 7, 0);
    gridControl->addWidget(groupLabelNum(labelAttempts, numAttempts), 8, 0);
    gridControl->addWidget(btnResetPos, 9, 0);
    gridControl->addWidget(new QFrame, 10, 0);

    // Limit Switches
    labelFWD = new QLabel("FWD");
    labelREV = new QLabel("REV");
    labelWB = new QLabel("WB");
    labelALM = new QLabel("ALM");
    labelPWR = new QLabel("PWR");

    labelFB = new QLabel("FB");
    labelTO = new QLabel("TO");

    checkLabels = {labelTO, labelFB, labelPWR, labelALM, labelWB, labelREV, labelFWD};

    checkPWR = new QCheckBox;
    checkPWR->setEnabled(false);
    checkFB = new QCheckBox;
    checkFB->setEnabled(false);
    checkTO = new QCheckBox;
    checkTO->setEnabled(false);
    checkWB = new QCheckBox;
    checkWB->setEnabled(false);
    checkALM = new QCheckBox;
    checkALM->setEnabled(false);
    checkFWD = new QCheckBox;
    checkFWD->setEnabled(false);
    checkREV = new QCheckBox;
    checkREV->setEnabled(false);

    txtMsg = new QTextEdit;
    txtMsg->setReadOnly(true);
    txtMsg->setEnabled(false);

    int h = txtMsg->fontMetrics().lineSpacing();
    h *= 5;
//    h += txtCode->fontMetrics().leading();

    QTextDocument* pdoc = txtMsg->document();
    QMargins margins = txtMsg->contentsMargins();
    h += static_cast<int>(pdoc->documentMargin()) + margins.top() + margins.bottom();

    txtMsg->setFixedHeight(h);

    //
    QGridLayout *gridLS = new QGridLayout;

#ifndef STONE
    gridLS->addWidget(labelTO, 0, 0, Qt::AlignCenter);
    gridLS->addWidget(checkTO, 1, 0, Qt::AlignCenter);

    gridLS->addWidget(labelFB, 0, 1, Qt::AlignCenter);
    gridLS->addWidget(checkFB, 1, 1, Qt::AlignCenter);
#endif

    gridLS->addWidget(labelPWR, 0, 2, Qt::AlignCenter);
    gridLS->addWidget(checkPWR, 1, 2, Qt::AlignCenter);

    gridLS->addWidget(labelWB, 0, 3, Qt::AlignCenter);
    gridLS->addWidget(checkWB, 1, 3, Qt::AlignCenter);

    gridLS->addWidget(labelALM, 0, 4, Qt::AlignCenter);
    gridLS->addWidget(checkALM, 1, 4, Qt::AlignCenter);

    gridLS->addWidget(labelREV, 0, 5, Qt::AlignCenter);
    gridLS->addWidget(checkREV, 1, 5, Qt::AlignCenter);

    gridLS->addWidget(labelFWD, 0, 6, Qt::AlignCenter);
    gridLS->addWidget(checkFWD, 1, 6, Qt::AlignCenter);

    QGridLayout *gridState = new QGridLayout;
    gridState->addLayout(gridLS, 0, 2, 1, 2);
    gridState->addWidget(groupLabelNum(labelSpeed, fnumSpeed), 1, 0);
    gridState->addWidget(groupLabelNum(labelVolt, fnumVolt), 1, 1);
    gridState->addWidget(groupLabelNum(labelX, fnumX), 1, 2);
    gridState->addWidget(groupLabelNum(labelY, fnumY), 1, 3);
//    gridState->addWidget(new QFrame, 1, 1);
//    gridState->addWidget(new QFrame, 0, 2, 2, 1);

    QGridLayout *gridMsgState = new QGridLayout;
    gridMsgState->addWidget(txtMsg, 0, 0);
    gridMsgState->addLayout(gridState, 0, 1, Qt::AlignRight | Qt::AlignBottom);

    //
    emptyPlot();

    mainLayout = new QGridLayout;

    mainLayout->addLayout(gridControl, 0, 0, Qt::AlignLeft | Qt::AlignTop);
//    mainLayout->addWidget(new QFrame, 1, 0);

    mainLayout->addWidget(qwtPlot, 0, 1);

    mainLayout->addLayout(gridMsgState, 1, 1);

    this->setLayout(mainLayout);

//    connect(fnumRadius, QOverload<double>::of(&QDoubleSpinBox::valueChanged), this, [=](double) {
//        emptyPlot();
//    });
}

void CenterWidget::createSpeed() {
    labelCoarseSpeed = new QLabel(tr("Coarse speed") + ": ");
    fnumSpeedCoarse = new QDoubleSpinBox;
//    fnumSpeedCoarse->setRange(0, 18);
//    fnumSpeedCoarse->setSingleStep(0.1);
//    fnumSpeedCoarse->setDecimals(1);
//    fnumSpeedCoarse->setValue(18);
    fnumSpeedCoarse->setAccelerated(true);

    labelFineSpeed = new QLabel(tr("Fine speed") + ": ");
    fnumSpeedFine = new QDoubleSpinBox;
//    fnumSpeedFine->setRange(0, 18);
//    fnumSpeedFine->setSingleStep(0.1);
//    fnumSpeedFine->setDecimals(1);
//    fnumSpeedFine->setValue(1.8);
    fnumSpeedFine->setAccelerated(true);

    speedMMM = new QRadioButton(tr("mm/min"));
    speedUMS = new QRadioButton(tr("um/sec"));

    groupSpeed = new QGroupBox;
    groupSpeed->setLayout(new QHBoxLayout);
    groupSpeed->layout()->addWidget(speedMMM);
    groupSpeed->layout()->addWidget(speedUMS);

    groupSpeed->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

    gridSpeed = new QGridLayout;
    gridSpeed->addWidget(groupLabelNum(labelCoarseSpeed, fnumSpeedCoarse), 0, 0);
    gridSpeed->addWidget(groupLabelNum(labelFineSpeed, fnumSpeedFine), 1, 0);
    gridSpeed->addWidget(groupSpeed, 2, 0, Qt::AlignRight);

    connect(speedMMM, &QRadioButton::clicked, this, [&]() {
        if (wireSpeedMode != WireSpeed::Mode::MMM) {
            changeSpinBoxSpeed(fnumSpeed, wireSpeedMode, WireSpeed::Mode::MMM);
            changeSpinBoxSpeed(fnumSpeedCoarse, wireSpeedMode, WireSpeed::Mode::MMM);
            changeSpinBoxSpeed(fnumSpeedFine, wireSpeedMode, WireSpeed::Mode::MMM);
            wireSpeedMode = WireSpeed::Mode::MMM;
        }
    });
    connect(speedUMS, &QRadioButton::clicked, this, [&]() {
        if (wireSpeedMode != WireSpeed::Mode::UMS) {
            changeSpinBoxSpeed(fnumSpeed, wireSpeedMode, WireSpeed::Mode::UMS);
            changeSpinBoxSpeed(fnumSpeedCoarse, wireSpeedMode, WireSpeed::Mode::UMS);
            changeSpinBoxSpeed(fnumSpeedFine, wireSpeedMode, WireSpeed::Mode::UMS);
            wireSpeedMode = WireSpeed::Mode::UMS;
        }
    });

    speedMMM->click();
}

void CenterWidget::changeSpinBoxSpeed(QDoubleSpinBox*& fnumSpeed, WireSpeed::Mode cur_mode, WireSpeed::Mode new_mode) {
    if (new_mode == cur_mode)
        return;

    switch (new_mode) {
    case WireSpeed::Mode::MMM: {
        WireSpeed speed(fnumSpeed->value(), WireSpeed::Mode::UMS);
        speed.changeMode(WireSpeed::Mode::MMM);
        fnumSpeed->setRange(speed.min(), speed.max());
        fnumSpeed->setValue(speed.get());
        fnumSpeed->setSingleStep(0.1);
        fnumSpeed->setDecimals(2);
        fnumSpeed->setSuffix(" " + tr("mm/min"));
    }
        break;

    case WireSpeed::Mode::UMS: {
        WireSpeed speed(fnumSpeed->value(), WireSpeed::Mode::MMM);
        speed.changeMode(WireSpeed::Mode::UMS);
        fnumSpeed->setRange(speed.min(), speed.max());
        fnumSpeed->setValue(speed.get());
        fnumSpeed->setSingleStep(1);
        fnumSpeed->setDecimals(1);
        fnumSpeed->setSuffix(" " + tr("um/sec"));
    }
        break;
    }
}

QGroupBox* CenterWidget::groupLabelNum(QLabel* label, QAbstractSpinBox* num) {
    QGroupBox* group = new QGroupBox;
    label->setBuddy(num);
    group->setLayout(new QHBoxLayout);
    group->layout()->addWidget(label);
    group->layout()->addWidget(num);
    groupSpeed->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    return group;
}

CenterWidget::~CenterWidget() {
//    delete qwtPlot;
}

// times
int CenterWidget::attempts() const { return numAttempts->value(); }
// mm
double CenterWidget::radius() const { return fnumRadius->value(); }
// mm
double CenterWidget::rollback() const { return fnumRollback->value(); }
// %
int CenterWidget::fineZonePct() const { return numFineZone->value(); }
// grade
int CenterWidget::drumVel() const { return numDrumVel->value(); }

// mm/min
double CenterWidget::speedCoarse() const {
    double value = fnumSpeedCoarse->value();
    if (speedUMS->isChecked())
        value = CncParam::ums_to_mmm(value);
    return value;
}
// mm/min
double CenterWidget::speedFine() const {
    double value = fnumSpeedFine->value();
    if (speedUMS->isChecked())
        value = CncParam::ums_to_mmm(value);
    return value;
}
// V
int CenterWidget::thresholdLow() const { return numLowThld->value(); }
// V
int CenterWidget::thresholdHigh() const { return numHighThld->value(); }

// Limit switches
void CenterWidget::setLimitSwitches(CncLimitSwitches ls) {
    checkFWD->setChecked(ls.limsw_fwd);
    checkREV->setChecked(ls.limsw_rev);
    checkALM->setChecked(ls.limsw_alm);
    checkWB->setChecked(ls.wire_break);
    checkPWR->setChecked(ls.pwr);
    checkFB->setChecked(ls.fb);
    checkTO->setChecked(ls.fb_to);
}

void CenterWidget::setLimitSwitches(bool fwd, bool rev, bool alarm, bool wire_break, bool pwr, bool feedback, bool fb_timeout) {
    CncLimitSwitches ls;

    ls.limsw_fwd = fwd;
    ls.limsw_rev = rev;
    ls.limsw_alm = alarm;
    ls.wire_break = wire_break;
    ls.pwr = pwr;
    ls.fb = feedback;
    ls.fb_to = fb_timeout;
    ls.res = 0;

    setLimitSwitches(ls);
}

void CenterWidget::setX(int32_t value) {
    fnumX->setValue(value * (1.0 / X_SCALE));
}

void CenterWidget::setY(int32_t value) {
    fnumX->setValue(value * (1.0 / Y_SCALE));
}

// ADC
void CenterWidget::setAdc(double value) {
    fnumVolt->setValue(round(value));
}

void CenterWidget::setAdc(const cnc_adc_volt_t &adc) {
    setAdc(adc.diff.value);
}

// mm/min
void CenterWidget::setSpeed(double F) {
    WireSpeed speed(F);
    speed.changeMode(wireSpeedMode);

    if (speed.get() < speed.min()) {
        fnumSpeed->setValue(speed.min());
        qDebug("Error: MIN CNC Speed: %f", F);
    }
    else if (speed.get() > speed.max()) {
        fnumSpeed->setValue(speed.max());
        qDebug("Error: MAX CNC Speed: %f", F);
    }
    else
        fnumSpeed->setValue(speed.get());
}

// Plot
void CenterWidget::emptyPlot() {
    if (!qwtPlot) return;

    m_pts.clear();
    qwtPlot->detachItems();
//    tweakPlot();
    qwtPlot->replot();
}

void CenterWidget::addPlot(int x, int y, const QColor& color, const QColor& tipColor, int width, Qt::PenStyle style) {
    if (!m_pts.empty()) {
        int x_last = round(m_pts.back().x() * X_SCALE);
        int y_last = round(m_pts.back().y() * Y_SCALE);

        if (x == x_last && y == y_last)
            return;
    }

    QPointF pt = {x * (1.0 / X_SCALE), y * (1.0 / Y_SCALE)};

    qwtPlot->detachItems();
    m_pts.push_back(pt);

    {
        QwtPlotCurve* curve = new QwtPlotCurve;
        curve->setPen(color, width, style);
        curve->setRenderHint(QwtPlotItem::RenderAntialiased, true);

        curve->setSamples(m_pts);

        curve->attach(qwtPlot);
    }

    {
        QwtPlotCurve* curve = new QwtPlotCurve;
        curve->setPen(tipColor, width);
        curve->setRenderHint(QwtPlotItem::RenderAntialiased, true);

        QwtSymbol* symbol = new QwtSymbol( QwtSymbol::Style::Ellipse, QBrush(tipColor), QPen(tipColor, width), QSize(width, width) );
        curve->setSymbol(symbol);

        curve->setSamples( {pt} );
        curve->attach(qwtPlot);
    }

    tweakPlot();

    qwtPlot->replot();
}

void CenterWidget::tweakPlot() {
    QwtPlotGrid* grid = new QwtPlotGrid;
    grid->setMajorPen(QPen( Qt::gray, 1 ));
    grid->setMinorPen(Qt::black, 1, Qt::PenStyle::DotLine);
    grid->enableXMin(true);
    grid->enableYMin(true);
    grid->attach(qwtPlot);

//    double R = fabs(fnumRadius->value());
//    double step = calcPlotStep(-R, R, 10);
//    QPointF pt0 = m_pts.empty() ? QPointF(0,0) : m_pts.front();

//    qwtPlot->setAxisScale(QwtPlot::xBottom, pt0.x() - R, pt0.x() + R, step);
//    qwtPlot->setAxisScale(QwtPlot::yLeft, pt0.y() - R, pt0.y() + R, step);

    qwtPlot->setAxisTitle(QwtPlot::Axis::xBottom, "X");
    qwtPlot->setAxisTitle(QwtPlot::Axis::yLeft, "Y");

    QwtPlotRescaler* rescaler = new QwtPlotRescaler( qwtPlot->canvas() );
    rescaler->setReferenceAxis(QwtPlot::xBottom);
//    rescaler->setAspectRatio(QwtPlot::yLeft, 1.0);
    rescaler->setRescalePolicy(QwtPlotRescaler::Fixed);
    rescaler->setEnabled(true);
    rescaler->rescale();
    qwtPlot->plotLayout()->setAlignCanvasToScales(true);

    qwtPlot->updateAxes();
//    plot->updateGeometry();
//    plot->update();
//    plot->show();
}

double CenterWidget::calcPlotStep(double min, double max, size_t n) {
    double w = max - min;
    double step = w / n;

    double e = log10(step);
    e = trunc(e);
    double exp = pow(10, e);

    if (step / exp < 1)
        exp = e < 0 ? exp / 10 : exp * 10;

    step /= exp; // 1..9
    step = ceil(step);
    int step_int = static_cast<int>(step);

    if (step_int == 0)
        return 0; // error
    else if (step_int == 1)
        step = 1;
    else if (step_int == 2)
        step = 2;
    else if (step_int <= 5)
        step = 5;
    else
        step = 10;

    return step * exp;
}

//
void CenterWidget::setFontPointSize(int /*pointSize*/) {

}
