#ifndef DEBUG_H
#define DEBUG_H

#define CONNECTION_ATTEMPTS (1)

#endif // DEBUG_H
