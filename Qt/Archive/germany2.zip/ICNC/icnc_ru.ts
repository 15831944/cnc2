<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>ContourTableModel</name>
    <message>
        <location filename="contour_table_model.cpp" line="51"/>
        <source>XY Plane</source>
        <translation>Плоскость XY</translation>
    </message>
    <message>
        <location filename="contour_table_model.cpp" line="53"/>
        <source>UV Plane</source>
        <translation>Плоскость UV</translation>
    </message>
</context>
<context>
    <name>FormContour</name>
    <message>
        <location filename="form_contour.cpp" line="63"/>
        <location filename="form_contour.cpp" line="118"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="65"/>
        <location filename="form_contour.cpp" line="120"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="68"/>
        <location filename="form_contour.cpp" line="123"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="71"/>
        <location filename="form_contour.cpp" line="126"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="74"/>
        <source>Load XY</source>
        <translation>Загр. XY</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="76"/>
        <source>Load UV</source>
        <translation>Загр. UV</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="79"/>
        <source>Passes</source>
        <translation>Проходы</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="81"/>
        <location filename="form_contour.cpp" line="136"/>
        <source>Generate</source>
        <translation>Генер.</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="98"/>
        <location filename="form_contour.cpp" line="155"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="129"/>
        <source>Load DXF</source>
        <translation>Загр. DXF</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="134"/>
        <source>Adjust</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="137"/>
        <location filename="form_contour.cpp" line="138"/>
        <source>Generate G-code</source>
        <translation>Генерировать G-код</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="200"/>
        <source>Contours</source>
        <translation>Контуры</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="201"/>
        <source>Current</source>
        <translation>Текущий</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="245"/>
        <source>New Contour</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="247"/>
        <source>Add Cutline</source>
        <translation>Линия захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="248"/>
        <source>Add new cutline before first segment</source>
        <translation>Добавить линию захода перед первым сегментом контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="249"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="250"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="260"/>
        <source>First</source>
        <translation>Первый</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="261"/>
        <location filename="form_contour.cpp" line="262"/>
        <source>Set as first segment in contour</source>
        <translation>Сделать первым элементом в контуре</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="263"/>
        <source>Change direction</source>
        <translation>Изменить направление</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="266"/>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="270"/>
        <source>Use as Cutline</source>
        <translation>Использовать как линию захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="271"/>
        <source>Use segment as Cutline</source>
        <translation>Использовать сегмент  как линию захода</translation>
    </message>
    <message>
        <source>Set as Cutline</source>
        <translation type="vanished">Сделать линией захода</translation>
    </message>
    <message>
        <source>Set segment as Cutline</source>
        <translation type="vanished">Сделать сегмент линией захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="272"/>
        <source>Mark as last segment</source>
        <oldsource>Set as last segment</oldsource>
        <translation>Пометить как  выходной сегмент</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="274"/>
        <source>Rotate</source>
        <translation>Поворот</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="275"/>
        <source>Flip Left-Right</source>
        <translation>Перевернуть слева-направо</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="276"/>
        <source>Flip Up-Down</source>
        <translation>Перевернуть сверху-вниз</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="277"/>
        <source>Resize</source>
        <translation>Изменить размер</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="343"/>
        <source>Open DXF file</source>
        <translation>Открыть DXF файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="344"/>
        <source>DXF files</source>
        <translation>Файлы DXF</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="376"/>
        <source>Bottom layer loaded successfully</source>
        <translation>Нижний контур загружен успешно</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="383"/>
        <source>Removed unconnected segments from Dxf</source>
        <translation>Удалены не подсоединенные сегменты из Dxf</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="390"/>
        <source>Removed extra tails from Dxf</source>
        <translation>Удалены лишние хвосты из Dxf</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="397"/>
        <source>Bottom layer DXF segments sorting error</source>
        <translation>Ошибка сортировки нижнего контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="405"/>
        <source>Bottom layer DXF parsing error</source>
        <translation>Ошибка файла нижнего контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="771"/>
        <source>No contour</source>
        <translation>Нет контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="778"/>
        <source>No contour. Only cutline</source>
        <translation>Нет контура. Только линия входа</translation>
    </message>
</context>
<context>
    <name>FormEdit</name>
    <message>
        <location filename="form_edit.cpp" line="75"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="76"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="77"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="78"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="80"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="81"/>
        <source>Plot</source>
        <translation>Чертёж</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="87"/>
        <source>to Contour</source>
        <translation>в Контур</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="102"/>
        <source>Run</source>
        <translation>Запуск</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="103"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <source>Open G-code file</source>
        <translation>Открыть G-код файл</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <location filename="form_edit.cpp" line="295"/>
        <source>G-code files</source>
        <oldsource>G-code (*.nc *.NC)</oldsource>
        <translation>G-код файлы</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation type="vanished">Все файлы (*)</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="293"/>
        <source>Save G-code file</source>
        <translation>Сохранение G-код файла</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="309"/>
        <source>Play</source>
        <translation>Проиграть</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="315"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
</context>
<context>
    <name>FormHelp</name>
    <message>
        <location filename="form_help.cpp" line="32"/>
        <source>Help file is not found</source>
        <oldsource>Help file not found</oldsource>
        <translation>Файл помощи не найден</translation>
    </message>
    <message>
        <location filename="form_help.cpp" line="48"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
</context>
<context>
    <name>FormHome</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Главная панель</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="75"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="78"/>
        <source>Contour</source>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="79"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="80"/>
        <source>Run</source>
        <translation>Пуск</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="81"/>
        <source>Options</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="207"/>
        <source>Serial port is not found</source>
        <translation>Последовательный порт не найден</translation>
    </message>
    <message>
        <source>G-code Recovery</source>
        <translation type="vanished">Восстановить G-код</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="82"/>
        <source>Recovery</source>
        <translation>Восстан.</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="83"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="95"/>
        <source>Test</source>
        <translation>Тест</translation>
    </message>
    <message>
        <source>Minimize Program</source>
        <translation type="vanished">Свернуть программу</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="101"/>
        <source>Minimize</source>
        <translation>Свернуть</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="102"/>
        <source>Shutdown</source>
        <translation>Выкл.</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="104"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="23"/>
        <source>Welcome</source>
        <translation>Приветствие</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="27"/>
        <source>Slicing</source>
        <translation>Нарезка</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="201"/>
        <source>Info</source>
        <oldsource>Info: </oldsource>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Connecting...</source>
        <translation type="vanished">Соединение...</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="201"/>
        <source>Connecting</source>
        <translation>Соединение</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="207"/>
        <location filename="form_home.cpp" line="213"/>
        <source>Error</source>
        <oldsource>Error: </oldsource>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>UART port is not found</source>
        <translation type="vanished">Последовательный порт не найден</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="213"/>
        <source>No connection. Check conection between computer and CNC board</source>
        <translation>Нет соединения. Проверьте соединение между компьютером и платой ЧПУ</translation>
    </message>
    <message>
        <location filename="form_home.h" line="35"/>
        <source>Meatec CNC Machine</source>
        <translation>ЧПУ компании Меатэк</translation>
    </message>
    <message>
        <location filename="form_home.h" line="36"/>
        <source>Application: </source>
        <translation>Приложение: </translation>
    </message>
    <message>
        <location filename="form_home.h" line="36"/>
        <source>from </source>
        <translation>от </translation>
    </message>
    <message>
        <source>MODEL_NAME</source>
        <translation type="vanished">ИМЯ_МОДЕЛИ</translation>
    </message>
    <message>
        <source>Model</source>
        <translation type="vanished">Модель</translation>
    </message>
</context>
<context>
    <name>FormPasses</name>
    <message>
        <location filename="form_passes.cpp" line="15"/>
        <source>Cutting settings</source>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="55"/>
        <source>Left Offset</source>
        <translation>Левое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="56"/>
        <source>Right Offset</source>
        <translation>Правое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="65"/>
        <source>Cut Times</source>
        <translation>Число проходов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="82"/>
        <source>Overlap</source>
        <translation>Перерез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="85"/>
        <location filename="form_passes.cpp" line="108"/>
        <location filename="form_passes.cpp" line="134"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="90"/>
        <source>Tab Width</source>
        <translation>Длина недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="105"/>
        <source>Offset in pass</source>
        <translation>Смещение на проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="114"/>
        <source>Mode in pass</source>
        <translation>Режим на проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="122"/>
        <source>Onepass Cutting</source>
        <translation>Однопроходный рез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="123"/>
        <source>Multipass Cutting</source>
        <translation>Многопроходный рез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="125"/>
        <source>Tab</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="131"/>
        <source>Tab Offset</source>
        <translation>Смещение при недорезе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="139"/>
        <source>Cutline Mode</source>
        <translation>Режим линии захода</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="143"/>
        <source>Tab Mode</source>
        <translation>Режим при недорезе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="147"/>
        <source>Tab Pause</source>
        <translation>Пауза после недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="149"/>
        <source>Pump On Pause</source>
        <oldsource>Pump Delay</oldsource>
        <translation>Задерка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="152"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="156"/>
        <source>Pump On Stop</source>
        <oldsource>Pump Pause</oldsource>
        <translation>Остановка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="330"/>
        <source>Generator Operation Modes</source>
        <translation>Режимы работы генератора</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="342"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="343"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="344"/>
        <location filename="form_passes.cpp" line="528"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="345"/>
        <location filename="form_passes.cpp" line="531"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="347"/>
        <source>Save As</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <source>Factory</source>
        <translation type="vanished">Сброс</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="408"/>
        <source>Open modes file</source>
        <translation>Открыть файл режимов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="410"/>
        <location filename="form_passes.cpp" line="472"/>
        <source>Modes files</source>
        <oldsource>Modes file (*.xmd *.XMD)</oldsource>
        <translation>Файлы режимов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="420"/>
        <source>Modes: Open File Error</source>
        <translation>Режимы: Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="426"/>
        <source>Modes: Parse File Error</source>
        <translation>Режимы: Ошибка разбора файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="460"/>
        <source>Modes: Save File Error</source>
        <translation>Режимы: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="470"/>
        <source>Save modes file</source>
        <translation>Сохранение режимов работы</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="500"/>
        <source>Cutting: Save File Error</source>
        <translation>Рез: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="510"/>
        <source>Save cutting settings</source>
        <translation>Сохранение параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="512"/>
        <source>Cutting settings files</source>
        <oldsource>Cutting settings file (*.xct *.XCT)</oldsource>
        <translation>Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="526"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="534"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="348"/>
        <location filename="form_passes.cpp" line="537"/>
        <source>Default</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="564"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="595"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
</context>
<context>
    <name>FormPassesStone</name>
    <message>
        <location filename="form_passes_stone.cpp" line="15"/>
        <source>Contour Adjustments</source>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="57"/>
        <source>Additional Offset</source>
        <translation>Дополнительное смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="60"/>
        <location filename="form_passes_stone.cpp" line="90"/>
        <location filename="form_passes_stone.cpp" line="133"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="68"/>
        <location filename="form_passes_stone.cpp" line="98"/>
        <source>Left Offset</source>
        <translation>Левое смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="69"/>
        <location filename="form_passes_stone.cpp" line="99"/>
        <source>Right Offset</source>
        <translation>Правое смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="87"/>
        <source>Wire Offset</source>
        <oldsource>Cutting Offset</oldsource>
        <translation>Смещение проволоки</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="130"/>
        <source>Overlapping</source>
        <translation>Перерез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="138"/>
        <source>Tab</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="146"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="148"/>
        <source>Last segment</source>
        <translation>Последний сегмент</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="206"/>
        <source>Tab Pause</source>
        <translation>Остановка перед недорезом</translation>
    </message>
    <message>
        <source>Pump On Delay</source>
        <translation type="vanished">Пауза по вкл. насоса</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="229"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <source>Pump On Pause</source>
        <translation type="vanished">Остановка по вкл. насоса</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="218"/>
        <source>Cutting Speed</source>
        <translation>Скорость реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="221"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="227"/>
        <source>Add pause after each segment</source>
        <translation>Добавить паузу после каждого сегмента</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="712"/>
        <source>Cutting: Save File Error</source>
        <translation>Рез: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="722"/>
        <source>Save cutting settings</source>
        <translation>Сохранение параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="724"/>
        <source>Cutting settings files</source>
        <oldsource>Cutting settings file</oldsource>
        <translation>Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="738"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="740"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="743"/>
        <source>Save</source>
        <translation>Сохранение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="746"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="749"/>
        <source>Default</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="775"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormPult</name>
    <message>
        <location filename="form_pult.cpp" line="18"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="67"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="70"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <source>Wire</source>
        <translation type="vanished">Проволока</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="73"/>
        <source>Break</source>
        <translation>Обрыв</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="77"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="81"/>
        <location filename="form_pult.cpp" line="256"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="85"/>
        <location filename="form_pult.cpp" line="100"/>
        <location filename="form_pult.cpp" line="114"/>
        <location filename="form_pult.cpp" line="128"/>
        <location filename="form_pult.cpp" line="142"/>
        <source>DEC</source>
        <translation>Умен.</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="88"/>
        <location filename="form_pult.cpp" line="107"/>
        <location filename="form_pult.cpp" line="121"/>
        <location filename="form_pult.cpp" line="135"/>
        <location filename="form_pult.cpp" line="149"/>
        <source>INC</source>
        <translation>Увел.</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="92"/>
        <location filename="form_pult.cpp" line="262"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="258"/>
        <source>Width</source>
        <oldsource>Width: </oldsource>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="260"/>
        <source>Ratio</source>
        <oldsource>Ratio: </oldsource>
        <translation>Скважность</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="264"/>
        <source>Current</source>
        <oldsource>Current: </oldsource>
        <translation>Ток</translation>
    </message>
</context>
<context>
    <name>FormRun</name>
    <message>
        <location filename="form_run.cpp" line="78"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="79"/>
        <source>Goto Home panel</source>
        <translation>Переход на главную панель</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="82"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <source>Wire</source>
        <translation type="vanished">Проволока</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="85"/>
        <source>Break</source>
        <translation>Обрыв</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="87"/>
        <source>Wire break control on/off</source>
        <oldsource>Wire control on/off</oldsource>
        <translation>Контроль обрыва проволоки вкл./выкл.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="90"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="92"/>
        <source>Pump on/off</source>
        <translation>Насос вкл./выкл.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="95"/>
        <location filename="form_run.cpp" line="274"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="97"/>
        <source>Wire drum on/off</source>
        <translation>Вращение барабана вкл./выкл.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="100"/>
        <location filename="form_run.cpp" line="117"/>
        <location filename="form_run.cpp" line="131"/>
        <location filename="form_run.cpp" line="145"/>
        <location filename="form_run.cpp" line="159"/>
        <source>DEC</source>
        <translation>Умен.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="101"/>
        <source>Drum velocity decrement</source>
        <translation>Уменьшить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="104"/>
        <location filename="form_run.cpp" line="124"/>
        <location filename="form_run.cpp" line="138"/>
        <location filename="form_run.cpp" line="152"/>
        <location filename="form_run.cpp" line="166"/>
        <source>INC</source>
        <translation>Увел.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="105"/>
        <source>Drum velocity increment</source>
        <translation>Увеличить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="110"/>
        <location filename="form_run.cpp" line="280"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="276"/>
        <source>Width</source>
        <oldsource>Width: </oldsource>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="278"/>
        <source>Ratio</source>
        <oldsource>Ratio: </oldsource>
        <translation>Скважность</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="282"/>
        <source>Current</source>
        <oldsource>Current: </oldsource>
        <translation>Ток</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="453"/>
        <location filename="form_run.cpp" line="465"/>
        <location filename="form_run.cpp" line="476"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="453"/>
        <source>No G-code</source>
        <translation>Нет  G-кода</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="465"/>
        <source>G-code error</source>
        <translation>Ошибка G-код</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="476"/>
        <source>No CNC connection</source>
        <translation>Нет связи с ЧПУ</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="516"/>
        <location filename="form_run.cpp" line="526"/>
        <location filename="form_run.cpp" line="541"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation type="vanished">Реверс</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="516"/>
        <location filename="form_run.cpp" line="526"/>
        <location filename="form_run.cpp" line="541"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="516"/>
        <location filename="form_run.cpp" line="526"/>
        <location filename="form_run.cpp" line="541"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="536"/>
        <location filename="form_run.cpp" line="551"/>
        <location filename="form_run.cpp" line="561"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="556"/>
        <source>Shortcut</source>
        <translation>Коротко</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="566"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
</context>
<context>
    <name>FormSettings</name>
    <message>
        <location filename="form_settings.cpp" line="53"/>
        <source>Options</source>
        <oldsource>&lt;h2&gt;Options&lt;/h2&gt;</oldsource>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="54"/>
        <source>CNC parameters</source>
        <oldsource>&lt;h3&gt;CNC parameters&lt;/h3&gt;</oldsource>
        <translation>Параметры работы ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="65"/>
        <source>Swap plot axes X, Y</source>
        <translation>Поменять местами оси X, Y</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="68"/>
        <source>Inverse axis X</source>
        <translation>Перевернуть ось X</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="71"/>
        <source>Inverse axis Y</source>
        <translation>Перевернуть ось Y</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="74"/>
        <source>Show plot axes</source>
        <translation>Отображать оси на чертеже</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="77"/>
        <source>Input Levels, bits</source>
        <oldsource>Input Levels, bits: </oldsource>
        <translation>Входные уровни, биты</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="90"/>
        <source>Metal</source>
        <translation>Метал</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="91"/>
        <source>Stone</source>
        <translation>Камень</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="95"/>
        <source>Feedback enable</source>
        <translation>Включить обратную связь</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="99"/>
        <source>High threshold</source>
        <translation>Верхний порог</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="100"/>
        <source>Low threshold</source>
        <translation>Нижний порог</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="101"/>
        <source>Rollback timeout</source>
        <translation>Время ожидания отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="102"/>
        <source>Rollback attempts</source>
        <translation>Количество попыток отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="103"/>
        <source>Rollback length</source>
        <translation>Длина отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="104"/>
        <source>Rollback speed</source>
        <translation>Скорость отката</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="112"/>
        <location filename="form_settings.cpp" line="118"/>
        <source>V</source>
        <translation>В</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="123"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="132"/>
        <location filename="form_settings.cpp" line="166"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="139"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="160"/>
        <source>Calculation step</source>
        <translation>Шаг вычислений</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="vanished">Отладка</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="92"/>
        <source>Debug</source>
        <translation>Отладка</translation>
    </message>
    <message>
        <source>Calculation step, mm</source>
        <oldsource>Step, mm: </oldsource>
        <translation type="vanished">Шаг вычислений, мм</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="175"/>
        <source>Precision (steps/mm)</source>
        <oldsource>Scale (steps/mm)</oldsource>
        <translation>Точность (шагов/мм)</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="176"/>
        <source>Motor</source>
        <translation>Двигатель</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="177"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="398"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="401"/>
        <source>Read</source>
        <translation>Чтение</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="404"/>
        <source>Write</source>
        <translation>Запись</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="447"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormTest</name>
    <message>
        <location filename="formtest.ui" line="14"/>
        <source>Form</source>
        <translation>Тест</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="31"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="38"/>
        <source>Quick Test</source>
        <translation>Быстрый</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="45"/>
        <source>Full Test</source>
        <translation>Полный</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="52"/>
        <source>Imitation</source>
        <translation>Иммитация</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="59"/>
        <source>Read CNC</source>
        <translation>Чтение ЧПУ</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="115"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="122"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_test.cpp" line="112"/>
        <location filename="form_test.cpp" line="118"/>
        <source>Error: No G-code program</source>
        <oldsource>Error: No G-code program
</oldsource>
        <translation>Ошибка: Нет программы G-код</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>Главное окно</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="105"/>
        <source>Warning</source>
        <oldsource>Warning: </oldsource>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="110"/>
        <source>Error</source>
        <oldsource>Error: </oldsource>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="143"/>
        <source>Meatec</source>
        <translation>Меатэк</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="205"/>
        <source>Load DXF contours</source>
        <translation>Загрузка контуров DXF</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="211"/>
        <source>Code Editor</source>
        <oldsource>Code Edit Page</oldsource>
        <translation>Редактор G-код</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="246"/>
        <source>Cutting settings</source>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <source>Run Page</source>
        <translation type="vanished">Рабочая панель</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="217"/>
        <source>Job Panel</source>
        <translation>Рабочая панель</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="223"/>
        <source>CNC Settigns</source>
        <translation>Настройки ЧПУ</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="228"/>
        <source>CNC Pult</source>
        <translation>Пульт ЧПУ</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="234"/>
        <source>Test</source>
        <oldsource>Test Page</oldsource>
        <translation>Тестирование</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="241"/>
        <source>Home Panel</source>
        <oldsource>Home Page</oldsource>
        <translation>Главная панель</translation>
    </message>
    <message>
        <source>Passes Panel</source>
        <oldsource>Passes Page</oldsource>
        <translation type="vanished">Панель параметров реза</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="251"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>ModeTableModel</name>
    <message>
        <location filename="mode_table_model.cpp" line="16"/>
        <source>Drum Velocity</source>
        <translation>Скорость барабана</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="17"/>
        <source>Pulse Width</source>
        <translation>Ширина импульсов</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="18"/>
        <source>Pulse Ratio</source>
        <translation>Скважность импульсов</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="19"/>
        <source>Voltage Level</source>
        <translation>Уровень напряжения</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="20"/>
        <source>Current Level</source>
        <translation>Уровень тока</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="27"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
</context>
<context>
    <name>NewCutlineDialog</name>
    <message>
        <location filename="new_cutline_dialog.cpp" line="43"/>
        <source>Abs</source>
        <translation>Абс.</translation>
    </message>
    <message>
        <location filename="new_cutline_dialog.cpp" line="44"/>
        <source>Rel</source>
        <translation>Отн.</translation>
    </message>
    <message>
        <location filename="new_cutline_dialog.cpp" line="88"/>
        <source>New cutline</source>
        <translation>Новая линия захода</translation>
    </message>
</context>
<context>
    <name>PultWidget</name>
    <message>
        <location filename="pult_widget.cpp" line="129"/>
        <location filename="pult_widget.cpp" line="340"/>
        <source>Motor</source>
        <translation>Двигатель</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="130"/>
        <location filename="pult_widget.cpp" line="341"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="131"/>
        <location filename="pult_widget.cpp" line="520"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="132"/>
        <location filename="pult_widget.cpp" line="521"/>
        <source>steps</source>
        <translation>шагов</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="209"/>
        <source>Diff.</source>
        <translation>Диф.</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="210"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="211"/>
        <source>Workpiece</source>
        <translation>Заготовка</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="212"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="213"/>
        <source>HV</source>
        <translation>ВН</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="214"/>
        <source>Shunt</source>
        <translation>Шунт</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="243"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="246"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="339"/>
        <source>Scale (steps/mm)</source>
        <translation>Масштаб (шагов/мм)</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="352"/>
        <source>Move</source>
        <translation>Ехать</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="353"/>
        <source>Set</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="354"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="533"/>
        <source>Speed</source>
        <oldsource>Speed:</oldsource>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="539"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="540"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="40"/>
        <source>Meatec CNC</source>
        <translation>ЧПУ Меатэк</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="516"/>
        <source>CNC</source>
        <translation>ЧПУ</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="517"/>
        <source>from</source>
        <translation>от</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="519"/>
        <source>at</source>
        <translation>на</translation>
    </message>
    <message>
        <location filename="cnc.cpp" line="521"/>
        <source>MHz</source>
        <translation>МГц</translation>
    </message>
    <message>
        <location filename="fpga.cpp" line="162"/>
        <source>FPGA</source>
        <translation>ПЛИС</translation>
    </message>
</context>
<context>
    <name>ResizeDialog</name>
    <message>
        <location filename="resize_dialog.cpp" line="4"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="5"/>
        <source>Height</source>
        <translation>Высота</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="6"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="7"/>
        <source>New size</source>
        <translation>Новый размер</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="19"/>
        <location filename="resize_dialog.cpp" line="26"/>
        <location filename="resize_dialog.cpp" line="33"/>
        <location filename="resize_dialog.cpp" line="40"/>
        <location filename="resize_dialog.cpp" line="96"/>
        <location filename="resize_dialog.cpp" line="103"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="88"/>
        <source>Center</source>
        <translation>Центр</translation>
    </message>
    <message>
        <location filename="resize_dialog.cpp" line="138"/>
        <source>Resize</source>
        <translation>Изменение размеров</translation>
    </message>
</context>
<context>
    <name>RotateDialog</name>
    <message>
        <location filename="rotate_dialog.cpp" line="5"/>
        <source>Angle</source>
        <translation>Угол</translation>
    </message>
    <message>
        <location filename="rotate_dialog.cpp" line="51"/>
        <source>Rotate</source>
        <translation>Поворот</translation>
    </message>
</context>
<context>
    <name>RunWidget</name>
    <message>
        <location filename="run_widget.cpp" line="44"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="46"/>
        <source>Holding of stepper motors on/off</source>
        <translation>Удержание шаговых двигателей вкл./выкл.</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="49"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation type="vanished">Реверс</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="49"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="49"/>
        <location filename="run_widget.cpp" line="187"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="51"/>
        <source>Speed</source>
        <oldsource>Speed:</oldsource>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="57"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="58"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="60"/>
        <source>Idle run</source>
        <translation>Холостой ход</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="120"/>
        <source>Time</source>
        <translation>Прошло</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="121"/>
        <source>Remain</source>
        <translation>Осталось</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="186"/>
        <source>Diff.</source>
        <translation>Диф.</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="188"/>
        <source>Workpiece</source>
        <translation>Заготовка</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="189"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="190"/>
        <source>HV</source>
        <translation>ВН</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="191"/>
        <source>Shunt</source>
        <translation>Шунт</translation>
    </message>
</context>
<context>
    <name>SlicingWidget</name>
    <message>
        <location filename="slicing_widget.cpp" line="9"/>
        <source>Workpiece slicing</source>
        <translation>Нарезка заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="10"/>
        <source>Wire diameter</source>
        <translation>Диаметр проволоки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="11"/>
        <location filename="slicing_widget.cpp" line="128"/>
        <source>Workpiece width</source>
        <translation>Ширина заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="12"/>
        <source>Spacing</source>
        <translation>Свободное пространство</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="13"/>
        <source>Slicing step</source>
        <translation>Шаг нарезки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="14"/>
        <source>Slices number</source>
        <translation>Количество частей</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="15"/>
        <source>Sections number in the speed profile</source>
        <translation>Количество участков в профиле скорости</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="16"/>
        <location filename="slicing_widget.cpp" line="129"/>
        <source>Speed</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="23"/>
        <location filename="slicing_widget.cpp" line="31"/>
        <location filename="slicing_widget.cpp" line="39"/>
        <location filename="slicing_widget.cpp" line="47"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="55"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="75"/>
        <source>Workpiece profile</source>
        <translation>Профиль заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="76"/>
        <source>Rectangle</source>
        <translation>Прямоугольный</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="77"/>
        <source>Circle</source>
        <translation>Круглый</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="87"/>
        <source>Generate</source>
        <translation>Генерировать</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="134"/>
        <source>Workpiece diameter</source>
        <translation>Диаметр заготовки</translation>
    </message>
    <message>
        <location filename="slicing_widget.cpp" line="135"/>
        <source>Average speed</source>
        <translation>Средняя скорость</translation>
    </message>
</context>
</TS>
