<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>ContourTableModel</name>
    <message>
        <location filename="contour_table_model.cpp" line="44"/>
        <source>XY Plane</source>
        <translation>Плоскость XY</translation>
    </message>
    <message>
        <location filename="contour_table_model.cpp" line="46"/>
        <source>UV Plane</source>
        <translation>Плоскость UV</translation>
    </message>
</context>
<context>
    <name>FormContour</name>
    <message>
        <location filename="form_contour.cpp" line="60"/>
        <location filename="form_contour.cpp" line="115"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="62"/>
        <location filename="form_contour.cpp" line="117"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="65"/>
        <location filename="form_contour.cpp" line="120"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="68"/>
        <location filename="form_contour.cpp" line="123"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="71"/>
        <source>Load XY</source>
        <translation>Загр. XY</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="73"/>
        <source>Load UV</source>
        <translation>Загр. UV</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="76"/>
        <source>Passes</source>
        <translation>Проходы</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="78"/>
        <location filename="form_contour.cpp" line="133"/>
        <source>Generate</source>
        <translation>Генер.</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="95"/>
        <location filename="form_contour.cpp" line="152"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="126"/>
        <source>Load DXF</source>
        <translation>Загр. DXF</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="131"/>
        <source>Adjust</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="134"/>
        <location filename="form_contour.cpp" line="135"/>
        <source>Generate G-code</source>
        <translation>Генерировать G-код</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="197"/>
        <source>Contours</source>
        <translation>Контуры</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="198"/>
        <source>Current</source>
        <translation>Текущий</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="228"/>
        <source>New Contour</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="230"/>
        <source>Add Cutline</source>
        <translation>Линия захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="231"/>
        <source>Add new cutline before first segment</source>
        <translation>Добавить линию захода перед первым сегментом контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="232"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="233"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="243"/>
        <source>First</source>
        <translation>Первый</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="244"/>
        <location filename="form_contour.cpp" line="245"/>
        <source>Set as first segment in contour</source>
        <translation>Сделать первым элементом в контуре</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="246"/>
        <source>Change direction</source>
        <translation>Изменить направление</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="249"/>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="253"/>
        <source>Set as Cutline</source>
        <translation>Сделать линией захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="254"/>
        <source>Set segment as Cutline</source>
        <translation>Сделать сегмент линией захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="255"/>
        <source>Mark as last segment</source>
        <oldsource>Set as last segment</oldsource>
        <translation>Пометить как  выходной сегмент</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="308"/>
        <source>Open DXF file</source>
        <translation>Открыть DXF файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="309"/>
        <source>DXF files</source>
        <translation>Файлы DXF</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="341"/>
        <source>Bottom layer loaded successfully</source>
        <translation>Нижний контур загружен успешно</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="344"/>
        <source>Bottom layer DXF segments sorting error</source>
        <translation>Ошибка сортировки нижнего контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="352"/>
        <source>Bottom layer DXF parsing error</source>
        <translation>Ошибка файла нижнего контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="608"/>
        <source>No contour</source>
        <translation>Нет контура</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="615"/>
        <source>No contour. Only cutline</source>
        <translation>Нет контура. Только линия входа</translation>
    </message>
</context>
<context>
    <name>FormEdit</name>
    <message>
        <location filename="form_edit.cpp" line="75"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="76"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="77"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="78"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="80"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="81"/>
        <source>Plot</source>
        <translation>Чертёж</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="87"/>
        <source>to Contour</source>
        <translation>в Контур</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="102"/>
        <source>Run</source>
        <translation>Запуск</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="103"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <source>Open G-code file</source>
        <translation>Открыть G-код файл</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="172"/>
        <location filename="form_edit.cpp" line="295"/>
        <source>G-code files</source>
        <oldsource>G-code (*.nc *.NC)</oldsource>
        <translation>G-код файлы</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation type="vanished">Все файлы (*)</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="293"/>
        <source>Save G-code file</source>
        <translation>Сохранение G-код файла</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="309"/>
        <source>Play</source>
        <translation>Проиграть</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="315"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
</context>
<context>
    <name>FormHelp</name>
    <message>
        <location filename="form_help.cpp" line="32"/>
        <source>Help file not found</source>
        <translation>Файл помощи не найден</translation>
    </message>
    <message>
        <location filename="form_help.cpp" line="48"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
</context>
<context>
    <name>FormHome</name>
    <message>
        <location filename="formhome.ui" line="14"/>
        <source>Form</source>
        <translation>Главная панель</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="89"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="96"/>
        <source>Contour</source>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="103"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="110"/>
        <source>Run</source>
        <translation>Пуск</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="123"/>
        <source>Options</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="133"/>
        <location filename="formhome.ui" line="139"/>
        <location filename="formhome.ui" line="142"/>
        <source>G-code Recovery</source>
        <translation>Восстановить G-код</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="145"/>
        <source>Recovery</source>
        <translation>Восстан.</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="158"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="195"/>
        <source>Test</source>
        <translation>Тест</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="205"/>
        <source>Minimize Program</source>
        <translation>Свернуть программу</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="208"/>
        <source>Minimize</source>
        <translation>Свернуть</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="218"/>
        <source>Shutdown</source>
        <translation>Выкл.</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="228"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="33"/>
        <source>Welcome</source>
        <translation>Приветствие</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="121"/>
        <source>Info</source>
        <oldsource>Info: </oldsource>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Connecting...</source>
        <translation type="vanished">Соединение...</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="121"/>
        <source>Connecting</source>
        <translation>Соединение</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="127"/>
        <location filename="form_home.cpp" line="133"/>
        <source>Error</source>
        <oldsource>Error: </oldsource>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="127"/>
        <source>UART port is not found</source>
        <translation>Последовательный порт не найден</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="133"/>
        <source>No connection. Check conection between computer and CNC board</source>
        <translation>Нет соединения. Проверьте соединение между компьютером и платой ЧПУ</translation>
    </message>
    <message>
        <location filename="form_home.h" line="17"/>
        <source>Meatec CNC Machine</source>
        <translation>ЧПУ компании Меатэк</translation>
    </message>
    <message>
        <location filename="form_home.h" line="18"/>
        <source>MODEL_NAME</source>
        <translation>ИМЯ_МОДЕЛИ</translation>
    </message>
    <message>
        <source>Model</source>
        <translation type="vanished">Модель</translation>
    </message>
</context>
<context>
    <name>FormPasses</name>
    <message>
        <location filename="form_passes.cpp" line="15"/>
        <source>Cutting settings</source>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="55"/>
        <source>Left Offset</source>
        <translation>Левое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="56"/>
        <source>Right Offset</source>
        <translation>Правое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="65"/>
        <source>Cut Times</source>
        <translation>Число проходов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="82"/>
        <source>Overlap</source>
        <translation>Перерез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="85"/>
        <location filename="form_passes.cpp" line="108"/>
        <location filename="form_passes.cpp" line="134"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="90"/>
        <source>Tab Width</source>
        <translation>Длина недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="105"/>
        <source>Offset in pass</source>
        <translation>Смещение на проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="114"/>
        <source>Mode in pass</source>
        <translation>Режим на проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="122"/>
        <source>Onepass Cutting</source>
        <translation>Однопроходный рез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="123"/>
        <source>Multipass Cutting</source>
        <translation>Многопроходный рез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="125"/>
        <source>Tab</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="131"/>
        <source>Tab Offset</source>
        <translation>Смещение при недорезе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="139"/>
        <source>Cutline Mode</source>
        <translation>Режим линии захода</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="143"/>
        <source>Tab Mode</source>
        <translation>Режим при недорезе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="147"/>
        <source>Tab Pause</source>
        <translation>Пауза после недореза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="149"/>
        <source>Pump On Pause</source>
        <oldsource>Pump Delay</oldsource>
        <translation>Задерка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="152"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="156"/>
        <source>Pump On Stop</source>
        <oldsource>Pump Pause</oldsource>
        <translation>Остановка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="330"/>
        <source>Generator Operation Modes</source>
        <translation>Режимы работы генератора</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="342"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="343"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="344"/>
        <location filename="form_passes.cpp" line="528"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="345"/>
        <location filename="form_passes.cpp" line="531"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="347"/>
        <source>Save As</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <source>Factory</source>
        <translation type="vanished">Сброс</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="408"/>
        <source>Open modes file</source>
        <translation>Открыть файл режимов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="410"/>
        <location filename="form_passes.cpp" line="472"/>
        <source>Modes files</source>
        <oldsource>Modes file (*.xmd *.XMD)</oldsource>
        <translation>Файлы режимов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="420"/>
        <source>Modes: Open File Error</source>
        <translation>Режимы: Ошибка открытия файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="426"/>
        <source>Modes: Parse File Error</source>
        <translation>Режимы: Ошибка разбора файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="460"/>
        <source>Modes: Save File Error</source>
        <translation>Режимы: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="470"/>
        <source>Save modes file</source>
        <translation>Сохранение режимов работы</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="500"/>
        <source>Cutting: Save File Error</source>
        <translation>Рез: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="510"/>
        <source>Save cutting settings</source>
        <translation>Сохранение параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="512"/>
        <source>Cutting settings files</source>
        <oldsource>Cutting settings file (*.xct *.XCT)</oldsource>
        <translation>Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="526"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="534"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="348"/>
        <location filename="form_passes.cpp" line="537"/>
        <source>Default</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="564"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="595"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
</context>
<context>
    <name>FormPassesStone</name>
    <message>
        <location filename="form_passes_stone.cpp" line="15"/>
        <source>Contour Adjustments</source>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="57"/>
        <source>Additional Offset</source>
        <translation>Дополнительное смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="60"/>
        <location filename="form_passes_stone.cpp" line="90"/>
        <location filename="form_passes_stone.cpp" line="133"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="68"/>
        <location filename="form_passes_stone.cpp" line="98"/>
        <source>Left Offset</source>
        <translation>Левое смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="69"/>
        <location filename="form_passes_stone.cpp" line="99"/>
        <source>Right Offset</source>
        <translation>Правое смещение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="87"/>
        <source>Wire Offset</source>
        <oldsource>Cutting Offset</oldsource>
        <translation>Смещение проволоки</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="130"/>
        <source>Overlapping</source>
        <translation>Перерез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="138"/>
        <source>Tab</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="146"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="148"/>
        <source>Last segment</source>
        <translation>Последний сегмент</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="206"/>
        <source>Tab Pause</source>
        <translation>Остановка перед недорезом</translation>
    </message>
    <message>
        <source>Pump On Delay</source>
        <translation type="vanished">Пауза по вкл. насоса</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="229"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <source>Pump On Pause</source>
        <translation type="vanished">Остановка по вкл. насоса</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="218"/>
        <source>Cutting Speed</source>
        <translation>Скорость реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="221"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="227"/>
        <source>Add pause after each segment</source>
        <translation>Добавить паузу после каждого сегмента</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="704"/>
        <source>Cutting: Save File Error</source>
        <translation>Рез: Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="714"/>
        <source>Save cutting settings</source>
        <translation>Сохранение параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="716"/>
        <source>Cutting settings files</source>
        <oldsource>Cutting settings file</oldsource>
        <translation>Файлы параметров реза</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="730"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="732"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="735"/>
        <source>Save</source>
        <translation>Сохранение</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="738"/>
        <source>Save as</source>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="741"/>
        <source>Default</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="form_passes_stone.cpp" line="767"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormPult</name>
    <message>
        <location filename="form_pult.cpp" line="18"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="67"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="70"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="73"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="77"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="81"/>
        <location filename="form_pult.cpp" line="256"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="85"/>
        <location filename="form_pult.cpp" line="100"/>
        <location filename="form_pult.cpp" line="114"/>
        <location filename="form_pult.cpp" line="128"/>
        <location filename="form_pult.cpp" line="142"/>
        <source>DEC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="88"/>
        <location filename="form_pult.cpp" line="107"/>
        <location filename="form_pult.cpp" line="121"/>
        <location filename="form_pult.cpp" line="135"/>
        <location filename="form_pult.cpp" line="149"/>
        <source>INC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="92"/>
        <location filename="form_pult.cpp" line="262"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="258"/>
        <source>Width</source>
        <oldsource>Width: </oldsource>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="260"/>
        <source>Ratio</source>
        <oldsource>Ratio: </oldsource>
        <translation>Скважность</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="264"/>
        <source>Current</source>
        <oldsource>Current: </oldsource>
        <translation>Ток</translation>
    </message>
</context>
<context>
    <name>FormRun</name>
    <message>
        <location filename="form_run.cpp" line="78"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="79"/>
        <source>Goto Home panel</source>
        <translation>Переход на главную панель</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="82"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="85"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="87"/>
        <source>Wire control on/off</source>
        <translation>Контроль обрыва проволоки вкл./выкл.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="90"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="92"/>
        <source>Pump on/off</source>
        <translation>Насос вкл./выкл.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="95"/>
        <location filename="form_run.cpp" line="274"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="97"/>
        <source>Wire drum on/off</source>
        <translation>Вращение барабана вкл./выкл.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="100"/>
        <location filename="form_run.cpp" line="117"/>
        <location filename="form_run.cpp" line="131"/>
        <location filename="form_run.cpp" line="145"/>
        <location filename="form_run.cpp" line="159"/>
        <source>DEC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="101"/>
        <source>Drum velocity decrement</source>
        <translation>Уменьшить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="104"/>
        <location filename="form_run.cpp" line="124"/>
        <location filename="form_run.cpp" line="138"/>
        <location filename="form_run.cpp" line="152"/>
        <location filename="form_run.cpp" line="166"/>
        <source>INC</source>
        <translation></translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="105"/>
        <source>Drum velocity increment</source>
        <translation>Увеличить скорость барабана</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="110"/>
        <location filename="form_run.cpp" line="280"/>
        <source>Voltage</source>
        <translation>Напряжение</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="276"/>
        <source>Width</source>
        <oldsource>Width: </oldsource>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="278"/>
        <source>Ratio</source>
        <oldsource>Ratio: </oldsource>
        <translation>Скважность</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="282"/>
        <source>Current</source>
        <oldsource>Current: </oldsource>
        <translation>Ток</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="444"/>
        <location filename="form_run.cpp" line="456"/>
        <location filename="form_run.cpp" line="467"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="444"/>
        <source>No G-code</source>
        <translation>Нет G-код</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="456"/>
        <source>G-code error</source>
        <translation>Ошибка G-код</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="467"/>
        <source>No CNC connection</source>
        <translation>Нет связи с ЧПУ</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="506"/>
        <location filename="form_run.cpp" line="516"/>
        <location filename="form_run.cpp" line="531"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="506"/>
        <location filename="form_run.cpp" line="516"/>
        <location filename="form_run.cpp" line="531"/>
        <source>Reverse</source>
        <translation>Реверс</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="506"/>
        <location filename="form_run.cpp" line="516"/>
        <location filename="form_run.cpp" line="531"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="526"/>
        <location filename="form_run.cpp" line="541"/>
        <location filename="form_run.cpp" line="551"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="546"/>
        <source>Shortcut</source>
        <translation>Коротко</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="556"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
</context>
<context>
    <name>FormSettings</name>
    <message>
        <location filename="form_settings.cpp" line="53"/>
        <source>Options</source>
        <oldsource>&lt;h2&gt;Options&lt;/h2&gt;</oldsource>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="54"/>
        <source>CNC parameters</source>
        <oldsource>&lt;h3&gt;CNC parameters&lt;/h3&gt;</oldsource>
        <translation>Параметры работы ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="65"/>
        <source>Input Levels, bits</source>
        <oldsource>Input Levels, bits: </oldsource>
        <translation>Входные уровни, биты</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="78"/>
        <source>Metal</source>
        <translation>Метал</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="79"/>
        <source>Stone</source>
        <translation>Камень</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="vanished">Отладка</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="80"/>
        <source>Debug</source>
        <translation>Отладка</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="82"/>
        <source>Calculation step, mm</source>
        <oldsource>Step, mm: </oldsource>
        <translation>Шаг вычислений, мм</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="96"/>
        <source>Precision (steps/mm)</source>
        <oldsource>Scale (steps/mm)</oldsource>
        <translation>Точность (шагов/мм)</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="97"/>
        <source>Motor</source>
        <translation>Двигатель</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="98"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="270"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="273"/>
        <source>Read</source>
        <translation>Чтение</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="276"/>
        <source>Write</source>
        <translation>Запись</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="319"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormTest</name>
    <message>
        <location filename="formtest.ui" line="14"/>
        <source>Form</source>
        <translation>Тест</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="31"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="38"/>
        <source>Quick Test</source>
        <translation>Быстрый</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="45"/>
        <source>Full Test</source>
        <translation>Полный</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="52"/>
        <source>Imitation</source>
        <translation>Иммитация</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="59"/>
        <source>Read CNC</source>
        <translation>Чтение ЧПУ</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="115"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="122"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_test.cpp" line="112"/>
        <location filename="form_test.cpp" line="118"/>
        <source>Error: No G-code program</source>
        <oldsource>Error: No G-code program
</oldsource>
        <translation>Ошибка: Нет программы G-код</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>Главное окно</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="105"/>
        <source>Warning</source>
        <oldsource>Warning: </oldsource>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="110"/>
        <source>Error</source>
        <oldsource>Error: </oldsource>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="143"/>
        <source>Meatec</source>
        <translation>Меатэк</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="205"/>
        <source>Load DXF contours</source>
        <translation>Загрузка контуров DXF</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="211"/>
        <source>Code Editor</source>
        <oldsource>Code Edit Page</oldsource>
        <translation>Редактор G-код</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="246"/>
        <source>Cutting settings</source>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <source>Run Page</source>
        <translation type="vanished">Рабочая панель</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="217"/>
        <source>Job Panel</source>
        <translation>Рабочая панель</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="223"/>
        <source>CNC Settigns</source>
        <translation>Настройки ЧПУ</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="228"/>
        <source>CNC Pult</source>
        <translation>Пульт ЧПУ</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="234"/>
        <source>Test</source>
        <oldsource>Test Page</oldsource>
        <translation>Тестирование</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="241"/>
        <source>Home Panel</source>
        <oldsource>Home Page</oldsource>
        <translation>Главная панель</translation>
    </message>
    <message>
        <source>Passes Panel</source>
        <oldsource>Passes Page</oldsource>
        <translation type="vanished">Панель параметров реза</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="251"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>ModeTableModel</name>
    <message>
        <location filename="mode_table_model.cpp" line="16"/>
        <source>Drum Velocity</source>
        <translation>Скорость барабана</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="17"/>
        <source>Pulse Width</source>
        <translation>Ширина импульсов</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="18"/>
        <source>Pulse Ratio</source>
        <translation>Скважность импульсов</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="19"/>
        <source>Voltage Level</source>
        <translation>Уровень напряжения</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="20"/>
        <source>Current Level</source>
        <translation>Уровень тока</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="27"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
</context>
<context>
    <name>NewCutlineDialog</name>
    <message>
        <location filename="new_cutline_dialog.cpp" line="43"/>
        <source>Abs</source>
        <translation>Абс.</translation>
    </message>
    <message>
        <location filename="new_cutline_dialog.cpp" line="44"/>
        <source>Rel</source>
        <translation>Отн.</translation>
    </message>
</context>
<context>
    <name>PultWidget</name>
    <message>
        <location filename="pult_widget.cpp" line="129"/>
        <location filename="pult_widget.cpp" line="247"/>
        <source>Motor</source>
        <translation>Двигатель</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="130"/>
        <location filename="pult_widget.cpp" line="248"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="131"/>
        <location filename="pult_widget.cpp" line="421"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="132"/>
        <location filename="pult_widget.cpp" line="422"/>
        <source>steps</source>
        <translation>шагов</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="157"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="161"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="246"/>
        <source>Scale (steps/mm)</source>
        <translation>Масштаб (шагов/мм)</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="259"/>
        <source>Move</source>
        <translation>Перемещение</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="260"/>
        <source>Set</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="261"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="434"/>
        <source>Speed</source>
        <oldsource>Speed:</oldsource>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="440"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="441"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="main.cpp" line="36"/>
        <source>Meatec CNC</source>
        <translation>ЧПУ Меатэк</translation>
    </message>
</context>
<context>
    <name>RunWidget</name>
    <message>
        <location filename="run_widget.cpp" line="35"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="37"/>
        <source>Holding of stepper motors on/off</source>
        <translation>Удержание шаговых двигателей вкл./выкл.</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="40"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="40"/>
        <source>Reverse</source>
        <translation>Реверс</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="40"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="42"/>
        <source>Speed</source>
        <oldsource>Speed:</oldsource>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="48"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="49"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="51"/>
        <source>Idle run</source>
        <translation>Холостой ход</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="115"/>
        <source>Time</source>
        <translation>Прошло</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="116"/>
        <source>Remain</source>
        <translation>Осталось</translation>
    </message>
</context>
</TS>
