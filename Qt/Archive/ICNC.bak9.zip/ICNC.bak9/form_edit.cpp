#include "form_edit.h"

#include <QFileDialog>
#include <QDebug>
#include <QMessageBox>
#include <QTextCodec>
#include <QSplitter>
#include <QList>
#include <algorithm>

using namespace std;

FormEdit::FormEdit(ProgramParam& par, QWidget *parent) :
    QWidget(parent),
    par(par),
    plotView(QwtPlotView()),
    select_ena(false)
{
    createButtons();

    txtEditor = new CodeEditor;
    txtEditor->setMinimumWidth(400);

    txtMsg = new QTextEdit;
    txtMsg->setReadOnly(true);
    txtMsg->setMinimumHeight(100);

    QWidget* plotWidget = new QWidget;
    plotWidget->setMinimumSize(QSize(250, 250));
    QGridLayout* grid = new QGridLayout;

//    grid->addWidget(plotView.give(), 0, 1, Qt::AlignTop | Qt::AlignRight);
    grid->addWidget(plotView.widget(), 0, 1);
    plotWidget->setLayout(grid);

    splitterTxtPlot = new QSplitter(Qt::Horizontal);
    splitterTxtPlot->addWidget(txtEditor);
    splitterTxtPlot->addWidget(plotWidget);
    splitterTxtPlot->setCollapsible(0, false);

    splitterTxtMsg = new QSplitter(Qt::Vertical);
    splitterTxtMsg->addWidget(splitterTxtPlot);
    splitterTxtMsg->addWidget(txtMsg);
    splitterTxtMsg->setCollapsible(0, false);

    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(splitterTxtMsg);
    mainLayout->addLayout(gridButtons);

    setFontPointSize(14);

    this->setLayout(mainLayout);

    connect(txtEditor, &CodeEditor::lineChanged, this, &FormEdit::onLineChanged);
    connect(txtEditor, &CodeEditor::textChanged, [&](){ select_ena = false; });

    connect(splitterTxtPlot, &QSplitter::splitterMoved, this, &FormEdit::onTxtPlotMoved);
    connect(splitterTxtMsg, &QSplitter::splitterMoved, this, &FormEdit::onTxtMsgMoved);

    init();
}

FormEdit::~FormEdit() {}

void FormEdit::setFontPointSize(int pointSize) {
    for (QPushButton* b: buttons) {
        QFont font = b->font();
        font.setPointSize(pointSize);
        b->setFont(font);
//        b->setStyleSheet("font: bold");
    }
}

void FormEdit::createButtons() {
    btnHome = new QPushButton(tr("Home"));
    btnNew = new QPushButton(tr("New"));
    btnOpen = new QPushButton(tr("Open"));
    btnSave = new QPushButton(tr("Save"));
    btnSave->setEnabled(false);
    btnSaveAs = new QPushButton(tr("Save as"));    
    btnPlot = new QPushButton(tr("Plot"));

//    btnPlay = new QPushButton(tr("Play"));
    btnPlay = new QPushButton;
    btnPlay->setEnabled(false);

    btnContour = new QPushButton(tr("to Contour"));
    btnContour->setEnabled(false);

    btn8 = new QPushButton;
    btn8->setEnabled(false);

    btn9 = new QPushButton;
    btn9->setEnabled(false);

    btn10 = new QPushButton;
    btn10->setEnabled(false);

    btn11 = new QPushButton;
    btn11->setEnabled(false);

    btnRun = new QPushButton(tr("Run"));
    btnHelp = new QPushButton(tr("Help"));

    gridButtons = new QGridLayout;

    gridButtons->addWidget(btnHome, 0, 0);
    gridButtons->addWidget(btnNew, 0, 1);
    gridButtons->addWidget(btnOpen, 0, 2);
    gridButtons->addWidget(btnSave, 0, 3);
    gridButtons->addWidget(btnSaveAs, 0, 4);
    gridButtons->addWidget(btnPlot, 0, 5);
    gridButtons->addWidget(btnContour, 0, 6);
    gridButtons->addWidget(btn8, 0, 7);
    gridButtons->addWidget(btn9, 0, 8);
    gridButtons->addWidget(btn10, 0, 9);
    gridButtons->addWidget(btn11, 0, 10);
    gridButtons->addWidget(btnPlay, 0, 11);
    gridButtons->addWidget(btnRun, 0, 12);
    gridButtons->addWidget(btnHelp, 0, 13);

    buttons = {btnHome, btnNew, btnOpen, btnSave, btnSaveAs, btnPlot, btnContour, btn8, btn9, btn10, btn11, btnPlay, btnRun, btnHelp};

    connect(btnHome, &QPushButton::clicked, [&]() { emit homePageClicked(); });
    connect(btnNew, &QPushButton::clicked, this, &FormEdit::on_btnNew_clicked);
    connect(btnOpen, &QPushButton::clicked, this, &FormEdit::on_btnOpen_clicked);
    connect(btnSave, &QPushButton::clicked, this, &FormEdit::on_btnSave_clicked);
    connect(btnSaveAs, &QPushButton::clicked, this, &FormEdit::on_btnSaveAs_clicked);
    connect(btnPlot, &QPushButton::clicked, this, &FormEdit::on_btnPlot_clicked);
    connect(btnPlay, &QPushButton::clicked, this, &FormEdit::on_btnPlay_clicked);
    connect(btnContour, &QPushButton::clicked, this, &FormEdit::on_btnContour_clicked);

    connect(btnRun, &QPushButton::clicked, this, &FormEdit::on_btnRun_clicked);
    connect(btnHelp, &QPushButton::clicked, this, [&]() { emit helpPageClicked(help_file); });
}

void FormEdit::init(bool auto_plot) {
    par.workContours.clear();
    par.mapGcodeToContours.clear();
    plot();
    txtEditor->setPlainText(par.gcodeText);
    showPlot();
    showMessage();
//    hidePlot();
//    hideMessage();
    select_ena = false;
    btnContour->setEnabled(par.contours.empty());
    btnSave->setEnabled(false);

    if (auto_plot)
        on_btnPlot_clicked();
}

void FormEdit::on_btnNew_clicked() {
    par.gcodeText.clear();
    txtEditor->setPlainText(par.gcodeText);
    par.cncFileName.clear();
    par.saveSettings();
    setFileEnabled(false);
}

bool FormEdit::openGcodeFileDialog(QFile& file, QString& fileDir, QString& fileName) {
    QString fullFileName = fileDir + "/" + fileName;

    if (!QFile::exists(fullFileName)) {
        fileName.clear();

        if (!QDir(fileDir).exists())
            fileDir = QDir::homePath();
    }

    QFileDialog dialog(this, tr("Open G-code file"), fileDir + "/" + fileName, tr("G-code files") + " (*.nc *.NC)" + ";;" + tr("All files") + " (*)");
    dialog.setAcceptMode(QFileDialog::AcceptMode::AcceptOpen);
    dialog.setFileMode(QFileDialog::FileMode::ExistingFile);
    dialog.setOption(QFileDialog::ReadOnly);

//    dialog.setWindowModality(Qt::ApplicationModal);
//    dialog.setModal(true);
//    dialog.setWindowFlags(Qt::WindowStaysOnTopHint);

//    dialog.setOption(QFileDialog::DontUseNativeDialog, true);

    if (dialog.exec()) {
        QStringList list = dialog.selectedFiles();
        fileDir = dialog.directory().canonicalPath();
        file.setFileName(list[0]);

        QFileInfo fInfo(file);
        fileName = fInfo.fileName();
        return true;
    }

    return false;
}

//bool FormEdit::openGcodeFileDialog(QFile& file, QString& fileDir, QString& fileName) {
////    QStringList filter;
////    filter << tr("G-code (*.nc *.NC)") << tr("All files (*)");

//    QFileDialog dialog(nullptr, tr("Open G-code file"), fileName, tr("G-code (*.nc *.NC)"));
//    dialog.setAcceptMode(QFileDialog::AcceptMode::AcceptOpen);
//    dialog.setFileMode(QFileDialog::FileMode::ExistingFile);
//    dialog.setOption(QFileDialog::ReadOnly);
//    dialog.setDirectory(fileDir);

//    if (dialog.exec()) {
//        QStringList list = dialog.selectedFiles();
//        fileDir = dialog.directory().path();
//        file.setFileName(list[0]);

//        QFileInfo fInfo(file);
//        fileName = fInfo.fileName();
//        return true;
//    }

//    return false;
//}

void FormEdit::on_btnOpen_clicked() {
    QFile file;

    setFileEnabled(false);

    if (openGcodeFileDialog(file, par.fileDir, par.cncFileName)) {
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
            QMessageBox::information(nullptr, "Error", file.errorString());
        }
        else {
            QTextStream stream(&file);
            stream.setCodec("Windows-1251");
            par.gcodeText = stream.readAll();
            txtEditor->setPlainText(par.gcodeText);
            file.close();
            par.saveSettings();
            setFileEnabled(true);
        }
    }
}

//void FormEdit::on_btnOpen_clicked() {
//    QStringList filter;
//    filter << tr("G-code (*.nc *.NC)") << tr("All files (*)");

//    QFileDialog dialog(this, tr("Open G-code file"), par.cncFileName);
//    dialog.setNameFilters(filter);
//    dialog.setAcceptMode(QFileDialog::AcceptMode::AcceptOpen);
//    dialog.setFileMode(QFileDialog::FileMode::ExistingFile);
//    dialog.setOption(QFileDialog::ReadOnly);
//    dialog.setDirectory(par.fileDir);

//    if (dialog.exec()) {
//        QStringList list = dialog.selectedFiles();
//        par.fileDir = dialog.directory().path();
//        QFile file(list[0]);

//        QFileInfo fInfo(list[0]);
//        par.cncFileName = fInfo.fileName();

//        if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
//            QMessageBox::information(nullptr, "Error", file.errorString());
//        }
//        else {
//            QTextStream stream(&file);
//            stream.setCodec("Windows-1251");
//            par.gcodeText = stream.readAll();
//            txtEditor->setPlainText(par.gcodeText);
//            file.close();
//            par.saveSettings();
//        }
//    }
//}

void FormEdit::on_btnSave_clicked() {
    if (par.fileDir.length() == 0 || par.cncFileName.length() == 0)
        on_btnSaveAs_clicked();
    else {
        QFile file(par.fileDir + "/" + par.cncFileName);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            QMessageBox::information(nullptr, "Error", file.errorString());
        }
        else {
            par.gcodeText = txtEditor->toPlainText();

            QTextStream stream(&file);
            stream.setCodec("Windows-1251");
            stream << par.gcodeText << flush;
            file.close();
        }
    }
}

void FormEdit::on_btnSaveAs_clicked() {
    QString new_filePath = QFileDialog::getSaveFileName(this, tr("Save G-code file"),
                               par.fileDir + "/" + par.cncFileName,
                               tr("G-code files") + " (*.nc *.NC)");

    if (new_filePath.length() != 0) {
        QFileInfo fInfo(new_filePath);
        par.fileDir = fInfo.dir().path();
        par.cncFileName = fInfo.fileName();
        on_btnSave_clicked();
        par.saveSettings();
        setFileEnabled(true);
    }
}

void FormEdit::on_btnPlay_clicked() {
    if (txtEditor->isReadOnly()) {
        btnPlay->setText(tr("Play"));
        buttonsEnable();
        txtEditor->setReadOnly(false);
    }
    else {
        buttonsDisable(btnPlay);
        btnPlay->setText(tr("Stop"));
        txtEditor->setReadOnly(true);
        // run timer
    }
}

// onTimer
// Move cursor

void FormEdit::on_btnMsg_clicked() {
    if (splitterTxtMsg->sizes().size() >= 2 && splitterTxtMsg->sizes()[1] != 0)
        hideMessage();
    else
        showMessage();
}

void FormEdit::on_btnPlot_clicked() {
    GCode gcode = compile();
    par.workContours = ContourList( gcode.getContours(&par.mapGcodeToContours) );

    if (!par.workContours.empty()) {
        showPlot();
        plot();
        select_ena = true;
    }
    else {
        if (splitterTxtPlot->sizes().size() >= 2 && splitterTxtPlot->sizes()[1] != 0)
            hidePlot();
        else
            showPlot();
    }
}

void FormEdit::on_btnContour_clicked() {
    if (par.contours.empty()) {
        GCode gcode = compile();
        ContourList contours = ContourList( gcode.getContours(&par.mapGcodeToContours) );

        if (!contours.empty()) {
            par.contours = contours;
            emit contourPageClicked();
        }
    }
}

void FormEdit::on_btnRun_clicked() {
    par.gcode = compile();
    par.gcodeSettings = par.gcode.getSettings();

    if (!par.gcode.empty())
        emit runPageClicked();
}

void FormEdit::on_btnImit_clicked() {
    par.mode = CncMode::RUN_IMIT;
    emit testPageClicked();
}

void FormEdit::onTxtPlotMoved(int /*pos*/, int /*index*/) {
    plotView.onResizeEvent( plotViewSize() );
}

void FormEdit::onTxtMsgMoved(int /*pos*/, int /*index*/) {
    plotView.onResizeEvent( plotViewSize() );
}

void FormEdit::onLineChanged(int row) {
    if (select_ena && !par.workContours.empty() && !par.mapGcodeToContours.empty()) {
        if (row >= 0)
            par.workContours.select( par.getDxfEntityNum(size_t(row)) );
        else
            par.workContours.clearSelected();

//        plotWidget->plot(par.workContours);
        plot();
    }
}

GCode FormEdit::compile() {
    const QString& txt = txtEditor->toPlainText();
    GCode gcode;
    int err = gcode.parse(txt.toStdString());

    if (err == 0) {
        string new_txt = gcode.toText();
        qDebug() << new_txt.c_str();
        par.gcodeText = new_txt.c_str();
        txtEditor->setPlainText(par.gcodeText);
        showMessage("Compilation completed successfully");
    }
    else {
        QTextCursor textCursor = txtEditor->textCursor();

        textCursor.movePosition(QTextCursor::Start);
        textCursor.movePosition(QTextCursor::Down, QTextCursor::MoveAnchor, err - 1);

        txtEditor->setTextCursor(textCursor);

        showMessage("Error: compalation error at line " + QString::number(err));

        txtEditor->setFocus();
        gcode.clear();
    }

    return gcode;
}

void FormEdit::showMessage(QString s) {
    showMessage();
    txtMsg->setText(s);
}

void FormEdit::showPlot() {
    QList<int> sizes = splitterTxtPlot->sizes();

    if (sizes.size() >= 2) {
        int w = sizes[0] + sizes[1];
        splitterTxtPlot->setSizes({int(w * 4.0/14.0), w - int(w * 4.0/14.0)});
    }
}

void FormEdit::hidePlot() {
    splitterTxtPlot->setSizes({100, 0});
}

void FormEdit::showMessage() {
    QList<int> sizes = splitterTxtMsg->sizes();

    if (sizes.size() >= 2) {
        int w = sizes[0] + sizes[1];
        splitterTxtMsg->setSizes({w - 100, 100});
    }
}

void FormEdit::hideMessage() {
    splitterTxtMsg->setSizes({100, 0});
}

//void FormEdit::on_splitterEditorPlot_splitterMoved(int pos, int index) {}

void FormEdit::plot() {
    QList<int> sizes = splitterTxtPlot->sizes();

    if (sizes.size() >= 2) {
        int w = sizes[1];
        int h = splitterTxtPlot->size().height();
        QSize size = QSize(w, h);
        plotView.setSwapXY(par.swapXY);
        plotView.setInverseX(par.inverseX);
        plotView.setInverseY(par.inverseY);
        plotView.setShowXY(par.showXY);
        plotView.plot(par.workContours, size);
//        plotView.plot(par.workContours);
    }
}

QSize FormEdit::plotViewSize() const {
    QList<int> hsizes = splitterTxtPlot->sizes();
    QList<int> vsizes = splitterTxtMsg->sizes();

    if (hsizes.size() >= 2 && vsizes.size() >= 2) {
        int w = hsizes[1];
        int h = splitterTxtPlot->size().height();
        h = vsizes[0];
        QSize size(w, h);
        qDebug() << "Plot splitter size: " << size;
        return size;
    }
    return QSize(0, 0);
}

void FormEdit::resizeEvent(QResizeEvent* event) {
    showMessage();
    QSize size = plotViewSize();

    if (!plotView.onResizeEvent(size))
        event->ignore();
}

void FormEdit::buttonsDisable(QPushButton *except) {
    for (QPushButton* btn: buttons)
        if (btn != except)
            btn->setEnabled(false);
}

void FormEdit::buttonsEnable() {
    for (QPushButton* btn: buttons)
        btn->setEnabled(true);
}
