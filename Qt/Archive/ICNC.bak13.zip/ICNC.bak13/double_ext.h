#ifndef DOUBLE_EXT_H
#define DOUBLE_EXT_H

#include <string>
#include "main.h"

//class doubleExt {
//    constexpr static const double M_PRECISION = PRECISION; // mm
//    static double prec;

//public:
//    static double getPrecition() { return prec; }
//    static void setPrecition(double value) { prec = std::abs(value); }

//    static double round(double value);
//    static double round(double value, double precition);

//    static std::string toString(double value);
//    static std::string toString(double value, double precition);
//};

#endif // DOUBLE_EXT_H
