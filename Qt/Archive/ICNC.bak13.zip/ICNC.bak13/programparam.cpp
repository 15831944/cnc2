#include "programparam.h"

ProgramParam::ProgramParam()
{

}
