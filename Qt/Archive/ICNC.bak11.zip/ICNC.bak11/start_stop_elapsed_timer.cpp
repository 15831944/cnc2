#include "start_stop_elapsed_timer.h"

StartStopElapsedTimer::StartStopElapsedTimer() : ms(0) {
    timer = new QElapsedTimer;
}

StartStopElapsedTimer::~StartStopElapsedTimer() {
    delete timer;
    timer = nullptr;
    ms = 0;
}

void StartStopElapsedTimer::clear() {
    timer->invalidate();
    ms = 0;
}

void StartStopElapsedTimer::start() {
    if (!timer->isValid())
        timer->start();
}

void StartStopElapsedTimer::stop() {
    if (timer->isValid()) {
        ms += timer->elapsed();
        timer->invalidate();
    }
}

qint64 StartStopElapsedTimer::elapsed() {
    return timer->isValid() ? ms + timer->elapsed() : ms;
}
