#ifndef PROGRAMPARAM_H
#define PROGRAMPARAM_H

//#pragma once

#include <list>
#include <map>
#include <cstdint>
#include <QString>

#include "gcode.h"
#include "cnc.h"
#include "contour_list.h"
#include "cnc_types.h"

class AppState {
public:
    enum class BUTTON {SIG_START, SIG_REVERSE, SIG_CANCEL, SIG_IMIT, SIG_ERROR};
    enum class STATES {ST_UNCHECKED, ST_IDLE, ST_DIRECT, ST_RUN, ST_PAUSE, ST_REV, ST_CANCEL, ST_SHORT_REV, ST_IMIT, ST_ERROR};
private:
    STATES m_state {STATES::ST_UNCHECKED};
    bool m_idle_run {false};
public:
    inline STATES state() const { return m_state; }
    inline bool isIdle() const { return m_state <= STATES::ST_IDLE; }
    inline bool isError() const { return m_state >= STATES::ST_ERROR; }
    inline bool isWork() const { return m_state > STATES::ST_IDLE && m_state < STATES::ST_ERROR; }
    inline void reset() { m_state = STATES::ST_UNCHECKED; }
    inline void error() { m_state = STATES::ST_ERROR; }
    void next(AppState::BUTTON btn);

    void setIdleRun(bool value) { m_idle_run = value; }
    bool idleRun() const { return m_idle_run; }

    inline void update(const CncContext& ctx) {
        if (ctx.isError())
            m_state = STATES::ST_ERROR;
        else if (ctx.isIdle())
            m_state = STATES::ST_UNCHECKED;
//        else if (ctx.isDirect())
//            m_state = STATES::ST_DIRECT;
        else if (ctx.reverse())
            switch (ctx.cncState()) {
            case cnc_state_t::ST_READ:
            case cnc_state_t::ST_SEGMENT:
            case cnc_state_t::ST_WAIT:
            case cnc_state_t::ST_PAUSE:
            case cnc_state_t::ST_WAIT_BUTTON:
                m_state = STATES::ST_REV;
                break;

            case cnc_state_t::ST_STOP:
                m_state = STATES::ST_PAUSE;
                break;

            default:
                break;
            }
        else
            switch (ctx.cncState()) {
            case cnc_state_t::ST_READ:
            case cnc_state_t::ST_SEGMENT:
            case cnc_state_t::ST_WAIT:
            case cnc_state_t::ST_PAUSE:
            case cnc_state_t::ST_WAIT_BUTTON:
            case cnc_state_t::ST_END:
                m_state = STATES::ST_RUN;
                break;

            case cnc_state_t::ST_STOP:
                m_state = STATES::ST_PAUSE;
                break;

            default:
                break;
            }
    }

    inline void recovery() {
        m_state = STATES::ST_PAUSE;
    }
};

enum class CncMode : uint8_t {RUN_NORMAL, RUN_IDLE, RUN_STEP_BY_STEP, RUN_IMIT, RUN_END};
const QString CncModeName[static_cast<int>(CncMode::RUN_END)] = {"Normal run", "Idle run", "Step-by-step run", "Imitation run"};

enum class InterfaceLanguage : uint8_t { ENGLISH, RUSSIAN, END };

class ProgramParam {
    static constexpr const char* org = "Meatec";
    static constexpr const char* app = "CncProgramPrototype_2";

public:
    static constexpr size_t AXES_NUM = 4;
    static InterfaceLanguage lang;
    static int fontSize;
    static bool swapXY, showXY;

    QString gcodeText;
    QString gcodeCnc;
    QString fileDir;
    QString cncFileName, contourFileName, modesFileName, cutFileName;
    AppState appState;
    CncMode mode;
    GCode gcode;
    GCodeSettings gcodeSettings;
    ContourList contours;

    ContourList workContours;
    std::vector<std::pair<size_t, size_t>> mapGcodeToContours;

    Cnc cnc;
    bool cncConnected;

    CncContext cncContext;
//    bool soft_context_valid;
//    bool hard_context_valid;

//    bool gcode_valid;

    cut_t cut;
    std::deque<GeneratorMode> genModesList;

    ProgramParam();
    ~ProgramParam();

    void loadSettings();
    void saveSettings();

    void setCncContext(const cnc_context_t& ctx) { cncContext.set(ctx); }
    void saveCncContext();
    void loadCncContext();
    void clearCncContext();

    void saveGcode();
    QString loadGcode();
    const QString& getGcode() const { return gcodeCnc; }

    void setDefaultGenModeList();
    void setDefaultCutParam();

    std::pair<size_t, size_t> getDxfEntityNum(size_t gframe_num) const {
        if (gframe_num < mapGcodeToContours.size())
            return mapGcodeToContours[gframe_num];
        else if (mapGcodeToContours.size())
            return mapGcodeToContours.back();

        return std::pair<size_t, size_t>({0,0});
    }
//private:
//    QString m_SettingsFile;

    static GCode compile(const QString& gcode);

    void loadBackup();
    bool validGCodeBackup() const { return !gcode.empty(); }
    bool validContextBackup() const { return cncContext.valid(); }
    bool backup();

    static void saveInterfaceLanguage(InterfaceLanguage lang);
    static InterfaceLanguage loadInterfaceLanguage();

    static void saveSwapXY(bool value);
    static bool loadSwapXY();

    static void saveShowXY(bool value);
    static bool loadShowXY();

    static QString helpSubDir();

    static void saveFontSize(int fontSize);
    static int loadFontSize();

    static void saveInputLevel(uint16_t value);
    static uint16_t loadInputLevel(bool& OK);
};

#endif // PROGRAMPARAM_H
