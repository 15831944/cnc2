#include "cnc.h"
#include <vector>
#include <list>
//#include "aux_func.h"
#include <cstdio>
#include <ctime>
#include <cmath>
//#include <chrono>
//#include <thread>
#include <unistd.h>
#include <QThread>
#include <QTextEdit>
#include <QDebug>

using namespace std;
using namespace aux_func;

uint16_t CncParam::inputLevel = INPUT_LEVEL_DEFAULT;
double CncParam::step = DEFAULT_STEP; // mm
double CncParam::scale_x = DEFAULT_SCALE_XY, CncParam::scale_y = DEFAULT_SCALE_XY, CncParam::scale_u = DEFAULT_SCALE_UV, CncParam::scale_v = DEFAULT_SCALE_UV;
double CncParam::enc_scale_x = DEFAULT_ENC_SCALE, CncParam::enc_scale_y = DEFAULT_ENC_SCALE;

CncCom* Cnc::com = nullptr;

Cnc::Cnc() : msg(nullptr) {
    fpga.bind(&com);
}
Cnc::~Cnc() {
    close();
}

//void Cnc::bindCncParam(CncParam *const ptr) {
//    p_cnc_param = ptr;
//}

void Cnc::setReportWriter(ReportWriter msg) {
    this->msg = msg;
}

bool Cnc::open(string /*portName*/) {
    if (com == nullptr) {
        com = new CncCom(msg);
        com->open();

        if (!com->isOpen()) {
            delete com;
            com = nullptr;
            return false;
        }

//        reset();
        return true;
    }
    return false;
}

bool Cnc::close() {
    msg = nullptr;
    if (com != nullptr) {
        com->close();
        delete com;
        com = nullptr;
//        p_key_level = nullptr;
        return true;
    }
    return false;
}

void Cnc::reset() {
    if (isOpen()) {
//        com->write32(ADDR::CLEAR, ADDR::RESET_MASK);
        writeInputLevel(CncParam::inputLevel); // reset included
    }
}

bool Cnc::writeProgArray(const vector<uint8_t>& bytes) {
    try {
        qDebug("Write to Program Array %d bytes\n", int(bytes.size()));
        if (isOpen()) {
            com->write(ADDR::PA, bytes);
            com->write32(ADDR::PA_RDADDR, 0);
            com->write32(ADDR::PA_WRADDR, static_cast<uint32_t>(bytes.size()));
            return true;
        }
    } catch (...) {}

    return false;
}

vector<uint8_t> Cnc::readProgArray() {
    qDebug("Read Program Array\n");
    uint32_t len = isOpen() ? com->read32(ADDR::PA_WRADDR) : 0;

    vector<uint8_t> bytes;
    if (isOpen())
        bytes = com->read(ADDR::PA, len);

    qDebug("read %d bytes\n", int(bytes.size()));
    return bytes;
}

string fileReadLine(FILE* fp) {
    string s;
    s.resize(256);
    s.clear();

    while (!feof(fp)) {
        int ch = fgetc(fp);

        if (ferror(fp)) {
            qDebug("Read file error\n");
            s.clear();
            break;
        }
        else {
            if (ch == '\n' || ch == '\0')
                break;
            else
                s += static_cast<char>(ch);
        }
    }

    return s;
}

string textReadLine(const string& text,  string::const_iterator& it) {
    string s;
    s.resize(256);
    s.clear();

    while (it != text.end()) {
        if (*it == '\n' || *it == '\0')
            break;
        else
            s += *it;

        ++it;
    }

    return s;
}

bool Cnc::writeFromFile(const string& fileName) {
    FILE* fp = fopen(fileName.c_str(), "r");

    if (fp == nullptr) {
        msg.write( QString::asprintf("File \"%s\" is not found\n", fileName.c_str()) );
        return false;
    }
    msg.write( QString::asprintf("Read G-code from file \"%s\"\n", fileName.c_str()) );

    list<string> ss;

    string s = fileReadLine(fp);
    size_t n = s.size() + 1;

    while (!s.empty()) {
        ss.push_back(std::move(s));
        s = fileReadLine(fp);
        n += s.size() + 1;
    }

    print_strings(&msg, ss);

    vector<uint8_t> data;
    for (list<string>::const_iterator it = ss.begin(); it != ss.end(); ++it)
        push_back_range(data, *it);

    uint32_t pa_size = isOpen() ? com->read32(ADDR::PA_SIZE) : 0;

    if (data.size() > pa_size) {
        qDebug("G-code size is too big %d bytes (available only %d bytes)", int(data.size()), int(pa_size));
        return false;
    }

    return writeProgArray(data);
}

bool Cnc::write(const std::list<std::string>& frames) {
    vector<uint8_t> data;
    for (list<string>::const_iterator it = frames.begin(); it != frames.end(); ++it)
        push_back_range(data, *it);

    uint32_t pa_size = isOpen() ? com->read32(ADDR::PA_SIZE) : 0;

    if (data.size() > pa_size) {
        msg.write( QString::asprintf("G-code size is too big %d bytes (available only %d bytes)", int(data.size()), int(pa_size)) );
        return false;
    }

    return writeProgArray(data);
}

void Cnc::printGCode() {
    list<string> frames = read();
    print_strings(frames);
}

list<string> Cnc::read() {
    vector<uint8_t> bytes = readProgArray();
    list<string> frames;

    string s;
    for (size_t i = 0; i < bytes.size(); i++) {
        if (bytes[i] == '\0') {
            frames.push_back(s);
            s.clear();
        }
        else
            s += static_cast<char>(bytes[i]);
    }

    return frames;
}

#define FPGA_CLOCK (72e6)
/* scale - steps/mm
 * speed - mm/min
*/
bool Cnc::directMoveOn(int32_t nx, double scale_x, int32_t ny, double scale_y, int32_t nu, double scale_u, int32_t nv, double scale_v, double speed) {
    if (nx || ny || nu || nv) {
        try {
            if (isOpen()) {
                double dx = nx / scale_x; // mm
                double dy = ny / scale_y;
                double du = nu / scale_u;
                double dv = nv / scale_v;

                double len_xy = sqrt(dx * dx + dy * dy);
                double len_uv = sqrt(du * du + dv * dv);
                double len = len_xy > len_uv ? len_xy : len_uv;

                double T = 60.0 * FPGA_CLOCK / speed; // clocks/mm

                double ts = len * T;

                int32_t Tx = int32_t(round(nx ? ts / nx : 0));
                int32_t Ty = int32_t(round(ny ? ts / ny : 0));
                int32_t Tu = int32_t(round(nu ? ts / nu : 0));
                int32_t Tv = int32_t(round(nv ? ts / nv : 0));

                int32_t data[] = {nx, Tx, ny, Ty, nu, Tu, nv, Tv};
                com->write(ADDR::MOVE_X, data, sizeof(data));
                return true;
            }
        } catch (...) {}

        return false;
    }

    return true;
}

bool Cnc::directSetPos(int32_t nx, int32_t ny, int32_t nu, int32_t nv, int32_t enc_x, int32_t enc_y) {
    try {
        if (isOpen()) {
            int32_t data[] = {nx, ny, nu, nv, enc_x, enc_y};
            com->write(ADDR::SET_X, data, sizeof(data));
            return true;
        }
    } catch (...) {}

    return false;
}

bool Cnc::runReq() {
    try {
        if (isOpen()) {
            com->write32(ADDR::STATUS, ADDR::RUN_MASK);
            return true;
        }
    } catch (...) {}

    return false;
}
bool Cnc::revReq() {
    try {
        if (isOpen()) {
            com->write32(ADDR::STATUS, ADDR::REV_MASK | ADDR::RUN_MASK);
            return true;
        }
    } catch (...) {}

    return false;
}

bool Cnc::abortReq() {
    try {
        if (isOpen()) {
            com->write32(ADDR::CLEAR, ADDR::ABORT_MASK);
            return true;
        }
    } catch (...) {}

    return false;
}
bool Cnc::stopReq() {
    try {
        if (isOpen()) {
            com->write32(ADDR::CLEAR, ADDR::STOP_MASK);
            return true;
        }
    }
    catch (...) {}

    return false;
}

bool Cnc::isRun() {
    try {
        return isOpen() ? (com->read32(ADDR::STATUS) & ADDR::RUN_MASK) != 0 : false;
    } catch (...) {}

    return false;
}

cnc_context_t Cnc::readCncContext() const {
    vector<uint8_t> v;

    try {
        if (isOpen()) {
            v = com->read(ADDR::CONTEXT, CncContext::SIZE);
            cnc_context_t ctx = CncContext::parse(v);
            ctx.field.backup_valid = true; // add valid for save param
            return ctx;
        }
    } catch (...) { }

    return CncContext::defaultContext();
}

cnc_context_t Cnc::readBackup() const {
    vector<uint8_t> v;

    try {
        if (isOpen()) {
            v = com->read(ADDR::BACKUP, CncContext::BACKUP_SIZE);
            return CncContext::parse(v);
        }
    } catch (...) { }

    return CncContext::defaultContext();
}

void Cnc::clearBackup() {
    com->write32(ADDR::BACKUP + ((CncContext::BACKUP_SIZE32 - 1) << 2), 0);
}

// program must be loaded + reset
void Cnc::initialContext(const cnc_context_t& ctx) {
    writeXYUVEnc(ctx.field.x, ctx.field.y, ctx.field.u, ctx.field.v, ctx.field.enc_x, ctx.field.enc_y);
    writeGoto(ctx.field.id);

//    writePumpEnable(ctx.field.pump_ena);
//    writeDrumEnable(ctx.field.drum_state == unsigned(drum_state_t::DRUM_ANY) ||
//                    ctx.field.drum_state == unsigned(drum_state_t::DRUM_REV) ||
//                    ctx.field.drum_state == unsigned(drum_state_t::DRUM_REV)
//                    );
    writeWireEnable(ctx.field.wire_ena);
//    writeVoltageEnable(ctx.field.voltage_ena);
    writeHoldEnable(ctx.field.hold_ena);
    writeDrumVel(ctx.field.drum_vel);
    writeVolgateLevel(ctx.field.voltage_level);
    writeCurrentIndex(ctx.field.current_index);
    writePulseWidth(ctx.field.pulse_width);
    writePulseRatio(ctx.field.pulse_ratio);
    writeSpeed( WireSpeed::TtoSpeed(ctx.field.T) );
    writeEnableUV(ctx.field.uv_ena);
}

cnc_adc_t Cnc::readADC() const {
    vector<uint8_t> v;

    try {
        if (isOpen()) {
            v = com->read(ADDR::ADC, cnc_adc_t::SIZE);
            return cnc_adc_t::parse(v);
        }
    } catch (...) { }

    return cnc_adc_t();
}

cnc_adc_volt_t Cnc::readADCVolt() const {
    return cnc_adc_volt_t( readADC() );
}

void Cnc::imitEna(bool value) {
    if (isOpen()) {
        if (value)
            com->write32(ADDR::STATUS, ADDR::IMIT_MASK);
        else
            com->write32(ADDR::CLEAR, ADDR::IMIT_MASK);
    }
}

bool Cnc::isImitEna() {
    return isOpen() ? (com->read32(ADDR::STATUS) & ADDR::IMIT_MASK) != 0 : false;
}

void Cnc::readImitFifo() {
    imit_list.clear();

    int timeout = 10;
    int cnt = timeout;
    int pack_num = 0, total = 0;
    MotorRecord rec;
    const uint8_t max = 21 * MotorRecord::size; // len = 252

    do {
        timespec tic, toc;
        clock_gettime(CLOCK_MONOTONIC, &tic);

        vector<uint8_t> b;
        if (isOpen())
            b = com->readFifo(ADDR::IMIT_FIFO_Q, max);

        clock_gettime(CLOCK_MONOTONIC, &toc);
        double sec = 1.0 * (toc.tv_sec - tic.tv_sec) + 1e-9 * (toc.tv_nsec - tic.tv_nsec);

        cnt--;
        size_t it = 0;
        pack_num++;

        if (!b.empty()) {
            double baud = 8.0 * b.size() / sec;
            total += b.size();
            msg.write(QString::asprintf(\
                           "%d Read %g records (%d bytes). Total: records %g (%d bytes). Baud %g bit/s\n",\
                           pack_num, double(b.size()) / MotorRecord::size, int(b.size()), double(total) / MotorRecord::size, total, std::round(baud))\
                       );

            do {
                rec = MotorRecord(b, &it);
                imit_list.push_back(rec);
                if (rec.stop) break;
            } while (it < b.size());

            if (rec.stop) break;
            cnt = timeout;
        }
        else
            qDebug("%d Read %g records (%d bytes). Total: records %g (%d bytes). Baud %g bit/s\n", pack_num, 0.0, 0, double(total) / MotorRecord::size, total, 0.0);

//            if (b.size() < max / 2) usleep(100);
//            usleep(100);
        QThread::msleep(100);
    } while (cnt != 0);

//        if (!rec.stop)
//            qDebug("Timeout\n");
}

void Cnc::saveImitData(string fileName) {
    deque<int32_t> X, Y;

    for (deque<MotorRecord>::const_iterator it = imit_list.begin(); it != imit_list.end(); ++it)
        switch (it->axis) {
            case AXIS_X: X.push_back(it->N); Y.push_back(0); break;
            case AXIS_Y: X.push_back(0); Y.push_back(it->N); break;
            default: throw string("Axis error");
        }

    vector<int32_t> v;

    for (size_t i = 0; i < min(X.size(), Y.size()); i++) {
        v.push_back(X[i]);
        v.push_back(Y[i]);
    }

    FILE* fp = fopen(fileName.c_str(), "wb");

    if (fp == nullptr) {
        qDebug("File \"%s\" not found\n", fileName.c_str());
        return;
    }

    fwrite(v.data(), sizeof(int32_t), v.size(), fp);
    fflush(fp);
    msg.write("Imitation data saved to file \"" + fileName + "\"");
}

string Cnc::versionDate() {
    char date[4 * sizeof(uint32_t)], time[4 * sizeof(uint32_t)];
//        memset(date, 0, sizeof(date));
//        memset(time, 0, sizeof(time));
    uint32_t rddata;

    for (uint32_t i = 0; i < sizeof(date) / sizeof(uint32_t); i++) {
        rddata = isOpen() ? com->read32(ADDR::VER_DATE + (i << 2)) : 0;
        memcpy(&date[sizeof(uint32_t) * i], &rddata, sizeof(uint32_t));
    }

    for (uint32_t i = 0; i < sizeof(time) / sizeof(uint32_t); i++) {
        rddata = isOpen() ? com->read32(ADDR::VER_TIME + (i << 2)) : 0;
        memcpy(&time[sizeof(uint32_t) * i], &rddata, sizeof(uint32_t));
    }

    return string(date, 0, sizeof(date)) + " " + string(time, 0, sizeof(time));
}

uint32_t Cnc::sysClock() { return isOpen() ? com->read32(ADDR::SYS_CLOCK) : 0; }
cnc_version_t Cnc::version() { return isOpen() ? com->read32(ADDR::VER) : 0; }

string Cnc::readVersion() {
    cnc_version_t mcu_ver = version();
    string mcu_s = mcu_ver.toString();
    string mcu_date = versionDate();
    uint32_t f = sysClock();
    string res = "CNC: " + mcu_s;
    res += string_format(" from %s at %g MHz", mcu_date.c_str(), static_cast<double>(f/1e6));
    qDebug("%s", res.c_str());
    return res;
}

bool Cnc::writeUInt32(uint32_t addr, uint32_t data) {
    try {
        if (isOpen()) {
            com->write32(addr, data);
            return true;
        }
    }
    catch (...) {}

    return false;
}

bool Cnc::writeFloat(uint32_t addr, float data) {
    const uint32_t* const ptr = reinterpret_cast<uint32_t*>(&data);

    try {
        if (isOpen()) {
            com->write32(addr, *ptr);
            return true;
        }
    }
    catch (...) {}

    return false;
}

bool Cnc::writeSetBits(uint32_t addr, unsigned bit, unsigned width, uint16_t data) {
    uint32_t mask;
    if (width >= 16)
        mask = 0xffff;
    else
        mask = (1<<width) - 1;

    mask <<= bit;

    uint32_t data32 = (mask<<16) | (uint16_t(data<<bit) & mask);

    return writeUInt32(addr, data32);
}

bool Cnc::writePumpEnable(bool ena) {
    return writeSetBits(ADDR::CONTROLS_ENABLE, 0, 1, ena);
}
bool Cnc::writeDrumEnable(bool ena) {
    return writeSetBits(ADDR::CONTROLS_ENABLE, 1, 2, ena ? uint16_t(drum_state_t::DRUM_ANY) : uint16_t(drum_state_t::DRUM_DIS));
}
bool Cnc::writeWireEnable(bool ena) {
    return writeSetBits(ADDR::CONTROLS_ENABLE, 3, 1, ena);
}
bool Cnc::writeVoltageEnable(bool ena) {
    return writeSetBits(ADDR::CONTROLS_ENABLE, 4, 1, ena);
}
bool Cnc::writeHoldEnable(bool ena) {
    return writeSetBits(ADDR::CONTROLS_ENABLE, 5, 1, ena);
}

bool Cnc::writeSemaphoreEnable(bool ena) {
    return writeSetBits(ADDR::CONTROLS_ENABLE, 6, 1, ena);
}

bool Cnc::writeDrumVel(unsigned value) { return writeUInt32(ADDR::DRUM_VEL, value); }
bool Cnc::writeVolgateLevel(unsigned value) { return writeUInt32(ADDR::VOLTAGE_LEVEL, value); }
bool Cnc::writeCurrentIndex(size_t index) {
    if (index > UINT8_MAX)
        index = UINT8_MAX;

    return writeUInt32(ADDR::CURRENT_INDEX, uint32_t(index));
}
bool Cnc::writePulseWidth(unsigned value) { return writeUInt32(ADDR::PULSE_WIDTH, value); }
bool Cnc::writePulseRatio(unsigned value) { return writeUInt32(ADDR::PULSE_RATIO, value); }

// value - mm/min
bool Cnc::writeSpeed(float value) { return writeFloat(ADDR::SPEED, value); }
bool Cnc::writeSpeed(WireSpeed value) { return writeSpeed( float(value.getMMM()) ); }

// mm
bool Cnc::writeStep(float value) { return writeFloat(ADDR::STEP, value); }
bool Cnc::writeEnableUV(bool ena) { return writeUInt32(ADDR::UV_ENABLE, ena ? 1 : 0); }
bool Cnc::writeGoto(int32_t frame_num) {
    if (frame_num < 0)
        frame_num = 0;

    return writeUInt32(ADDR::GOTO, uint32_t(frame_num));
}
bool Cnc::writeXYUVEnc(int nx, int ny, int nu, int nv, int enc_x, int enc_y) {
    try {
        if (isOpen()) {
            int32_t data[] = {nx, ny, nu, nv, enc_x, enc_y};
            com->write(ADDR::REC_X, data, sizeof(data));
            return true;
        }
    } catch (...) {}

    return false;
}

bool Cnc::writeInputLevel(uint16_t value) { // RWR
    CncParam::inputLevel = value;

    uint16_t rd_key_level = readInputLevel();
    qDebug("KEY LEVEL: %x", int(rd_key_level));

    try {
        if (isOpen()) {
            com->write32(ADDR::INPUT_LEVEL, static_cast<uint32_t>(value));
            qDebug("NEW KEY LEVEL: %x", int(value));

            rd_key_level = readInputLevel();
            qDebug("KEY LEVEL: %x", int(rd_key_level));
            return true;
        }
    }
    catch (...) {}

    qDebug("WRITE KEY LEVEL ERROR");
    return false;
}

uint16_t Cnc::readInputLevel(bool* err) {
    try {
        if (isOpen()) {
            uint16_t value = static_cast<uint16_t>(com->read32(ADDR::INPUT_LEVEL) & 0xFFFF);

            if (err) *err = false;
            CncParam::inputLevel = value;

            qDebug("KEY LEVEL: %x", value);
            return value;
        }
    } catch (...) {}

    qDebug("READ KEY LEVEL ERROR");
    if (err) *err = true;
    return 0;
}

//bool Cnc::writeAdcThreshold(bool enable, uint16_t low, uint16_t high) {
//    if (high < low)
//        high = low;

//    //    CncParam::inputLevel = value;

//        try {
//            if (isOpen()) {
//                if (!enable)
//                    com->write32(ADDR::ADC_ENA, 0);
//                else
//                    com->write64(ADDR::ADC_THDL, static_cast<uint64_t>(enable)<<32 | static_cast<uint64_t>(high)<<16 | low);

//                return true;
//            }
//        }
//        catch (...) {}

//        qDebug("WRITE ADC THRESHOLD LEVEL ERROR");
//        return false;
//}

//bool Cnc::writeAdcThresholdVolt(bool enable, double low, double high) {
//    return writeAdcThreshold( enable, cnc_adc_volt_t::toCode(0, low), cnc_adc_volt_t::toCode(0, high) );
//}

//bool Cnc::readAdcThreshold(bool& enable, uint16_t& low, uint16_t& high) {
//    try {
//        if (isOpen()) {
//            uint64_t data = com->read64(ADDR::ADC_THDL);
//            low = static_cast<uint16_t>(data);
//            high = static_cast<uint16_t>(data>>16);
//            enable = (data & (1ULL << 32)) != 0;
////            CncParam::inputLevel = value;
//            return true;
//        }
//    } catch (...) {}

//    qDebug("WRITE ADC THRESHOLD LEVEL ERROR");
//    return false;
//}

//bool Cnc::readAdcThresholdVolt(bool& enable, double& low, double& high) {
//    uint16_t low_code, high_code;

//    bool OK = readAdcThreshold(enable, low_code, high_code);
//    low = cnc_adc_volt_t::toVolt(0, low_code);
//    high = cnc_adc_volt_t::toVolt(0, high_code);
//    return OK;
//}

bool Cnc::writeFeedback(bool enable, double Vlow, double Vhigh, double to_sec, uint32_t attempts, double length_mm, double speed_mmm) {
//    int Vthld_max = static_cast<int>( round(cnc_adc_volt_t::maxVolt(0)) );
//    Vlow  = Vlow  > Vthld_max ? Vthld_max : Vlow;
//    Vhigh = Vhigh > Vthld_max ? Vthld_max : Vhigh;

    if (Vhigh < Vlow)
        Vhigh = Vlow;

    try {
        if (isOpen()) {
            if (!enable)
                com->write32(ADDR::FB_ENA, 0);
            else {
                vector<uint8_t> v = vector<uint8_t>(6 * sizeof(uint32_t));

                uint32_t data = enable;
                memcpy(&v[0], reinterpret_cast<uint8_t*>(&data), sizeof(uint32_t));

                data = static_cast<uint32_t>(cnc_adc_volt_t::toCode(0, Vhigh))<<16 | cnc_adc_volt_t::toCode(0, Vlow);
                memcpy(&v[4], reinterpret_cast<uint8_t*>(&data), sizeof(uint32_t));

                uint32_t ms = static_cast<uint32_t>(round(to_sec * 1e3));
                memcpy(&v[8], reinterpret_cast<uint8_t*>(&ms), sizeof(uint32_t));

                memcpy(&v[12], reinterpret_cast<uint8_t*>(&attempts), sizeof(uint32_t));

                float mm = length_mm;
                memcpy(&v[16], reinterpret_cast<uint8_t*>(&mm), sizeof(float));

                float mmm = speed_mmm;
                memcpy(&v[20], reinterpret_cast<uint8_t*>(&mmm), sizeof(float));

                com->write(ADDR::FB_ENA, v);
            }

            return true;
        }
    } catch (...) {}

    return false;
}

bool Cnc::readFeedback(bool &enable, double &Vlow, double &Vhigh, double &to_sec, uint32_t &attempts, double &length_mm, double &speed_mmm) {
    try {
        if (isOpen()) {
            vector<uint8_t> v = com->read(ADDR::FB_ENA, 6 * sizeof(uint32_t));

            if (v.size() == 6 * sizeof(uint32_t)) {
                enable = (v[0] & 1) != 0;
                Vlow = cnc_adc_volt_t::toVolt(0, BitConverter::toUInt16(v, 4));
                Vhigh = cnc_adc_volt_t::toVolt(0, BitConverter::toUInt16(v, 6));
                to_sec = BitConverter::toUInt32(v, 8) / 1e3;
                attempts = BitConverter::toUInt32(v, 12);
                length_mm = BitConverter::toFloat(v, 16);
                speed_mmm = BitConverter::toFloat(v, 20);
                return true;
            }
        }
    } catch (...) {}

    return false;
}
