#include "form_settings.h"
#include <cstdint>
#include <QToolTip>

#include "program_param.h"

// todo: message view
FormSettings::FormSettings(ProgramParam& par, QWidget *parent) : QWidget(parent), par(par) {
    createSettingsWidget();
    createButtons();

//    setFontPointSize(14);

    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(widgetSettings, Qt::AlignTop | Qt::AlignHCenter);
    mainLayout->addLayout(gridButtons);

    this->setLayout(mainLayout);
}

QGroupBox* FormSettings::groupLabelNum(QLabel* label, QDoubleSpinBox* num) {
    QGroupBox* group = new QGroupBox;
    label->setBuddy(num);
    group->setLayout(new QHBoxLayout);
    group->layout()->addWidget(label);
    group->layout()->addWidget(num);
    return group;
}

QGroupBox* FormSettings::groupLabelNum(QLabel* label, QSpinBox* num, QComboBox* combo) {
    QGroupBox* group = new QGroupBox;
    label->setBuddy(num);
    group->setLayout(new QHBoxLayout);
    group->layout()->addWidget(label);
    group->layout()->addWidget(num);
    group->layout()->addWidget(combo);
    return group;
}

QGroupBox* FormSettings::groupLabelCombo(QLabel* label, QComboBox* combo) {
    QGroupBox* group = new QGroupBox;
    label->setBuddy(combo);
    group->setLayout(new QHBoxLayout);
    group->layout()->addWidget(label);
    group->layout()->addWidget(combo);
    return group;
}

void FormSettings::createSettingsWidget() {
    widgetSettings = new QWidget(this);
    gridSettings = new QGridLayout;

    labelTitle = new QLabel("<h2>" + tr("Options") + "</h2>");
    labelCNC = new QLabel("<h3>" + tr("CNC parameters") + "</h3>");
//    labelTitle->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

    labelLanguage = new QLabel("Language: ");

    comboLanguage = new QComboBox;
    comboLanguage->addItem("English");
    comboLanguage->addItem("Русский");

    comboLanguage->setCurrentIndex(int(ProgramParam::lang));

    checkSwapXY = new QCheckBox(tr("Swap plot axes X, Y"));
    checkSwapXY->setCheckState(ProgramParam::swapXY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    labelInputLevel = new QLabel(tr("Input Levels, bits") + ": ");
    numInputLevel = new QSpinBox;
    numInputLevel->setDisplayIntegerBase(16);
//    QFont font = spinKeyLevel->font();
//    font.setCapitalization(QFont::AllUppercase);
//    spinKeyLevel->setFont(font);
    numInputLevel->setPrefix("0x");
//    spinKeyLevel->setRange(INT32_MIN, INT32_MAX);
    numInputLevel->setRange(0, INT32_MAX);
    numInputLevel->setValue(int(CncParam::inputLevel));

    comboInputLevel = new QComboBox(this);
    comboInputLevel->addItem(tr(""));
    comboInputLevel->addItem(tr("Metal"));
    comboInputLevel->addItem(tr("Stone"));
    comboInputLevel->addItem(tr("Debug"));

    labelStep = new QLabel(tr("Calculation step, mm") + ": ");
    numStep = new QDoubleSpinBox;
    numStep->setValue(0.001);
    numStep->setRange(0.001, 1.0);
    numStep->setSingleStep(0.001);
    numStep->setDecimals(3);

    labelX = new QLabel("X:");
    labelY = new QLabel("Y:");
    labelU = new QLabel("U:");
    labelV = new QLabel("V:");
    labelEncX = new QLabel("X:");
    labelEncY = new QLabel("Y:");

    labelPrecision = new QLabel(tr("Precision (steps/mm)"));
    labelMotor = new QLabel(tr("Motor"));
    labelEncoder = new QLabel(tr("Encoder"));

    //
    numScaleX = new QDoubleSpinBox;
    numScaleY = new QDoubleSpinBox;
    numScaleU = new QDoubleSpinBox;
    numScaleV = new QDoubleSpinBox;
    numEncScaleX = new QDoubleSpinBox;
    numEncScaleY = new QDoubleSpinBox;

    scaleNum = {numScaleX, numScaleY, numScaleU, numScaleV};
    encScaleNum = {numEncScaleX, numEncScaleY};

    // Scale
    for (size_t i = 0; i < scaleNum.size(); i++) {
        scaleNum[i]->setRange(1, 10000);
        scaleNum[i]->setSingleStep(1);
        scaleNum[i]->setDecimals(0);
    }

    scaleNum[0]->setValue(CncParam::DEFAULT_SCALE_XY);
    scaleNum[1]->setValue(CncParam::DEFAULT_SCALE_XY);
    scaleNum[2]->setValue(CncParam::DEFAULT_SCALE_UV);
    scaleNum[3]->setValue(CncParam::DEFAULT_SCALE_UV);

    for (size_t i = 0; i < encScaleNum.size(); i++) {
        encScaleNum[i]->setRange(1, 10000);
        encScaleNum[i]->setSingleStep(1);
        encScaleNum[i]->setDecimals(0);
    }

    encScaleNum[0]->setValue(CncParam::DEFAULT_ENC_SCALE);
    encScaleNum[1]->setValue(CncParam::DEFAULT_ENC_SCALE);

#ifndef DEV
    numStep->setEnabled(false);
    for (QDoubleSpinBox*& o: scaleNum)
        o->setEnabled(false);
    for (QDoubleSpinBox*& o: encScaleNum)
        o->setEnabled(false);
#endif

    setFontPointSize(16);

    gridSettings = new QGridLayout;

    gridSettings->addWidget(labelTitle, 0, 1, 1, 4, Qt::AlignHCenter | Qt::AlignBottom);
    gridSettings->addWidget(new QFrame, 1, 0, 1, 4);

    gridSettings->addWidget(groupLabelCombo(labelLanguage, comboLanguage), 2, 1, 1, 2);
    gridSettings->addWidget(checkSwapXY, 3, 1, 1, 4);

    gridSettings->addWidget(new QFrame, 4, 0, 1, 4);
    gridSettings->addWidget(labelCNC, 5, 1, 1, 4, Qt::AlignHCenter | Qt::AlignBottom);

    gridSettings->addWidget(groupLabelNum(labelInputLevel, numInputLevel, comboInputLevel), 6, 1, 1, 3);

    gridSettings->addWidget(groupLabelNum(labelStep, numStep), 7, 1, 1, 2);

    gridSettings->addWidget(labelPrecision, 8, 1, 1, 4, Qt::AlignHCenter | Qt::AlignBottom);

    gridSettings->addWidget(labelMotor, 9, 0);
    gridSettings->addWidget(groupLabelNum(labelX, numScaleX), 9, 1, 1, 2);
    gridSettings->addWidget(groupLabelNum(labelY, numScaleY), 9, 3, 1, 2);

#ifndef STONE
    gridSettings->addWidget(groupLabelNum(labelU, numScaleU), 10, 1, 1, 2);
    gridSettings->addWidget(groupLabelNum(labelV, numScaleV), 10, 3, 1, 2);
#endif

    gridSettings->addWidget(labelEncoder, 11, 0);
    gridSettings->addWidget(groupLabelNum(labelEncX, numEncScaleX), 11, 1, 1, 2);
    gridSettings->addWidget(groupLabelNum(labelEncY, numEncScaleY), 11, 3, 1, 2);

//    gridSettings->addWidget(new QFrame, 0, 3, 8, 1);
//    gridSettings->addWidget(new QFrame, 8, 0, 1, 4);

//    gridSettings->setSizeConstraint(QLayout::SetFixedSize);
    QWidget* widgetInside = new QWidget(this);
    widgetInside->setLayout(gridSettings);

    QGridLayout* grid = new QGridLayout;
    grid->addWidget(new QFrame, 0, 0);
    grid->addWidget(widgetInside, 0, 1);
    grid->addWidget(new QFrame, 0, 2);
    grid->addWidget(new QFrame, 1, 0, 1, 3);

    widgetSettings->setLayout(grid);

    //
    connect(comboLanguage, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [&](int i) {
        switch (i) {
        case int(InterfaceLanguage::RUSSIAN):
            ProgramParam::saveInterfaceLanguage(InterfaceLanguage::RUSSIAN);
            break;
        default:
            ProgramParam::saveInterfaceLanguage(InterfaceLanguage::ENGLISH);
            break;
        }

        showWarning("Interface language will be changed after reboot");
    });

    connect(checkSwapXY, &QCheckBox::stateChanged, [&](int) {
        ProgramParam::saveSwapXY(checkSwapXY->isChecked());
    });

    connect(comboInputLevel, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [&](int i) {
        numInputLevel->blockSignals(true);

        switch (i) {
        case 1: numInputLevel->setValue(CncParam::INPUT_LEVEL_METAL); break;
        case 2: numInputLevel->setValue(CncParam::INPUT_LEVEL_STONE); break;
        case 3: numInputLevel->setValue(CncParam::INPUT_LEVEL_DEBUG); break;
        }

        numInputLevel->blockSignals(false);
    });

    connect(numInputLevel, QOverload<int>::of(&QSpinBox::valueChanged), this, [&](int /*value*/) {
        comboInputLevel->setCurrentIndex(0);
    });
}

FormSettings::~FormSettings() {}

void FormSettings::setFontPointSize(int pointSize) {
    QFont font;

    for (QPushButton* b: buttons) {
        font = b->font();
        font.setPointSize(pointSize);
        b->setFont(font);
    }

    font = labelX->font();
    font.setPointSize(pointSize + 2);

    labelTitle->setFont(font);
    labelCNC->setFont(font);
    labelLanguage->setFont(font);
    labelInputLevel->setFont(font);
    labelStep->setFont(font);

    labelX->setFont(font);
    labelY->setFont(font);
    labelU->setFont(font);
    labelV->setFont(font);
    labelEncX->setFont(font);
    labelEncY->setFont(font);

    labelPrecision->setFont(font);
    labelMotor->setFont(font);
    labelEncoder->setFont(font);

    //
    font = comboLanguage->font();
    font.setPointSize(pointSize + 2);

    comboLanguage->setFont(font);
    comboInputLevel->setFont(font);

    //
    font = numStep->font();
    font.setPointSize(pointSize + 2);

    numInputLevel->setFont(font);
    numStep->setFont(font);

    numScaleX->setFont(font);
    numScaleY->setFont(font);
    numScaleU->setFont(font);
    numScaleV->setFont(font);
    numEncScaleX->setFont(font);
    numEncScaleY->setFont(font);

    font = checkSwapXY->font();
    font.setPointSize(pointSize + 2);
    checkSwapXY->setFont(font);
}

void FormSettings::createButtons() {
    btnHome = new QPushButton();
    btnHome->setText(tr("Back"));

    btnRead = new QPushButton();
    btnRead->setText(tr("Read"));

    btnWrite = new QPushButton();
    btnWrite->setText(tr("Write"));

    btn3 = new QPushButton();
    btn3->setText(tr(""));
    btn3->setEnabled(false);

    btn4 = new QPushButton();
    btn4->setText(tr(""));
    btn4->setEnabled(false);

    btn5 = new QPushButton();
    btn5->setText(tr(""));
    btn5->setEnabled(false);

    btn6 = new QPushButton();
    btn6->setText(tr(""));
    btn6->setEnabled(false);

    btn7 = new QPushButton();
    btn7->setText(tr(""));
    btn7->setEnabled(false);

    btn8 = new QPushButton();
    btn8->setText(tr(""));
    btn8->setEnabled(false);

    btn9 = new QPushButton();
    btn9->setText(tr(""));
    btn9->setEnabled(false);

    btn10 = new QPushButton();
    btn10->setText(tr(""));
    btn10->setEnabled(false);

    btn11 = new QPushButton();
    btn11->setText(tr(""));
    btn11->setEnabled(false);

    btn12 = new QPushButton();
    btn12->setText(tr(""));
    btn12->setEnabled(false);

    btnHelp = new QPushButton();
    btnHelp->setText(tr("Help"));

    buttons = {btnHome, btnRead, btnWrite, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btnHelp};

    gridButtons = new QGridLayout();

    gridButtons->addWidget(btnHome, 0, 0);
    gridButtons->addWidget(btnRead, 0, 1);
    gridButtons->addWidget(btnWrite, 0, 2);
    gridButtons->addWidget(btn3, 0, 3);
    gridButtons->addWidget(btn4, 0, 4);
    gridButtons->addWidget(btn5, 0, 5);
    gridButtons->addWidget(btn6, 0, 6);
    gridButtons->addWidget(btn7, 0, 7);
    gridButtons->addWidget(btn8, 0, 8);
    gridButtons->addWidget(btn9, 0, 9);
    gridButtons->addWidget(btn10, 0, 10);
    gridButtons->addWidget(btn11, 0, 11);
    gridButtons->addWidget(btn12, 0, 12);
    gridButtons->addWidget(btnHelp, 0, 13);

    connect(btnHome, &QPushButton::clicked, this, [&]() {
        showInfo(QString());
        emit homePageClicked();
    });

    connect(btnRead, &QPushButton::clicked, this, [&]() {
        bool err;
        const uint16_t value = par.cnc.readInputLevel(&err);

        if (!err) {
            ProgramParam::saveInputLevel(value);
            numInputLevel->setValue(value);
            comboInputLevel->setCurrentIndex(0);
            showInfo("Read OK");
        }
        else {
            qDebug("Read Input Levels ERROR!\n");
//            setStatusTip("Read Input Levels ERROR!");
            showError("Read ERROR!");
        }
    });

    connect(btnWrite, &QPushButton::clicked, this, [&]() {
        uint16_t value = static_cast<uint16_t>(numInputLevel->value() & 0xFFFF);
        ProgramParam::saveInputLevel(value);

        bool OK = par.cnc.writeInputLevel(CncParam::inputLevel);

        if (OK)
            showInfo("Write OK");
        else
            showError("Write ERROR!");

        btnRead->click();
    });

    connect(btnHelp, &QPushButton::clicked, this, [&]() { emit helpPageClicked(help_file); });
}
