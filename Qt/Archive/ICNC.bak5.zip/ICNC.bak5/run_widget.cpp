#include "run_widget.h"
#include <QDebug>
#include <QList>
#include "program_param.h"
#include <cmath>
#include "aux_func.h"

using namespace std;

RunWidget::RunWidget(QWidget *parent) : QWidget(parent), plotView(QwtPlotView()) {
    createButtons();
    createTextBoxes();
    createState();

//    setFontPointSize(14);

    QGridLayout *grid = new QGridLayout;
    grid->addLayout(gridState, 0, 0, Qt::AlignTop);
    grid->addLayout(gridButton, 1, 0, Qt::AlignBottom);

    gridMain = new QGridLayout;
//    gridMain->addWidget(plotView.give(), 0, 0, Qt::AlignLeft | Qt::AlignTop);

//    gridMain->addWidget(plotView.give(), 0, 0);
//    gridMain->addLayout(gridState, 0, 1, Qt::AlignRight | Qt::AlignTop);
//    gridMain->addLayout(gridText, 1, 0);
//    gridMain->addLayout(gridButton, 1, 1, Qt::AlignRight | Qt::AlignTop);

    gridMain->addWidget(plotView.give(), 0, 0);
    gridMain->addLayout(grid, 0, 1, 2, 1, Qt::AlignRight);
    gridMain->addLayout(gridText, 1, 0);

    this->setLayout(gridMain);

    qDebug() << "RunWidget constractor: " << size();
}

void RunWidget::createButtons() {
    btnStart = new QPushButton;
    btnReverse = new QPushButton;
    btnCancel = new QPushButton;

    btnHold = new QPushButton;
    btnHold->setText(tr("Hold"));
    btnHold->setCheckable(true);
    btnHold->setStatusTip(tr("Holding of stepper motors on/off"));

    setButtonsEnabled(1, 0, 0, 1);
    setButtonsText({tr("Start"), tr("Reverse"), tr("Cancel")});

    labelSpeed = new QLabel(tr("Speed") + ": ");

    numSpeed = new QDoubleSpinBox;
    numSpeed->setRange(0, 100);
    numSpeed->setSingleStep(0.1);

    speedMMM = new QRadioButton(tr("mm/min"));
    speedUMS = new QRadioButton(tr("um/sec"));

    checkIdle = new QCheckBox(tr("Idle run"));
    checkIdle->setCheckState(Qt::CheckState::PartiallyChecked);

    groupSpeed = new QGroupBox;
    groupSpeed->setLayout(new QHBoxLayout);
    groupSpeed->layout()->addWidget(speedMMM);
    groupSpeed->layout()->addWidget(speedUMS);

    groupSpeed->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    speedMMM->click();

    gridButton = new QGridLayout;
    gridButton->addWidget(btnStart, 0, 0, 1, 2);
    gridButton->addWidget(btnReverse, 1, 0);
    gridButton->addWidget(btnCancel, 1, 1);
    gridButton->addWidget(btnHold, 2, 0, 1, 2);
    gridButton->addWidget(labelSpeed, 3, 0);
    gridButton->addWidget(numSpeed, 3, 1);
    gridButton->addWidget(groupSpeed, 4, 0, 1, 2);
    gridButton->addWidget(checkIdle, 5, 0, 1, 2);

    //
    buttons = {btnStart, btnReverse, btnCancel, btnHold};
    labels = {labelSpeed};
    nums = {numSpeed};
    radio = {speedMMM, speedUMS};
}

void RunWidget::createTextBoxes() {
    txtCode = new CodeEditor;
    txtCode->setReadOnly(true);

    int h = txtCode->fontMetrics().lineSpacing();
    h *= 5;
//    h += txtCode->fontMetrics().leading();

    QTextDocument* pdoc = txtCode->document();
    QMargins margins = txtCode->contentsMargins();
    h += static_cast<int>(pdoc->documentMargin()) + margins.top() + margins.bottom();

    txtCode->setFixedHeight(h);

    txtMsg = new QTextEdit;
    txtMsg->setReadOnly(true);

    txtMsg->setFixedHeight(h);

    gridText = new QGridLayout;
    gridText->addWidget(txtCode, 0, 0);
    gridText->addWidget(txtMsg, 0, 1);
}

void RunWidget::createState() {
    gridState = new QGridLayout;

    labelX = new QLabel(R"(<font color=blue>X</font>)");
    labelY = new QLabel(R"(<font color=blue>Y</font>)");
#if !defined(STONE)
    labelU = new QLabel(R"(<font color=blue>U</font>)");
    labelV = new QLabel(R"(<font color=blue>V</font>)");
#else
    labelU = new QLabel;
    labelV = new QLabel;
#endif
    labelTime = new QLabel(R"(<font color=blue>)" + tr("Time") + R"(</font>)");
    labelETA = new QLabel(R"(<font color=blue>)" + tr("Remain") + R"(</font>)");

    posLabels = {new QLabel, new QLabel, new QLabel, new QLabel, new QLabel, new QLabel, labelX, labelY, labelU, labelV, labelTime, labelETA};

    for (size_t i = 0; i < posLabels.size(); i++) {
        if (i < ProgramParam::AXES_NUM)
            setPositionLabels(i, 0);
    }
    setElapsedTime(0, 0, 0);
    setRemainTime(0, 0, 0);

    // Limit Switches
    labelPWR = new QLabel("PWR");
    labelFB = new QLabel("FB");
    labelTO = new QLabel("TO");
    labelWB = new QLabel("WB");
    labelLS = new QLabel("LS");
    labelFWD = new QLabel("FWD");
    labelREV = new QLabel("REV");

    checkLabels = {labelPWR, labelFB, labelTO, labelWB, labelLS, labelFWD, labelREV};

    checkPWR = new QCheckBox;
    checkPWR->setEnabled(false);
    checkFB = new QCheckBox;
    checkFB->setEnabled(false);
    checkTO = new QCheckBox;
    checkTO->setEnabled(false);
    checkWB = new QCheckBox;
    checkWB->setEnabled(false);
    checkLS = new QCheckBox;
    checkLS->setEnabled(false);
    checkFWD = new QCheckBox;
    checkFWD->setEnabled(false);
    checkREV = new QCheckBox;
    checkREV->setEnabled(false);

    gridLS = new QGridLayout;

    gridLS->addWidget(labelPWR, 0, 0, Qt::AlignCenter);
    gridLS->addWidget(labelFB, 0, 1, Qt::AlignCenter);
    gridLS->addWidget(labelTO, 0, 2, Qt::AlignCenter);
    gridLS->addWidget(labelWB, 0, 3, Qt::AlignCenter);
    gridLS->addWidget(labelLS, 0, 4, Qt::AlignCenter);
    gridLS->addWidget(labelFWD, 0, 5, Qt::AlignCenter);
    gridLS->addWidget(labelREV, 0, 6, Qt::AlignCenter);
    gridLS->addWidget(checkPWR, 1, 0, Qt::AlignCenter);
    gridLS->addWidget(checkFB, 1, 1, Qt::AlignCenter);
    gridLS->addWidget(checkTO, 1, 2, Qt::AlignCenter);
    gridLS->addWidget(checkWB, 1, 3, Qt::AlignCenter);
    gridLS->addWidget(checkLS, 1, 4, Qt::AlignCenter);
    gridLS->addWidget(checkFWD, 1, 5, Qt::AlignCenter);
    gridLS->addWidget(checkREV, 1, 6, Qt::AlignCenter);

    //
    gridState->addWidget(labelX, 0, 0);
    gridState->addWidget(posLabels[0], 0, 1, Qt::AlignRight);

    gridState->addWidget(labelY, 1, 0);
    gridState->addWidget(posLabels[1], 1, 1, Qt::AlignRight);

    gridState->addWidget(labelU, 2, 0);
    gridState->addWidget(posLabels[2], 2, 1, Qt::AlignRight);

    gridState->addWidget(labelV, 3, 0);
    gridState->addWidget(posLabels[3], 3, 1, Qt::AlignRight);

    gridState->addWidget(labelTime, 4, 0);
    gridState->addWidget(posLabels[4], 4, 1, Qt::AlignRight);

    gridState->addWidget(labelETA, 5, 0);
    gridState->addWidget(posLabels[5], 5, 1, Qt::AlignRight);

    gridState->addLayout(gridLS, 6, 0, 1, 2);

    gridState->setSizeConstraint(QLayout::SetFixedSize);
}

RunWidget::~RunWidget() {}

void RunWidget::setButtonsEnabled(bool start_ena, bool reverse_ena, bool cancel_ena, bool hold_ena) {
    btnStart->setEnabled(start_ena);
    btnReverse->setEnabled(reverse_ena);
    btnCancel->setEnabled(cancel_ena);
    btnHold->setEnabled(hold_ena);
}

void RunWidget::setButtonsText(const QString (&text)[3]) {
    if (text[0].length() != 0) btnStart->setText(text[0]);
    if (text[1].length() != 0) btnReverse->setText(text[1]);
    if (text[2].length() != 0) btnCancel->setText(text[2]);
}

void RunWidget::setPositionLabels(size_t axis_num, int value) {
    if (axis_num < ProgramParam::AXES_NUM) {        
        bool sign = value < 0;
        value = std::abs(value);

        double scale = 1;
        switch (axis_num) {
            case 0: scale = X_SCALE; break;
            case 1: scale = Y_SCALE; break;
            case 2: scale = U_SCALE; break;
            case 3: scale = V_SCALE; break;
        }

        uint32_t value_um = static_cast<uint32_t>( std::round(double(value) / scale * 1e3) );
        QString s = QString::asprintf("%c%04d.%03d", sign ? '-' : ' ', value_um / 1000, value_um % 1000);

#if defined(STONE)
        if (axis_num < 2)
            posLabels[axis_num]->setText(R"(<font color=red>)" + s + R"(</font>)");
#else
        posLabels[axis_num]->setText(R"(<font color=red>)" + s + R"(</font>)");
#endif
    }
}

void RunWidget::setElapsedTime(int h, int m, int s) {
    QString str = QString::asprintf("%02d:%02d:%02d", h, m, s);
    posLabels[4]->setText(R"(<font color=red>)" + str + R"(</font>)");
//    qDebug("%s\n", str.toStdString().c_str());
}

void RunWidget::setElapsedTime(qint64 ms) {
    using namespace aux_func;
    HMS hms(ms);
    setElapsedTime(int(hms.h), int(hms.m), int(hms.s));
//    qDebug("%d ms\n", int(ms));
}

void RunWidget::setRemainTime(int h, int m, int s) {
    QString str = QString::asprintf("%02d:%02d:%02d", h, m, s);
    posLabels[5]->setText(R"(<font color=red>)" + str + R"(</font>)");
}

void RunWidget::setRemainTime(qint64 ms) {
    using namespace aux_func;
    HMS hms(ms);
    setRemainTime(int(hms.h), int(hms.m), int(hms.s));
}

void RunWidget::setFontPointSize(int pointSize) {
    for (QPushButton* o: buttons) {
        QFont font = o->font();
        font.setPointSize(pointSize);
        o->setFont(font);
    //        o->setStyleSheet("font: bold");
    }

    for (QLabel* o: labels) {
        QFont font = o->font();
        font.setPointSize(pointSize);
        o->setFont(font);
    }

    for (QLabel* o: checkLabels) {
        QFont font = o->font();
        font.setPointSize(pointSize);
        o->setFont(font);
    }

    for (QDoubleSpinBox* o: nums) {
        QFont font = o->font();
        font.setPointSize(pointSize);
        o->setFont(font);
    }

    for (QRadioButton* o: radio) {
        QFont font = o->font();
        font.setPointSize(static_cast<int>( round(pointSize * 0.8) ));
        o->setFont(font);
    }

    for (size_t i = 0; i < posLabels.size(); i++) {
        QLabel*& label = posLabels[i];

        label->setSizePolicy( QSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum) );
        QFont font = label->font();
        font.setPointSize(pointSize * 2);
        font.setBold(true);
        label->setFont(font);
    }

    {
        QFont font = checkIdle->font();
        font.setPointSize(pointSize);
        checkIdle->setFont(font);
    }
}

//void RunWidget::setETA(int value) {
////        bool sign = value < 0;
////        value = std::abs(value);
////        uint32_t value_um = static_cast<uint32_t>( std::round(double(value) / CNC_SCALE * 1e3) );
////        QString s = QString::asprintf("%c%04d.%03d", sign ? '-' : ' ', value_um / 1000, value_um % 1000);
////        posLabels[axis_num]->setText(R"(<font color=red>)" + s + R"(</font>)");
//}

void RunWidget::plot(const ContourList& contourList, bool swapXY) {
    plotView.setSwapXY(swapXY);
    plotView.plot(contourList);
}

QSize RunWidget::plotViewSize() const {
    return plotViewSize(size());
}

QSize RunWidget::plotViewSize(const QSize& formSize) const {
    int codeHeight = gridText->sizeHint().height();
    int stateWidth = gridState->sizeHint().width();

    int w = formSize.width() - stateWidth;
    int h = formSize.height() - codeHeight;

    QSize res(w, h);

    qDebug() << "Widget size: " << size() << ", plot size:" << res << ", msg height: " << codeHeight << ", state width: " << stateWidth;

    return res;
}

void RunWidget::resizeEvent(QResizeEvent* event) {
    if (!plotView.onResizeEvent( plotViewSize(event->size()) ))
        event->ignore();
}
