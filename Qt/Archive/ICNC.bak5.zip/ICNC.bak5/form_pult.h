#ifndef FORMPULT_H
#define FORMPULT_H

#include <QWidget>
#include <QPushButton>
#include <QSpinBox>
#include <QGroupBox>

#include "program_param.h"
#include "pult_widget.h"
#include "start_stop_elapsed_timer.h"

class FormPult : public QWidget {
    Q_OBJECT

    const QString help_file = "pult.html";
    const int POLLING_TIME = 1000 / 5; // ms

    ProgramParam& par;
    PultWidget* pultWidget;
    bool cncReaderEna;

    QLabel *labelWidth, *labelRatio, *labelVoltage, *labelCurrent, *labelDrum;
    std::vector<QLabel*> labels;

    QSpinBox *numWidth, *numRatio, *numVoltage, *numCurrent, *numDrumVel;
    std::vector<QSpinBox*> nums;

    QGroupBox *groupWidth, *groupRatio, *groupVoltage, *groupCurrent, *groupDrum;

    QPushButton *btnHome, *btnDrum, *btnPump, *btnWire, *btnVoltage, *btnWidthDec, *btnWidthInc, *btnRatioInc, *btnRatioDec,\
        *btnVoltageDec, *btnVoltageInc, *btnCurrentDec, *btnCurrentInc, *btnDrumVelDec, *btnDrumVelInc, *btnHelp;

    std::vector<QPushButton*> buttons;

    QGridLayout* gridButtons;
    QVBoxLayout* mainLayout;

    bool cutStateAbortReq = false;
    WireSpeed::Mode wireSpeedMode;

    StartStopElapsedTimer* timer;

    void addButtons();
    void createButtonLayout();

    void _init();
    void updateButtons();

    void startTimer();
    void stopTimer();

private slots:
    void on_btnHome_clicked();

    void on_btnMove_clicked();
    void on_btnSet_clicked();

    void on_btnStop_clicked();

    void startCncReader();
    void stopCncReader();
    void readCutState();

public:
//    explicit FormRun(QWidget *parent = nullptr);
    FormPult(ProgramParam& par, QWidget *parent = nullptr);
    ~FormPult();

    void setFontPointSize(int pointSize);

    void init();

signals:
    void homePageClicked();
    void helpPageClicked(const QString& file_name);
};

#endif // FORMPULT_H
