#include "cnc_backup.h"

#include <QSettings>
#include <QApplication>
#include <QDebug>

//CncContextBackup::CncContextBackup() {

//}
