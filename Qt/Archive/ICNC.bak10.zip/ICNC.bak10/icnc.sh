cd /home/cnc/Meatec/cnc2/
./icnc
