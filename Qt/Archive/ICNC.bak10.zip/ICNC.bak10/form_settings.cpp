#include "form_settings.h"
#include <cstdint>
#include <QToolTip>

#include "program_param.h"
#include <QScrollArea>

// todo: message view
FormSettings::FormSettings(ProgramParam& par, QWidget *parent) : QWidget(parent), par(par) {
    createSettingsWidget();
    createButtons();

//    setFontPointSize(14);

    QScrollArea* scrollArea = new QScrollArea;
    scrollArea->setWidget(widgetSettings);
    scrollArea->setAlignment(Qt::AlignTop | Qt::AlignHCenter);
    scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarPolicy::ScrollBarAlwaysOn);

    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(scrollArea, Qt::AlignTop | Qt::AlignHCenter);
    mainLayout->addLayout(gridButtons);

    this->setLayout(mainLayout);
}

QGroupBox* FormSettings::groupLabelNum(QLabel* label, QDoubleSpinBox* num) {
    QGroupBox* group = new QGroupBox;
    label->setBuddy(num);
    group->setLayout(new QHBoxLayout);
    group->layout()->addWidget(label);
    group->layout()->addWidget(num);
    return group;
}

QGroupBox* FormSettings::groupLabelNum(QLabel* label, QSpinBox* num, QComboBox* combo) {
    QGroupBox* group = new QGroupBox;
    label->setBuddy(num);
    group->setLayout(new QHBoxLayout);
    group->layout()->addWidget(label);
    group->layout()->addWidget(num);
    group->layout()->addWidget(combo);
    return group;
}

QGroupBox* FormSettings::groupLabelCombo(QLabel* label, QComboBox* combo) {
    QGroupBox* group = new QGroupBox;
    label->setBuddy(combo);
    group->setLayout(new QHBoxLayout);
    group->layout()->addWidget(label);
    group->layout()->addWidget(combo);
    return group;
}

void FormSettings::createSettingsWidget() {
    widgetSettings = new QWidget(this);
    gridSettings = new QGridLayout;

    labelTitle = new QLabel("<h2>" + tr("Application settings") + "</h2>");
    labelCNC = new QLabel("<h3>" + tr("CNC parameters") + "</h3>");
//    labelTitle->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

    labelLanguage = new QLabel("Language: ");

    comboLanguage = new QComboBox;
    comboLanguage->addItem("English");
    comboLanguage->addItem("Русский");

    comboLanguage->setCurrentIndex(int(ProgramParam::lang));

    checkSwapXY = new QCheckBox(tr("Swap plot axes X, Y"));
    checkSwapXY->setCheckState(ProgramParam::swapXY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkReverseX = new QCheckBox(tr("Reverse plot axis X"));
    checkReverseX->setCheckState(ProgramParam::reverseX ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkReverseY = new QCheckBox(tr("Reverse plot axis Y"));
    checkReverseY->setCheckState(ProgramParam::reverseY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkShowXY = new QCheckBox(tr("Show plot axes names"));
    checkShowXY->setCheckState(ProgramParam::showXY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    labelInputLevel = new QLabel(tr("Input Levels, bits") + ": ");
    numInputLevel = new QSpinBox;
    numInputLevel->setDisplayIntegerBase(16);
//    QFont font = spinKeyLevel->font();
//    font.setCapitalization(QFont::AllUppercase);
//    spinKeyLevel->setFont(font);
    numInputLevel->setPrefix("0x");
//    spinKeyLevel->setRange(INT32_MIN, INT32_MAX);
    numInputLevel->setRange(0, INT32_MAX);
    numInputLevel->setValue(int(CncParam::inputLevel));

    comboInputLevel = new QComboBox(this);
    comboInputLevel->addItem(tr(""));
    comboInputLevel->addItem(tr("Metal"));
    comboInputLevel->addItem(tr("Stone"));
    comboInputLevel->addItem(tr("Debug"));

    checkReverseMotorX = new QCheckBox(tr("Reverse motor X"));
    checkReverseMotorX->setCheckState(CncParam::reverseX ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkReverseMotorY = new QCheckBox(tr("Reverse motor Y"));
    checkReverseMotorY->setCheckState(CncParam::reverseY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkReverseMotorU = new QCheckBox(tr("Reverse motor U"));
    checkReverseMotorU->setCheckState(CncParam::reverseU ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkReverseMotorV = new QCheckBox(tr("Reverse motor V"));
    checkReverseMotorV->setCheckState(CncParam::reverseV ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkSwapMotorXY = new QCheckBox(tr("Swap motors X and Y"));
    checkSwapMotorXY->setCheckState(CncParam::swapXY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    checkSwapMotorUV = new QCheckBox(tr("Swap motors U and V"));
    checkSwapMotorUV->setCheckState(CncParam::swapUV ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

    labelAcc = new QLabel(tr("Acceleration") + ":", this);
    fnumAcc = new QDoubleSpinBox(this);
    fnumAcc->setRange(1, 1000);
    fnumAcc->setSuffix(" " + tr("um/sec2")); // per 100 V
    fnumAcc->setDecimals(0);
    fnumAcc->setSingleStep(10);
    fnumAcc->setValue(100);
#ifdef STONE
    fnumAcc->setEnabled(false);
#endif

    labelDec = new QLabel(tr("Deceleration") + ":", this);
    fnumDec = new QDoubleSpinBox(this);
    fnumDec->setRange(1, 1000);
    fnumDec->setSuffix(" " + tr("um/sec2")); // per 100 V
    fnumDec->setDecimals(0);
    fnumDec->setSingleStep(10);
    fnumDec->setValue(300);
#ifdef STONE
    fnumDec->setEnabled(false);
#endif

    // Feedback
    groupFeedback = new QGroupBox(tr("Feedback enable"));
    groupFeedback->setCheckable(true);
    groupFeedback->setChecked(false);

    labelHighThld = new QLabel(tr("High threshold"));
    labelLowThld = new QLabel(tr("Low threshold"));
    labelRbTimeout = new QLabel(tr("Rollback timeout"));
    labelRbAttempts = new QLabel(tr("Rollback attempts"));
    labelRbLength = new QLabel(tr("Rollback length"));
    labelRbSpeed = new QLabel(tr("Rollback speed"));

    int thld_max = static_cast<int>( round(cnc_adc_volt_t::maxVolt(0)) );

    numHighThld = new QSpinBox;
    labelHighThld->setBuddy(numHighThld);
    numHighThld->setRange(0, thld_max);
    numHighThld->setValue(thld_max);
    numHighThld->setSuffix(" " + tr("V"));

    numLowThld = new QSpinBox;
    labelLowThld->setBuddy(numLowThld);
    numLowThld->setRange(0, thld_max);
    numLowThld->setValue(0);
    numLowThld->setSuffix(" " + tr("V"));

    numRbTimeout = new QSpinBox;
    labelRbTimeout->setBuddy(numRbTimeout);
    numRbTimeout->setRange(10, 60);
    numRbTimeout->setSuffix(" " + tr("sec"));

    numRbAttempts = new QSpinBox;
    labelRbAttempts->setBuddy(numRbAttempts);
    numRbAttempts->setRange(1, 5);

    fnumRbLength = new QDoubleSpinBox;
    labelRbLength->setBuddy(fnumRbLength);
    fnumRbLength->setRange(0.100, 0.500);
    fnumRbLength->setSuffix(" " + tr("mm"));
    fnumRbLength->setDecimals(3);
    fnumRbLength->setSingleStep(0.01);

    fnumRbSpeed = new QDoubleSpinBox;
    labelRbSpeed->setBuddy(fnumRbSpeed);
    fnumRbSpeed->setRange(0.1, 2);
    fnumRbSpeed->setSuffix(" " + tr("mm/min"));
    fnumRbSpeed->setDecimals(1);
    fnumRbSpeed->setSingleStep(0.1);

    QGridLayout* gridFeedback = new QGridLayout;
    gridFeedback->addWidget(labelHighThld, 0, 0);
    gridFeedback->addWidget(numHighThld, 0, 1);
    gridFeedback->addWidget(labelLowThld, 1, 0);
    gridFeedback->addWidget(numLowThld, 1, 1);
    gridFeedback->addWidget(labelRbTimeout, 2, 0);
    gridFeedback->addWidget(numRbTimeout, 2, 1);
    gridFeedback->addWidget(labelRbAttempts, 3, 0);
    gridFeedback->addWidget(numRbAttempts, 3, 1);
    gridFeedback->addWidget(labelRbLength, 4, 0);
    gridFeedback->addWidget(fnumRbLength, 4, 1);
    gridFeedback->addWidget(labelRbSpeed, 5, 0);
    gridFeedback->addWidget(fnumRbSpeed, 5, 1);

    groupFeedback->setLayout(gridFeedback);

    //
    labelStep = new QLabel(tr("Calculation step") + ": ");
    numStep = new QDoubleSpinBox;
    numStep->setValue(0.001);
    numStep->setRange(0.001, 1.0);
    numStep->setSingleStep(0.001);
    numStep->setDecimals(3);
    numStep->setSuffix(" " + tr("mm"));

    labelX = new QLabel("X:");
    labelY = new QLabel("Y:");
    labelU = new QLabel("U:");
    labelV = new QLabel("V:");
    labelEncX = new QLabel("X:");
    labelEncY = new QLabel("Y:");

    labelPrecision = new QLabel(tr("Precision (steps/mm)"));
    labelMotor = new QLabel(tr("Motor"));
    labelEncoder = new QLabel(tr("Encoder"));

    //
    numScaleX = new QDoubleSpinBox;
    numScaleY = new QDoubleSpinBox;
    numScaleU = new QDoubleSpinBox;
    numScaleV = new QDoubleSpinBox;
    numEncScaleX = new QDoubleSpinBox;
    numEncScaleY = new QDoubleSpinBox;

    scaleNum = {numScaleX, numScaleY, numScaleU, numScaleV};
    encScaleNum = {numEncScaleX, numEncScaleY};

    // Scale
    for (size_t i = 0; i < scaleNum.size(); i++) {
        scaleNum[i]->setRange(1, 10000);
        scaleNum[i]->setSingleStep(1);
        scaleNum[i]->setDecimals(0);
    }

    scaleNum[0]->setValue(CncParam::DEFAULT_SCALE_XY);
    scaleNum[1]->setValue(CncParam::DEFAULT_SCALE_XY);
    scaleNum[2]->setValue(CncParam::DEFAULT_SCALE_UV);
    scaleNum[3]->setValue(CncParam::DEFAULT_SCALE_UV);

    for (size_t i = 0; i < encScaleNum.size(); i++) {
        encScaleNum[i]->setRange(1, 10000);
        encScaleNum[i]->setSingleStep(1);
        encScaleNum[i]->setDecimals(0);
    }

    encScaleNum[0]->setValue(CncParam::DEFAULT_ENC_SCALE);
    encScaleNum[1]->setValue(CncParam::DEFAULT_ENC_SCALE);

#ifndef DEV
    numStep->setEnabled(false);
    for (QDoubleSpinBox*& o: scaleNum)
        o->setEnabled(false);
    for (QDoubleSpinBox*& o: encScaleNum)
        o->setEnabled(false);
#endif

    setFontPointSize(16);

    gridSettings = new QGridLayout;

    gridSettings->addWidget(labelTitle, 0, 1, 1, 4, Qt::AlignHCenter | Qt::AlignBottom);
    gridSettings->addWidget(new QFrame, 1, 0, 1, 4);

    gridSettings->addWidget(groupLabelCombo(labelLanguage, comboLanguage), 2, 1, 1, 2);
    gridSettings->addWidget(checkSwapXY, 3, 1, 1, 4);
    gridSettings->addWidget(checkReverseX, 4, 1, 1, 4);
    gridSettings->addWidget(checkReverseY, 5, 1, 1, 4);
    gridSettings->addWidget(checkShowXY, 6, 1, 1, 4);

    gridSettings->addWidget(new QFrame, 7, 0, 1, 4);
    gridSettings->addWidget(labelCNC, 8, 1, 1, 4, Qt::AlignHCenter | Qt::AlignBottom);

    gridSettings->addWidget(groupLabelNum(labelInputLevel, numInputLevel, comboInputLevel), 9, 1, 1, 3);

    gridSettings->addWidget(groupLabelNum(labelStep, numStep), 10, 1, 1, 2);

    gridSettings->addWidget(checkReverseMotorX, 11, 1, 1, 4);
    gridSettings->addWidget(checkReverseMotorY, 12, 1, 1, 4);
#ifndef STONE
    gridSettings->addWidget(checkReverseMotorU, 13, 1, 1, 4);
    gridSettings->addWidget(checkReverseMotorV, 14, 1, 1, 4);
#endif
    gridSettings->addWidget(checkSwapMotorXY, 15, 1, 1, 4);
#ifndef STONE
    gridSettings->addWidget(checkSwapMotorUV, 16, 1, 1, 4);
#endif

    gridSettings->addWidget(groupLabelNum(labelAcc, fnumAcc), 17, 1, 1, 2);
    gridSettings->addWidget(groupLabelNum(labelDec, fnumDec), 18, 1, 1, 2);

#ifndef STONE
    gridSettings->addWidget(groupFeedback, 19, 1, 1, 2);
#endif

    gridSettings->addWidget(labelPrecision, 20, 1, 1, 4, Qt::AlignHCenter | Qt::AlignBottom);

    gridSettings->addWidget(labelMotor, 21, 0);
    gridSettings->addWidget(groupLabelNum(labelX, numScaleX), 21, 1, 1, 2);
    gridSettings->addWidget(groupLabelNum(labelY, numScaleY), 21, 3, 1, 2);

#ifndef STONE
    gridSettings->addWidget(groupLabelNum(labelU, numScaleU), 22, 1, 1, 2);
    gridSettings->addWidget(groupLabelNum(labelV, numScaleV), 22, 3, 1, 2);
#endif

    gridSettings->addWidget(labelEncoder, 23, 0);
    gridSettings->addWidget(groupLabelNum(labelEncX, numEncScaleX), 23, 1, 1, 2);
    gridSettings->addWidget(groupLabelNum(labelEncY, numEncScaleY), 23, 3, 1, 2);

//    gridSettings->addWidget(new QFrame, 0, 3, 8, 1);
//    gridSettings->addWidget(new QFrame, 8, 0, 1, 4);

//    gridSettings->setSizeConstraint(QLayout::SetFixedSize);
    QWidget* widgetInside = new QWidget(this);
    widgetInside->setLayout(gridSettings);

    QGridLayout* grid = new QGridLayout;
    grid->addWidget(new QFrame, 0, 0);
    grid->addWidget(widgetInside, 0, 1);
    grid->addWidget(new QFrame, 0, 2);
    grid->addWidget(new QFrame, 1, 0, 1, 3);

    widgetSettings->setLayout(grid);

    //
    connect(comboLanguage, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [&](int i) {
        switch (i) {
        case int(InterfaceLanguage::RUSSIAN):
            ProgramParam::saveInterfaceLanguage(InterfaceLanguage::RUSSIAN);
            break;
        default:
            ProgramParam::saveInterfaceLanguage(InterfaceLanguage::ENGLISH);
            break;
        }

        emit showWarning("Interface language will be changed after reboot");
    });

    connect(checkSwapXY, &QCheckBox::stateChanged, [&](int) {
        ProgramParam::saveSwapXY(checkSwapXY->isChecked());
    });

    connect(checkReverseX, &QCheckBox::stateChanged, [&](int) {
        ProgramParam::saveReverseX(checkReverseX->isChecked());
    });

    connect(checkReverseY, &QCheckBox::stateChanged, [&](int) {
        ProgramParam::saveReverseY(checkReverseY->isChecked());
    });

    connect(checkShowXY, &QCheckBox::stateChanged, [&](int) {
        ProgramParam::saveShowXY(checkShowXY->isChecked());
    });

    connect(comboInputLevel, QOverload<int>::of(&QComboBox::currentIndexChanged), this, [&](int i) {
        numInputLevel->blockSignals(true);

        switch (i) {
        case 1: numInputLevel->setValue(CncParam::INPUT_LEVEL_METAL); break;
        case 2: numInputLevel->setValue(CncParam::INPUT_LEVEL_STONE); break;
        case 3: numInputLevel->setValue(CncParam::INPUT_LEVEL_DEBUG); break;
        }

        numInputLevel->blockSignals(false);
    });

    connect(numInputLevel, QOverload<int>::of(&QSpinBox::valueChanged), this, [&](int /*value*/) {
        comboInputLevel->setCurrentIndex(0);
    });

    connect(checkReverseMotorX, &QCheckBox::stateChanged, this, &FormSettings::onStateChangedMotor);
    connect(checkReverseMotorY, &QCheckBox::stateChanged, this, &FormSettings::onStateChangedMotor);
    connect(checkReverseMotorU, &QCheckBox::stateChanged, this, &FormSettings::onStateChangedMotor);
    connect(checkReverseMotorV, &QCheckBox::stateChanged, this, &FormSettings::onStateChangedMotor);
    connect(checkSwapMotorXY, &QCheckBox::stateChanged, this, &FormSettings::onStateChangedMotor);
    connect(checkSwapMotorUV, &QCheckBox::stateChanged, this, &FormSettings::onStateChangedMotor);

//    connect(numHighThld, QOverload<int>::of(&QSpinBox::valueChanged), this, [&](int value) {
//        if (value < numLowThld->value())
//            numLowThld->setValue(value);
//    });

//    connect(numLowThld, QOverload<int>::of(&QSpinBox::valueChanged), this, [&](int value) {
//        if (value > numHighThld->value())
//            numHighThld->setValue(value);
//    });
}

void FormSettings::onStateChangedMotor(int /*state*/) {
    ProgramParam::saveMotorDir(
        checkReverseMotorX->isChecked(), checkReverseMotorY->isChecked(), checkReverseMotorU->isChecked(), checkReverseMotorV->isChecked(),
        checkSwapMotorXY->isChecked(), checkSwapMotorUV->isChecked()
    );
}

FormSettings::~FormSettings() {}

void FormSettings::setFontPointSize(int pointSize) {
    QFont font;

    for (QPushButton* b: buttons) {
        font = b->font();
        font.setPointSize(pointSize);
        b->setFont(font);
    }

    font = labelX->font();
    font.setPointSize(pointSize + 2);

    labelTitle->setFont(font);
    labelCNC->setFont(font);
    labelLanguage->setFont(font);
    labelInputLevel->setFont(font);
    labelStep->setFont(font);
    labelAcc->setFont(font);
    labelDec->setFont(font);

    labelX->setFont(font);
    labelY->setFont(font);
    labelU->setFont(font);
    labelV->setFont(font);
    labelEncX->setFont(font);
    labelEncY->setFont(font);

    labelPrecision->setFont(font);
    labelMotor->setFont(font);
    labelEncoder->setFont(font);

    //
    font = comboLanguage->font();
    font.setPointSize(pointSize + 2);

    comboLanguage->setFont(font);
    comboInputLevel->setFont(font);

    //
    font = numStep->font();
    font.setPointSize(pointSize + 2);

    numInputLevel->setFont(font);
    numStep->setFont(font);
    fnumAcc->setFont(font);
    fnumDec->setFont(font);

    numScaleX->setFont(font);
    numScaleY->setFont(font);
    numScaleU->setFont(font);
    numScaleV->setFont(font);
    numEncScaleX->setFont(font);
    numEncScaleY->setFont(font);

    font = checkSwapXY->font();
    font.setPointSize(pointSize + 2);
    checkSwapXY->setFont(font);
    checkReverseX->setFont(font);
    checkReverseY->setFont(font);
    checkShowXY->setFont(font);
    checkReverseMotorX->setFont(font);
    checkReverseMotorY->setFont(font);
    checkReverseMotorU->setFont(font);
    checkReverseMotorV->setFont(font);
    checkSwapMotorXY->setFont(font);
    checkSwapMotorUV->setFont(font);

    groupFeedback->setFont(font);
    labelHighThld->setFont(font);
    labelLowThld->setFont(font);
    numHighThld->setFont(font);
    numLowThld->setFont(font);
}

void FormSettings::createButtons() {
    btnHome = new QPushButton();
    btnHome->setText(tr("Back"));

    btnRead = new QPushButton();
    btnRead->setText(tr("Read"));

    btnWrite = new QPushButton();
    btnWrite->setText(tr("Write"));

    btn3 = new QPushButton();
    btn3->setText(tr(""));
    btn3->setEnabled(false);

    btn4 = new QPushButton();
    btn4->setText(tr(""));
    btn4->setEnabled(false);

    btn5 = new QPushButton();
    btn5->setText(tr(""));
    btn5->setEnabled(false);

    btn6 = new QPushButton();
    btn6->setText(tr(""));
    btn6->setEnabled(false);

    btn7 = new QPushButton();
    btn7->setText(tr(""));
    btn7->setEnabled(false);

    btn8 = new QPushButton();
    btn8->setText(tr(""));
    btn8->setEnabled(false);

    btn9 = new QPushButton();
    btn9->setText(tr(""));
    btn9->setEnabled(false);

    btn10 = new QPushButton();
    btn10->setText(tr(""));
    btn10->setEnabled(false);

    btn11 = new QPushButton();
    btn11->setText(tr(""));
    btn11->setEnabled(false);

    btn12 = new QPushButton();
    btn12->setText(tr(""));
    btn12->setEnabled(false);

    btnHelp = new QPushButton();
    btnHelp->setText(tr("Help"));

    buttons = {btnHome, btnRead, btnWrite, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12, btnHelp};

    gridButtons = new QGridLayout();

    gridButtons->addWidget(btnHome, 0, 0);
    gridButtons->addWidget(btnRead, 0, 1);
    gridButtons->addWidget(btnWrite, 0, 2);
    gridButtons->addWidget(btn3, 0, 3);
    gridButtons->addWidget(btn4, 0, 4);
    gridButtons->addWidget(btn5, 0, 5);
    gridButtons->addWidget(btn6, 0, 6);
    gridButtons->addWidget(btn7, 0, 7);
    gridButtons->addWidget(btn8, 0, 8);
    gridButtons->addWidget(btn9, 0, 9);
    gridButtons->addWidget(btn10, 0, 10);
    gridButtons->addWidget(btn11, 0, 11);
    gridButtons->addWidget(btn12, 0, 12);
    gridButtons->addWidget(btnHelp, 0, 13);

    connect(btnHome, &QPushButton::clicked, this, [&]() {
        emit showInfo(QString());
        emit homePageClicked();
    });

    connect(btnRead, &QPushButton::clicked, this, [&]() {
        uint16_t input_lvl;
        bool revX, revY, revU, revV, swapXY, swapUV;
        bool fb_ena;
        uint32_t rbAttempts;
        double low_thld, high_thld, rbTimeout, rbLength, rbSpeed, acc, dec;

        bool OK = par.cnc.readSettings(input_lvl, revX, revY, revU, revV, swapXY, swapUV, acc, dec);

        if (OK) {
            ProgramParam::saveInputLevel(input_lvl);
            numInputLevel->setValue(input_lvl);
            comboInputLevel->setCurrentIndex(0);

            ProgramParam::saveMotorDir(revX, revY, revU, revV, swapXY, swapUV);
            checkReverseMotorX->setCheckState(revX ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);
            checkReverseMotorY->setCheckState(revY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);
            checkReverseMotorU->setCheckState(revU ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);
            checkReverseMotorV->setCheckState(revV ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);
            checkSwapMotorXY->setCheckState(swapXY ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);
            checkSwapMotorUV->setCheckState(swapUV ? Qt::CheckState::Checked : Qt::CheckState::Unchecked);

            fnumAcc->setValue(acc);
            fnumDec->setValue(dec);
        }
        else
            qDebug("Read Input Levels ERROR!\n");

        OK &= par.cnc.readFeedback(fb_ena, low_thld, high_thld, rbTimeout, rbAttempts, rbLength, rbSpeed);

        if (OK) {
            numLowThld->blockSignals(true);
            numHighThld->blockSignals(true);

            // todo: save param
            groupFeedback->setChecked(fb_ena);
            numLowThld->setValue(static_cast<int>(round(low_thld)));
            numHighThld->setValue(static_cast<int>(round(high_thld)));
            numRbTimeout->setValue(rbTimeout);
            numRbAttempts->setValue(rbAttempts);
            fnumRbLength->setValue(rbLength);
            fnumRbSpeed->setValue(rbSpeed);

            numLowThld->blockSignals(false);
            numHighThld->blockSignals(false);
            emit showInfo("Read OK");
        }
        else {
            groupFeedback->setChecked(false);
            emit showError("Read ERROR!");
        }
    });

    connect(btnWrite, &QPushButton::clicked, this, [&]() {
        uint16_t input_lvl = static_cast<uint16_t>(numInputLevel->value() & 0xFFFF);
        bool revX = checkReverseMotorX->isChecked();
        bool revY = checkReverseMotorY->isChecked();
        bool revU = checkReverseMotorU->isChecked();
        bool revV = checkReverseMotorV->isChecked();
        bool swapXY = checkSwapMotorXY->isChecked();
        bool swapUV = checkSwapMotorUV->isChecked();

        ProgramParam::saveInputLevel(input_lvl);
        ProgramParam::saveMotorDir(revX, revY, revU, revV, swapXY, swapUV);
        bool OK =   par.cnc.writeSettings(
                        input_lvl,
                        revX, revY, revU, revV,
                        swapXY, swapUV,
                        fnumAcc->value(), fnumDec->value()
                    );


        if (numHighThld->value() < numLowThld->value())
            numHighThld->setValue( numLowThld->value() );

        // todo: save param
        OK &=   par.cnc.writeFeedback(
                    groupFeedback->isChecked(),
                    numLowThld->value(),
                    numHighThld->value(),
                    numRbTimeout->value(),
                    numRbAttempts->value(),
                    fnumRbLength->value(),
                    fnumRbSpeed->value()
                );

#if defined(STONE)
        OK &= par.cnc.writeSemaphoreCncEnable(true);
#else
        OK &= par.cnc.writeCncEnable(true);
#endif

        if (OK)
            emit showInfo("Write OK");
        else
            emit showError("Write ERROR!");

        btnRead->click();
    });

    connect(btnHelp, &QPushButton::clicked, this, [&]() { emit helpPageClicked(help_file); });
}
