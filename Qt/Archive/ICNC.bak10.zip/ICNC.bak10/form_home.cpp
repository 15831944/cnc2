#include <QTimer>
#include <QDebug>
#include <QProcess>

#include "form_home.h"
#include "aux_func.h"
#include "cnc.h"
#include "debug.h"

FormHome::FormHome(ProgramParam& par, QWidget *parent) : QWidget(parent), par(par) {
    createButtons();

    QHBoxLayout *hboxApps = new QHBoxLayout;

    treeApps = new QTreeWidget;
    treeApps->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
    treeApps->setHeaderHidden(true);
    treeApps->setWordWrap(true);
    treeApps->setAutoFillBackground(true);
    treeApps->setColumnCount(1);

    itemWelcome = new QTreeWidgetItem(treeApps);
    itemWelcome->setText(0, tr("Welcome"));
    treeApps->addTopLevelItem(itemWelcome);

    itemSlicing = new QTreeWidgetItem(treeApps);
    itemSlicing->setText(0, tr("Slicing"));
    treeApps->addTopLevelItem(itemSlicing);

    itemWelcome->setSelected(true);

    txtInfo = new QTextEdit;
    txtInfo->setEnabled(false);
    txtInfo->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    widgetSlicing = new SlicingWidget(par, this);
    widgetSlicing->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    stackedWidget = new QStackedWidget;
    stackedWidget->addWidget(txtInfo);
    stackedWidget->addWidget(widgetSlicing);

    stackedWidget->setCurrentWidget(txtInfo);

    hboxApps->addWidget(treeApps);
    hboxApps->addWidget(stackedWidget);
    hboxApps->setStretch(0, 2);
    hboxApps->setStretch(1, 12);

    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addLayout(hboxApps);
    mainLayout->addLayout(gridButtons);

    this->setLayout(mainLayout);

    //    treeBook->itemAt(0,0)->setBackgroundColor(0, Qt::blue);
    connect(treeApps, &QTreeWidget::itemClicked, this, &FormHome::onItemClicked);
    connect(treeApps, &QTreeWidget::itemActivated, this, &FormHome::onItemClicked);

    connect(widgetSlicing, &SlicingWidget::clicked, this, [&]() { emit dxfPageClicked(); });
}

void FormHome::onItemClicked(QTreeWidgetItem *item, int) {
    if (item == itemWelcome) {
        stackedWidget->setCurrentWidget(txtInfo);
    }
    else if (item == itemSlicing) {
        stackedWidget->setCurrentWidget(widgetSlicing);
    }
}

FormHome::~FormHome() {}

void FormHome::createButtons() {
    btnHome = new QPushButton(tr("Home"));
    btnHome->setEnabled(false);

    btnContour = new QPushButton(tr("Contour"));
    btnGCode = new QPushButton(tr("G-code"));
    btnRun = new QPushButton(tr("Run"));
    btnSettings = new QPushButton(tr("Settings"));
    btnPult = new QPushButton(tr("Pult"));

#ifndef STONE
    btnCenter = new QPushButton(tr("Center"));
#else
    btnCenter = new QPushButton;
    btnCenter->setEnabled(false);
#endif

    btnRec = new QPushButton(tr("Recovery"));

    btn8 = new QPushButton;
    btn8->setEnabled(false);

    btn9 = new QPushButton;
    btn9->setEnabled(false);

#if defined(DEV)
    btnTest = new QPushButton(tr("Test"));
#else
    btnTest = new QPushButton;
    btnTest->setEnabled(false);
#endif

    btnMinimize = new QPushButton(tr("Minimize"));
    btnShutdown = new QPushButton(tr("Shutdown"));
    btnShutdown->setEnabled(false);
    btnHelp = new QPushButton(tr("Help"));

    buttons = {
        btnHome, btnContour, btnGCode, btnRun, btnSettings, btnPult, btnCenter, btnRec,
        btn8, btn9, btnTest, btnMinimize, btnShutdown, btnHelp
    };

    gridButtons = new QGridLayout;

    gridButtons->addWidget(btnHome, 0, 0);
    gridButtons->addWidget(btnContour, 0, 1);
    gridButtons->addWidget(btnGCode, 0, 2);
    gridButtons->addWidget(btnRun, 0, 3);
    gridButtons->addWidget(btnSettings, 0, 4);
    gridButtons->addWidget(btnPult, 0, 5);

#ifndef STONE
    gridButtons->addWidget(btnCenter, 0, 6);
    gridButtons->addWidget(btnRec, 0, 7);
#else
    gridButtons->addWidget(btnRec, 0, 6);
    gridButtons->addWidget(btnCenter, 0, 7);
#endif

    gridButtons->addWidget(btn8, 0, 8);
    gridButtons->addWidget(btn9, 0, 9);
    gridButtons->addWidget(btnTest, 0, 10);
    gridButtons->addWidget(btnMinimize, 0, 11);
    gridButtons->addWidget(btnShutdown, 0, 12);
    gridButtons->addWidget(btnHelp, 0, 13);

    connect(btnContour, &QPushButton::clicked, this, [&]() { emit dxfPageClicked(); });
    connect(btnGCode, &QPushButton::clicked, this, [&]() { emit editPageClicked(); });
    connect(btnRun, &QPushButton::clicked, this, [&]() { emit runPageClicked(false); });
    connect(btnSettings, &QPushButton::clicked, this, [&]() { emit settingsPageClicked(); });
    connect(btnPult, &QPushButton::clicked, this, [&]() { emit pultPageClicked(); });
    connect(btnCenter, &QPushButton::clicked, this, [&]() { emit centerPageClicked(); });
    connect(btnRec, &QPushButton::clicked, this, [&]() {
        par.loadBackup();

        if (!par.gcode.empty())
            emit runPageClicked(true);
    //    else
    //        ui->btnRec->setEnabled(false);
    });

    connect(btnTest, &QPushButton::clicked, this, [&]() { emit testPageClicked(); });
    connect(btnMinimize, &QPushButton::clicked, this, [&]() { emit programMinimize(); });
    connect(btnShutdown, &QPushButton::clicked, this, [&]() {
#ifdef LINUX
        QProcess::startDetached("shutdown -P now");
#else
        QProcess::startDetached("shutdown -s -f -t 00");
#endif
    });
    connect(btnHelp, &QPushButton::clicked, this, [&]() { emit helpPageClicked(help_file); });
}

void FormHome::connectCnc() {
    using namespace std;
    static int cnt = 0;

    showConnecting();
    qDebug() << "Connecting...";

    if (!par.cnc.isOpen()) {
        par.cnc.open();

        if (!par.cnc.isOpen()) {
            showComNotFound();
            if (cnt++ < CONNECTION_ATTEMPTS) {
                QTimer::singleShot(5000, this, &FormHome::connectCnc);
            }
            return;
        }
    }

    string mcu_ver, fpga_ver;
    par.cncConnected = false;

    try {
        par.cnc.reset();
        mcu_ver = par.cnc.readVersion();
        fpga_ver = par.cnc.fpga.readVersion();
        par.cncConnected = true;
//        par.cnc.writeInputLevel(CncParam::inputLevel); // - in reset
     } catch (string& s) {
        qDebug("%s\n", s.c_str());
    } catch (exception& e) {
        qDebug("Exception: %s\n", e.what());
    } catch (...) {
        qDebug("Unknown exception\n");
    }

    if (!par.cncConnected) {
        showNoConnection();
        if (cnt++ < CONNECTION_ATTEMPTS) {
            QTimer::singleShot(5000, this, &FormHome::connectCnc);
        }
    }
    else
        showVersion(mcu_ver, fpga_ver);
}

void FormHome::showConnecting() {
    QString s = R"(<p><b>)" + tr("Info") + ": " + R"(</b>)" + tr("Connecting") + "..." + R"(</p>)";
    QString info = info_header + R"(<p style="text-align:center;"><h3>)" + s + R"(</h3></p>)";
    txtInfo->setHtml(info);
}

void FormHome::showComNotFound() {
    QString s = R"(<p><font color=red>)" + tr("Error") + ": " + R"(</font><i>)" + tr("Serial port is not found") + R"(</i></p>)";
    QString info = info_header + R"(<p style="text-align:right;">)" + s + R"(</p>)";
    txtInfo->setHtml(info);
}

void FormHome::showNoConnection() {
    QString s = R"(<p><font color=red>)" + tr("Error") + ": " + R"(</font><i>)" + tr("No connection. Check conection between computer and CNC board") + R"(</i></p>)";
    QString info = info_header + R"(<p style="text-align:right;">)" + s + R"(</p>)";
    txtInfo->setHtml(info);
}

void FormHome::showVersion(const std::string &mcu, const std::string &fpga) {
    QString info = info_header +
            R"(<font color=black><p style="text-align:center;"><h3>)" + QString(mcu.c_str()) + R"(</h3></p></font>)" +
            R"(<font color=black><p style="text-align:center;"><h3>)" + QString(fpga.c_str()) + R"(</h3></p></font>)";
    txtInfo->setHtml(info);
}

void FormHome::setFontPointSize(int pointSize) {
    for (QPushButton* b: buttons) {
        QFont font = b->font();
        font.setPointSize(pointSize);
        b->setFont(font);
//        b->setStyleSheet("font: bold");
    }

    QFont font = treeApps->font();
    font.setPointSize(pointSize);
    treeApps->setFont(font);

    itemWelcome->setFont(0, font);
    itemSlicing->setFont(0, font);

    widgetSlicing->setFontPointSize(pointSize);
}
