#include "cnc_types.h"

using namespace std;

string stateToString(cnc_state_t ctx) {
    switch (ctx) {
    case cnc_state_t::ST_IDLE:
        return "ST_IDLE";
    case cnc_state_t::ST_DIRECT:
        return "ST_DIRECT";
    case cnc_state_t::ST_CENTER:
        return "ST_CENTER";
    case cnc_state_t::ST_READ:
        return "ST_READ";
    case cnc_state_t::ST_SEGMENT:
        return "ST_SEGMENT";
    case cnc_state_t::ST_WAIT:
        return "ST_WAIT";
    case cnc_state_t::ST_PAUSE:
        return "ST_PAUSE";
    case cnc_state_t::ST_STOP:
        return "ST_STOP";
    case cnc_state_t::ST_WAIT_BUTTON:
        return "ST_WAIT_BUTTON";
    case cnc_state_t::ST_END:
        return "ST_END";
    case cnc_state_t::ST_ERROR:
        return "ST_ERROR";
    default:
        return "ST_UNKNOWN";
    }
}

uint8_t cut_t::getTimes() const {
    return times <= offsets.size() ? times : uint8_t(offsets.size());
}

vector<offset_t> cut_t::getOffsets() const {
    vector<offset_t> res(offsets);
    uint8_t times = getTimes();

    if (times <= res.size()) {
        res.resize(times);
        return res;
    }
    else
        return res;
}

vector<offset_t> cut_t::getTabOffsets() const {
    if (tab_multi_pass)
        return getOffsets();
    else {
        uint8_t times = getTimes();

        if (times & 1)
            return vector<offset_t>(1, tab_offset);
        else
            return vector<offset_t>(2, tab_offset);
    }
}

offset_t cut_t::getOverlapOffset() const {
    vector<offset_t> offsets = getOffsets();
    return !offsets.empty() ? getOffsets().back() : offset_t();
}

offset_t cut_t::getOutOffset() const {
    return getOverlapOffset();
}
