#include "cnc.h"
#include "aux_func.h"

using namespace std;
using namespace aux_func;

bool Cnc::testRegs() {
    qDebug("Test: RW test_reg\n");

    uint32_t test_reg = com->read32(ADDR::TEST_REG);
    qDebug("Read test_reg: 0x%08X\n", test_reg);

    byte_reverse(test_reg);
    uint32_t wrdata = test_reg;

    com->write32(ADDR::TEST_REG, wrdata);
    test_reg = com->read32(ADDR::TEST_REG);

    qDebug("Read test_reg: 0x%08X", test_reg);

    if (test_reg == wrdata) {
        qDebug(" - OK\n");
        qDebug("###################\n");
        return true;
    }
    else {
        qDebug(" - Error (expected 0x%08X)\n", wrdata);
        qDebug("###################\n");
        return false;
    }
}

bool Cnc::testProgArray() {
    qDebug("Test: RW Program Array...\n");
    uint32_t run = isRun();
    uint32_t imit = isImitEna();
    uint32_t rdaddr = com->read32(ADDR::PA_RDADDR);
    uint32_t wraddr = com->read32(ADDR::PA_WRADDR);
    uint32_t size = com->read32(ADDR::PA_SIZE);

    qDebug("PA size: %d, wraddr: %d, rdaddr = %d, run = %d, imit = %d\n", size, wraddr, rdaddr, run, imit);

    vector<uint8_t> wrdata = gen_rnd(size);

    com->write(ADDR::PA, wrdata);

    vector<uint8_t> rddata = com->read(ADDR::PA, size);

    bool OK = vector_compare(wrdata, rddata);

    if (OK) {
        qDebug("RW Program Array - OK\n");
        qDebug("###################\n");
        return true;
    }
    else
    {
        qDebug("RW Program Array - ERROR!\n");
        qDebug("###################\n");
        return false;
    }
}

bool Cnc::testFpga() {
    qDebug("FPGA test\n");
    cnc_version_t ver = fpga.version();
    std::string s = ver.toString();
    msg.write("FPGA version: " + s + "\n");
    qDebug("FPGA version: %s\n", ver.toString().c_str());

    return true;
}
