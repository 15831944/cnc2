#ifndef CNC_CONTEXT_BACKUP_H
#define CNC_CONTEXT_BACKUP_H

//#include <list>
//#include <map>
#include <cstdint>
#include <QString>

#include "cnc_types.h"

//class CncContextBackup {
//public:
//    cnc_context_t context;
//    bool valid;

//    CncContextBackup();
//    ~CncContextBackup();

//    void save();
//    void load();
//};

#endif // CNC_CONTEXT_BACKUP_H
