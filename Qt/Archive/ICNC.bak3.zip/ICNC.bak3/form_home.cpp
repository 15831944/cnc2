#include "form_home.h"
#include "ui_formhome.h"
#include "aux_func.h"
#include "cnc.h"
#include <QTimer>
#include <QDebug>
#include <QProcess>
#include "debug.h"

FormHome::FormHome(ProgramParam& par, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormHome),
    par(par)
{
    ui->setupUi(this);

#ifdef STONE
    ui->btnPult->setEnabled(false);
    ui->btnPult->setText(QString());
#endif

    buttons = {
        ui->btnHome, ui->btnContour, ui->btnGCode, ui->btnRun, ui->btnSettings, ui->btnPult, ui->btnRec,
        ui->btn8, ui->btn9, ui->btn10, ui->btnTest, ui->btnMinimize, ui->btnShutdown, ui->btnHelp
    };

#ifndef DEV
    ui->btnTest->setEnabled(false);
    ui->btnTest->setText(QString());
#endif

    QTreeWidgetItem* item = new QTreeWidgetItem(ui->treeBook);
    item->setText(0, tr("Welcome"));
    ui->treeBook->addTopLevelItem(item);
    item->setSelected(true);

//    ui->treeMarks->itemAt(0,0)->setBackgroundColor(0, Qt::blue);

//    setFontPointSize(14);
}

FormHome::~FormHome()
{
    delete ui;
}

void FormHome::on_btnGCode_clicked()
{
    emit editPageClicked();
}

void FormHome::on_btnRun_clicked()
{
    emit runPageClicked(false);
}

void FormHome::on_btnTest_clicked()
{
    emit testPageClicked();
}

void FormHome::on_btnContour_clicked() {
    emit dxfPageClicked();
}

void FormHome::on_btnSettings_clicked() {
    emit settingsPageClicked();
}

void FormHome::on_btnPult_clicked() {
    emit pultPageClicked();
}

void FormHome::connectCnc() {
    using namespace std;
    static int cnt = 0;

    showConnecting();
    qDebug() << "Connecting...";

    if (!par.cnc.isOpen()) {
        par.cnc.open();

        if (!par.cnc.isOpen()) {
            showComNotFound();
            if (cnt++ < CONNECTION_ATTEMPTS) {
                QTimer::singleShot(5000, this, &FormHome::connectCnc);
            }
            return;
        }
    }

    string mcu_ver, fpga_ver;
    par.cncConnected = false;

    try {
        par.cnc.reset();
        mcu_ver = par.cnc.readVersion();
        fpga_ver = par.cnc.fpga.readVersion();
        par.cncConnected = true;
//        par.cnc.writeInputLevel(CncParam::inputLevel); // - in reset
     } catch (string& s) {
        qDebug("%s\n", s.c_str());
    } catch (exception& e) {
        qDebug("Exception: %s\n", e.what());
    } catch (...) {
        qDebug("Unknown exception\n");
    }

    if (!par.cncConnected) {
        showNoConnection();
        if (cnt++ < CONNECTION_ATTEMPTS) {
            QTimer::singleShot(5000, this, &FormHome::connectCnc);
        }
    }
    else
        showVersion(mcu_ver, fpga_ver);
}

void FormHome::showConnecting() {
    QString s = R"(<p><b>)" + tr("Info") + ": " + R"(</b>)" + tr("Connecting") + "..." + R"(</p>)";
    QString info = info_header + R"(<p style="text-align:center;"><h3>)" + s + R"(</h3></p>)";
    ui->txtInfo->setHtml(info);
}

void FormHome::showComNotFound() {
    QString s = R"(<p><font color=red>)" + tr("Error") + ": " + R"(</font><i>)" + tr("UART port is not found") + R"(</i></p>)";
    QString info = info_header + R"(<p style="text-align:right;">)" + s + R"(</p>)";
    ui->txtInfo->setHtml(info);
}

void FormHome::showNoConnection() {
    QString s = R"(<p><font color=red>)" + tr("Error") + ": " + R"(</font><i>)" + tr("No connection. Check conection between computer and CNC board") + R"(</i></p>)";
    QString info = info_header + R"(<p style="text-align:right;">)" + s + R"(</p>)";
    ui->txtInfo->setHtml(info);
}

void FormHome::showVersion(const std::string &mcu, const std::string &fpga) {
    QString info = info_header +
            R"(<font color=black><p style="text-align:center;"><h3>)" + QString(mcu.c_str()) + R"(</h3></p></font>)" +
            R"(<font color=black><p style="text-align:center;"><h3>)" + QString(fpga.c_str()) + R"(</h3></p></font>)";
    ui->txtInfo->setHtml(info);
}

void FormHome::setFontPointSize(int pointSize) {
    for (QPushButton* b: buttons) {
        QFont font = b->font();
        font.setPointSize(pointSize);
        b->setFont(font);
//        b->setStyleSheet("font: bold");
    }

    QFont font = ui->treeBook->font();
    font.setPointSize(pointSize);
    ui->treeBook->setFont(font);
}

void FormHome::on_btnShutdown_clicked() {
#ifdef LINUX
    QProcess::startDetached("shutdown -P now");
#else
    QProcess::startDetached("shutdown -s -f -t 00");
#endif
}

void FormHome::on_btnRec_clicked() {
    par.loadBackup();

    if (!par.gcode.empty())
        emit runPageClicked(true);
//    else
//        ui->btnRec->setEnabled(false);
}

void FormHome::on_btnHelp_clicked() {
    emit helpPageClicked(help_file);
}

void FormHome::on_btnMinimize_clicked() {
    emit programMinimize();
}
