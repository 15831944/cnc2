#ifndef RESIZEDIALOG_H
#define RESIZEDIALOG_H

#include <QDialog>
#include <QLabel>
#include <QDoubleSpinBox>
#include <QRadioButton>
#include <QGroupBox>
#include <QGridLayout>
#include <QDialogButtonBox>

class ResizeDialog : public QDialog {
    Q_OBJECT

    QLabel *labelWidth, *labelHeight, *labelBase, *labelNew;
    QDoubleSpinBox *inPct, *inWidth, *inHeight, *inBase, *inNew;

    QRadioButton *radioPct, *radioRect, *radioRatio;
    QGroupBox *group;

public:
    QDialogButtonBox* buttonBox;

    explicit ResizeDialog(double width = 0, double height = 0, QWidget *parent = nullptr);

    bool isPct() const;
    bool isRect() const;
    bool isRatio() const;

    double pct() const;
    double rectWidth() const;
    double rectHeight() const;
    double ratioSize() const;
    double ratioNew() const;

    ~ResizeDialog();
};

#endif // RESIZEDIALOG_H
