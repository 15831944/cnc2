#include <cmath>
#include "frect_t.h"

frect_t::frect_t() : m_min(0,0), m_max(0,0) {}
frect_t::frect_t(const fpoint_t& _min, const fpoint_t& _max) : m_min(_min), m_max(_max) {
    if (m_max.x < m_min.x) {
        double x = m_min.x;
        m_min.x = m_max.x;
        m_max.x = x;
    }
    if (m_max.y < m_min.y) {
        double y = m_min.y;
        m_min.y = m_max.y;
        m_max.y = y;
    }
}

const fpoint_t &frect_t::min() const { return m_min; }

const fpoint_t &frect_t::max() const { return m_max; }

double frect_t::width() const { return fabs(m_max.x - m_min.x); }
double frect_t::height() const { return fabs(m_max.y - m_min.y); }

fpoint_t frect_t::center() const {
    fpoint_t c;
    c.x = m_min.x + width() / 2;
    c.y = m_min.y + width() / 2;
    return c;
}

