cd /home/cnc/Work/cnc2/Qt/Main/build-ICNC-Desktop-Release
./ICNC
