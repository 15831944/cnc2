#ifndef CNCCONTEXT_H
#define CNCCONTEXT_H

#include <cstdint>
#include <cfloat>

#include <QVariant>
#include "cnc_types.h"
#include "aux_func.h"

#define CNC_CONTEX_SIZE32 (11)
#define CNC_BACKUP_SIZE32 (CNC_CONTEX_SIZE32 + 1)

typedef union {
    uint32_t data[CNC_BACKUP_SIZE32];
    uint8_t bytes[CNC_BACKUP_SIZE32 * sizeof(uint32_t)];

    struct {
        // 0
        uint32_t pump_ena:1;
        uint32_t drum_state:2;
        uint32_t wire_ena:1;
        uint32_t voltage_ena:1;
        uint32_t hold_ena:1;
        uint32_t :2;

        uint32_t drum_vel:8;

        uint32_t uv_ena:1;
        uint32_t rev:1;
        uint32_t enc_ena:1;
        uint32_t :5;

        uint32_t state:8;
        // 1
        uint32_t pulse_width:8;
        uint32_t pulse_ratio:8;
        uint32_t voltage_level:8;
        uint32_t current_index:8;
        // 2, 3, 4, 5, 6
        int32_t id, x, y, u, v;
        // 7, 8
        int32_t enc_x, enc_y;
        // 9
        float T; // clocks/mm
        // 10
        float step; // mm
        // 11
        uint32_t backup_valid:1; // only for backup
        uint32_t read_valid:1;
        uint32_t :30;
    } field;
} cnc_context_t;

Q_DECLARE_METATYPE(cnc_context_t) // for QVariant

void toDebug(const cnc_context_t* const ctx);

class CncContext {
    cnc_context_t m_context;

public:
    static constexpr size_t SIZE32 = CNC_CONTEX_SIZE32;
    static constexpr size_t BACKUP_SIZE32 = CNC_BACKUP_SIZE32;
    static constexpr size_t SIZE = CNC_CONTEX_SIZE32 * sizeof(uint32_t);
    static constexpr size_t BACKUP_SIZE = CNC_BACKUP_SIZE32 * sizeof(uint32_t);
    static constexpr float STEP_MIN  = 0.001f; // mm
    static constexpr float STEP_MAX  = 1.0f; // mm

    static cnc_context_t defaultContext() {
        cnc_context_t ctx;

        ctx.field.pump_ena = false;
        ctx.field.drum_state = static_cast<uint8_t>(drum_state_t::DRUM_DIS);
        ctx.field.wire_ena = false;
        ctx.field.voltage_ena = false;
        ctx.field.hold_ena = false;

        ctx.field.drum_vel = 0;

        ctx.field.uv_ena = false;
        ctx.field.rev = false;

        ctx.field.state = static_cast<uint8_t>(cnc_state_t::ST_IDLE);

        ctx.field.pulse_width = 0;
        ctx.field.pulse_ratio = 0;
        ctx.field.voltage_level = 0;
        ctx.field.current_index = 0;

        ctx.field.id = -1;
        ctx.field.x = 0;
        ctx.field.y = 0;
        ctx.field.u = 0;
        ctx.field.v = 0;
        ctx.field.enc_x = 0;
        ctx.field.enc_y = 0;
        ctx.field.T = FLT_MAX;
        ctx.field.step = STEP_MIN;

        ctx.field.backup_valid = false;

        return ctx;
    }

    CncContext() { m_context = defaultContext(); }
    void setDefault() { m_context = defaultContext(); }

    static cnc_state_t toCncState(uint8_t value) {
        if (value > static_cast<uint8_t>(cnc_state_t::ST_ERROR))
            return cnc_state_t::ST_ERROR;

        return static_cast<cnc_state_t>(value);
    }

    static drum_state_t toDrumState(uint8_t value) {
        if (value > static_cast<uint8_t>(drum_state_t::DRUM_ERROR))
            return drum_state_t::DRUM_ERROR;

        return static_cast<drum_state_t>(value);
    }

    static cnc_context_t parse(const std::vector<uint8_t>& v) {
        using namespace aux_func;
        cnc_context_t ctx;

        if (v.size() >= SIZE) {
            ctx.field.pump_ena = (v[0] & 1) != 0;
            ctx.field.drum_state = static_cast<uint8_t>(toDrumState(v[0]>>1 & 3));
            ctx.field.wire_ena = (v[0] & 8) != 0;
            ctx.field.voltage_ena = (v[0] & 0x10) != 0;
            ctx.field.hold_ena = (v[0] & 0x20) != 0;

            ctx.field.drum_vel = v[1];

            ctx.field.uv_ena = (v[2] & 1) != 0;
            ctx.field.rev = (v[2] & 2) != 0;
            ctx.field.enc_ena = (v[2] & 4) != 0;

            ctx.field.state = static_cast<uint8_t>(toCncState(v[3]));

            ctx.field.pulse_width = v[4];
            ctx.field.pulse_ratio = v[5];
            ctx.field.voltage_level = v[6];
            ctx.field.current_index = v[7];

            ctx.field.id = BitConverter::toInt32(v, 2 * sizeof(uint32_t));
            ctx.field.x = BitConverter::toInt32(v, 3 * sizeof(uint32_t));
            ctx.field.y = BitConverter::toInt32(v, 4 * sizeof(uint32_t));
            ctx.field.u = BitConverter::toInt32(v, 5 * sizeof(uint32_t));
            ctx.field.v = BitConverter::toInt32(v, 6 * sizeof(uint32_t));
            ctx.field.enc_x = BitConverter::toInt32(v, 7 * sizeof(uint32_t));
            ctx.field.enc_y = BitConverter::toInt32(v, 8 * sizeof(uint32_t));
            ctx.field.T = BitConverter::toFloat(v, 9 * sizeof(uint32_t));
            ctx.field.step = BitConverter::toFloat(v, 10 * sizeof(uint32_t));

            if (v.size() >= BACKUP_SIZE)
                ctx.field.backup_valid = (v[BACKUP_SIZE - sizeof(uint32_t)] & 1) != 0;
            else
                ctx.field.backup_valid = false;
        }
        else
            ctx.field.backup_valid = false;

        return ctx;
    }

    static cnc_context_t parse(const QByteArray& ar) {
        cnc_context_t ctx;

        if (ar.size() == sizeof(cnc_context_t))
            memcpy(ctx.bytes, ar.data(), sizeof(cnc_context_t));
        else
            ctx = CncContext::defaultContext();

        return ctx;
    }

    // init from backup
    void set(const QByteArray& ar) {
        m_context = parse(ar);
    }

    QByteArray getByteArray() {
        QByteArray bytes(sizeof(cnc_context_t), 0);
        memcpy(bytes.data(), m_context.bytes, sizeof(cnc_context_t));
        return bytes;
    }

    void set(const cnc_context_t& ctx) { m_context = ctx; }
    CncContext(const cnc_context_t& ctx) { m_context = ctx; }
    CncContext(const std::vector<uint8_t>& v) { m_context = parse(v); }
    const cnc_context_t& get() const { return m_context; }

    bool pumpEnabled() const { return m_context.field.pump_ena; }
    drum_state_t drumState() const { return static_cast<drum_state_t>(m_context.field.drum_state); }
    bool wireControlEnabled() const { return m_context.field.wire_ena; }
    bool voltageEnabled() const { return m_context.field.voltage_ena; }
    bool hold() const { return m_context.field.hold_ena; }

    uint8_t drumVelocity() const { return m_context.field.drum_vel; }

    bool uvEnabled() const { return m_context.field.uv_ena; }
    bool reverse() const { return m_context.field.rev; }

    cnc_state_t cncState() const {
        return m_context.field.state > static_cast<uint8_t>(cnc_state_t::ST_ERROR) ? cnc_state_t::ST_ERROR : static_cast<cnc_state_t>(m_context.field.state);
    }

    uint8_t pulseWidth() const { return m_context.field.pulse_width; }
    uint8_t pulseRatio() const { return m_context.field.pulse_ratio; }
    uint8_t voltageLevel() const { return m_context.field.voltage_level; }
    uint8_t currentIndex() const { return m_context.field.current_index; }

    int32_t frameNum() const { return m_context.field.id; }
    int32_t x() const { return m_context.field.x; }
    int32_t y() const { return m_context.field.y; }
    int32_t u() const { return m_context.field.u; }
    int32_t v() const { return m_context.field.v; }
    int32_t encoderX() const { return m_context.field.enc_x; }
    int32_t encoderY() const { return m_context.field.enc_y; }

    // clocks/mm
    double speed() const { return WireSpeed::TtoSpeed(m_context.field.T); }
    double step() const { return static_cast<double>(m_context.field.step); } // mm

    bool valid() const { return m_context.field.backup_valid; }
    void setValid(bool value) { m_context.field.backup_valid = value; }

    inline bool isWork() const {
        return m_context.field.state > static_cast<uint8_t>(cnc_state_t::ST_IDLE) && m_context.field.state < static_cast<uint8_t>(cnc_state_t::ST_ERROR);
    }
    inline bool isError() const {
        return m_context.field.state >= static_cast<uint8_t>(cnc_state_t::ST_ERROR);
    }
    inline bool isIdle() const {
        return m_context.field.state == static_cast<uint8_t>(cnc_state_t::ST_IDLE);
    }

    inline bool isDrumEnable() const {
        return m_context.field.drum_state == static_cast<uint8_t>(drum_state_t::DRUM_FWD) || m_context.field.drum_state == static_cast<uint8_t>(drum_state_t::DRUM_REV);
    }

    inline void setDrumEnable(bool value) {
        m_context.field.drum_state = value ? static_cast<uint8_t>(drum_state_t::DRUM_ANY) : static_cast<uint8_t>(drum_state_t::DRUM_DIS);
    }

    inline std::string toString() const {
        return  "State: " + std::to_string(static_cast<uint8_t>(m_context.field.state)) + "\n" +
                "Frame Number: " + std::to_string(m_context.field.id) + "\n" +
                "Position: (" +  std::to_string(m_context.field.x) + ", " + std::to_string(m_context.field.y) + ", " +
                            std::to_string(m_context.field.u) + ", " + std::to_string(m_context.field.v) + ") " + "\n" +
                "Encoder: (" +  std::to_string(m_context.field.enc_x) + ", " + std::to_string(m_context.field.enc_y) + ")" + "\n" +
                "Pump Enable: " + std::to_string(m_context.field.pump_ena) + "\n" +
                "Drum State: " + std::to_string(m_context.field.drum_state) + "\n" +
                "Wire Control: " + std::to_string(m_context.field.wire_ena) + "\n" +
                "Voltage Enable: " + std::to_string(m_context.field.voltage_ena) + "\n" +
                "Motor Hold Enable: " + std::to_string(m_context.field.hold_ena) + "\n" +
                "Drum Velocity: " + std::to_string(m_context.field.drum_vel) + "\n" +
                "Pulse Width: " + std::to_string(m_context.field.pulse_width) + " Ratio: " + std::to_string(m_context.field.pulse_ratio) + "\n" +
                "Voltage Level: " + std::to_string(m_context.field.voltage_level) + "\n" +
                "Current Index: " + std::to_string(m_context.field.current_index) + "\n" +
                "Period : " + std::to_string(m_context.field.T) + "clock/mm\n" +
                "UV Enable: " + std::to_string(m_context.field.uv_ena) + "\n" +
                "Valid: " + std::to_string(m_context.field.backup_valid) + "\n";
    }
};


#endif // CNCCONTEXT_H
