#include "cnc_com.h"

#include <iostream>
#include <memory>
#include <iostream>
#include <string>
#include <cstdio>

#include "aux_func.h"

#include <QDebug>
#include <QThread>
#include <QTime>
#include <QCoreApplication>
//#include <regex>
#include "main.h"

using namespace std;
using namespace aux_func;

CncCom::CncCom(ReportWriter txt) : txt(txt) {}

CncCom::~CncCom() {
    delete port;
}

// todo on timer
//void CncCom::delay(int ms) {
//    QTime dieTime= QTime::currentTime().addMSecs(ms);
//    while (QTime::currentTime() < dieTime)portName
//        QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
//}

bool CncCom::open() {
    QString portName;
//    close();
//    pFile = fopen(portName.c_str(), "r+");

//    QString s;
//    if (pFile)
//        s = QString::asprintf("Port %s is opened", portName.c_str());
//    else
//        s = QString::asprintf("Port %s is not opened", portName.c_str());

//    txt.write(s);

//    return pFile != nullptr;

    QList<QSerialPortInfo> list = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo& info: list) {
        if (!info.isNull()) {
            qDebug("name: %s product_id: %x vendor_id: %x", info.portName().toStdString().c_str(), info.productIdentifier(), info.vendorIdentifier());

            if (info.productIdentifier() == ST_PRODUCT_ID && info.vendorIdentifier() == ST_VENDOR_ID) {
                portName = info.portName();
//                break;
            }
        }
    }

    if (port != nullptr && port->isOpen()) {
        port->close();
        delete port;
    }
    port = nullptr;

    if (portName.size() != 0) {
        port = new QSerialPort();
    //    port->setPortName(QString::fromStdString(portName));
        port->setPortName(portName);
        port->setBaudRate(QSerialPort::Baud115200);
        port->setDataBits(QSerialPort::Data8);
        port->setParity(QSerialPort::NoParity);
        port->setStopBits(QSerialPort::OneStop);
        port->setFlowControl(QSerialPort::NoFlowControl);
        port->setReadBufferSize(16 * 1024);

        QString s;
        if (!port->open(QIODevice::ReadWrite)) {
            delete port;
            port = nullptr;
            s = QString::asprintf("Port %s is not opened", portName.toStdString().c_str());
        }
        else
            s = QString::asprintf("Port %s is opened", portName.toStdString().c_str());

        txt.write(s);
        return port != nullptr;
    }
    else {
        txt.write("STM USB CDC device was not found");
        return false;
    }
}

bool CncCom::close() {
//    if (pFile) {
//        fclose(pFile);
//        pFile = nullptr;
//        return true;
//    }
//    return false;

    if (port && port->isOpen()) {
        port->close();
        delete port;
        port = nullptr;
        QString s = "COM port is closed";
        txt.write(s);
        return true;
    }

    port = nullptr;
    return false;
}

void CncCom::push_back_u32_rev(vector<uint8_t>& v, uint32_t data) {
    const uint8_t* const ptr = reinterpret_cast<uint8_t*>(&data);
    v.push_back(ptr[3]);
    v.push_back(ptr[2]);
    v.push_back(ptr[1]);
    v.push_back(ptr[0]);
}

//#define RX_PRINT
int CncCom::readPort(vector<uint8_t>& rx_buf, int timeout) {
//    vector<uint8_t> v_res;
//    int timer = 0;

//    timeout_ms /= 10;

//    for (; timer < timeout_ms; timer++) {
//        int c;

//        while ((c = fgetc(pFile)) != EOF)
//           v_res.push_back(static_cast<uint8_t>(c & 0xFF));

//        if (ferror(pFile))
//            qDebug("I/O error when reading");
////        else if (feof(fp))
////            puts("End of file reached successfully");

//        if (!v_res.empty())
//            break;

//        QThread::msleep(10);
//    }

//    if (!v_res.empty()) {
//        push_back_range(rx_buf, v_res, 0, v_res.size());
//        return int(v_res.size());
//    }
//    else
//        return -1;

    vector<uint8_t> v_res;

    if (port != nullptr && port->waitForReadyRead(timeout)) {
        QByteArray res = port->readAll();
        v_res = vector<uint8_t>(res.begin(), res.end());

#ifdef RX_PRINT
        static int n;
        if (rx_buf.empty()) n = 0;

        if (!v_res.empty()) {
            for (size_t i = 0; i < v_res.size(); i++) {
                if (n != 15)
                    qDebug("%02X ", int(v_res[i]));
                else
                    qDebug("%02X\n", int(v_res[i]));
            }
        }
        else {
            if (n != 15)
                qDebug("(00) ");
            else
                qDebug("(00)\n");
        }
        n++;
#endif

        push_back_range(rx_buf, v_res, 0, v_res.size());
        return int(v_res.size());
    }
    else
        return -1;
}

void CncCom::writeBytes(uint32_t addr, const vector<uint8_t>& bytes, size_t begin, uint8_t length) {
    if (addr >> 28 != 0)
        throw string_format("Address error: 0x%08x", int(addr));

    if (port == nullptr || !port->isOpen())
//    if (pFile == nullptr)
        throw string("Com port isn't open");

    tx_buf.clear();

    uint32_t data = Commands::CMD_WRITE << 28 | addr;
    push_back_u32_rev(tx_buf, data);

    tx_buf.push_back(length);
    push_back_range(tx_buf, bytes, static_cast<size_t>(begin), static_cast<size_t>(length));

    uint32_t crc32_calc = crc32(tx_buf.data(), tx_buf.size());

    push_back_u32_rev(tx_buf, crc32_calc);

//    fwrite(tx_buf.data(), sizeof(uint8_t), tx_buf.size(), pFile);
//    fflush(pFile);
    port->write(reinterpret_cast<char*>(tx_buf.data()), qint64(tx_buf.size()));
    port->flush();

    qDebug("Write to address 0x%08x:\n", addr);
    aux_func::print_vector(tx_buf);

    int timeout = 1000;

    rx_buf.clear();

    while (true) {
        int res = readPort(rx_buf, timeout);

        if (res <= 0)
            throw string("Rx timeout. Received ") + to_string(rx_buf.size()) + " bytes";

        if (rx_buf.size() >= 9) {
            uint8_t ack_cmd = rx_buf[0] >> 4;

            if (ack_cmd == Commands::CMD_ERROR)
                throw string_format("CNC write error code: %d", int(rx_buf[4]));
            else {
                uint32_t ack_addr = BitConverter::toUInt32Rev(rx_buf, 0) & 0x0FFFFFFF;
                uint8_t ack_len = rx_buf[4];
                uint32_t ack_crc32 = BitConverter::toUInt32Rev(rx_buf, 5);
                uint32_t ack_crc32_calc = crc32(rx_buf.data(), rx_buf.size() - sizeof(uint32_t));

                if (ack_cmd != Commands::CMD_WRITE)
                    throw string_format("Write ack command error: 0x%x", int(ack_cmd));

                if (ack_addr != addr)
                    throw string_format("Write ack address error: 0x%x", ack_addr);

                if (ack_len != length)
                    throw string_format("Write ack length error: %d", ack_len);

                if (ack_crc32 != ack_crc32_calc)
                    throw string_format("Write ack CRC error: 0x%x (expected 0x%x)", ack_crc32, ack_crc32_calc);

                break;
            }
        }
    }
}

void CncCom::writeBytes(uint32_t addr, const uint8_t* data, size_t size, size_t begin, uint8_t length) {
    if (begin < size)
        data += begin;
    else
        return;

    if (begin + length > size)
        length = static_cast<uint8_t>(size - begin);

    vector<uint8_t> bytes(length);

    for (size_t i = 0; i < bytes.size(); i++)
        bytes[i] = *data++;

    writeBytes(addr, bytes, 0, length);
}

void CncCom::write(uint32_t addr, const vector<uint8_t>& bytes) {
    const uint8_t max = 255;
    size_t pos = 0;
    size_t rem = bytes.size();

    while (rem > 0) {
        uint8_t len = rem > max ? max : static_cast<uint8_t>(rem);

        this->writeBytes(addr, bytes, pos, len);

        addr += len;
        pos += len;
        rem -= len;
    }
}

void CncCom::write(uint32_t addr, const void* data, size_t size) {
    const uint8_t max = 255;
    size_t pos = 0;

    while (size > 0) {
        uint8_t len = size > max ? max : static_cast<uint8_t>(size);

        this->writeBytes(addr, reinterpret_cast<const uint8_t*>(data), size, pos, len);

        addr += len;
        pos += len;
        size -= len;
    }
}

// no reverse!
void CncCom::write16(uint32_t addr, uint16_t data) {
    vector<uint8_t> v = vector<uint8_t>(sizeof(data));
    memcpy(&v[0], reinterpret_cast<uint8_t*>(&data), v.size());
    this->write(addr, v);
}

void CncCom::write32(uint32_t addr, uint32_t data) {
    vector<uint8_t> v = vector<uint8_t>(sizeof(data));
    memcpy(&v[0], reinterpret_cast<uint8_t*>(&data), v.size());
    this->write(addr, v);
}

void CncCom::write64(uint32_t addr, uint64_t data) {
    vector<uint8_t> v = vector<uint8_t>(sizeof(data));
    memcpy(&v[0], reinterpret_cast<uint8_t*>(&data), v.size());
    this->write(addr, v);
}

void CncCom::write48(uint32_t addr, uint64_t data) {
    vector<uint8_t> v = vector<uint8_t>(sizeof(uint16_t) * 3);
    memcpy(&v[0], reinterpret_cast<uint8_t*>(&data), v.size());
    this->write(addr, v);
}

vector<uint8_t> CncCom::readBytes(uint32_t addr, uint8_t len) {
    vector<uint8_t> rddata;

    if (addr >> 28 != 0)
        throw aux_func::string_format("Address error: 0x%x", int(addr));

//    if (pFile == nullptr)
    if (!port || !port->isOpen())
        throw string("Com port isn't open");

    tx_buf.clear();

    uint32_t data = Commands::CMD_READ << 28 | addr;

    push_back_u32_rev(tx_buf, data);

    tx_buf.push_back(len);

    uint32_t crc32_calc = crc32(tx_buf.data(), tx_buf.size());
    push_back_u32_rev(tx_buf, crc32_calc);

//    fwrite(tx_buf.data(), sizeof(uint8_t),tx_buf.size(), pFile);
//    fflush(pFile);
    port->write(reinterpret_cast<char*>(tx_buf.data()), qint64(tx_buf.size()));
    port->flush();

#ifdef PRINT_CNC_COM_DEBUG
    qDebug("Read address 0x%08x:\n", addr);
    print_vector(tx_buf);
#endif

    int timeout = 10000;

    rx_buf.clear();

    vector<uint8_t> v_res;
    uint8_t ack_len = 0;

    while (true) {
        int res = readPort(rx_buf, timeout);

        if (res <= 0)
            throw string("Rx timeout. Received ") + to_string(rx_buf.size()) + " bytes";

        if (rx_buf.size() >= 5)
            ack_len = rx_buf[4];

        if (rx_buf.size() >= 9 && rx_buf[0] >> 4 == Commands::CMD_ERROR)
            // todo: try again - it's corrected error
            throw aux_func::string_format("CNC write error code: %d", int(rx_buf[4]));
        else if (rx_buf.size() >= 5U + ack_len + 4U) {
            uint8_t ack_cmd = rx_buf[0] >> 4;
            uint32_t ack_addr = BitConverter::toUInt32Rev(rx_buf, 0) & 0x0FFFFFFF;

            uint32_t ack_crc32 = BitConverter::toUInt32Rev(rx_buf, rx_buf.size() - sizeof(uint32_t));
            uint32_t ack_crc32_calc = crc32(rx_buf.data(), rx_buf.size() - sizeof(uint32_t));

            if (ack_cmd != Commands::CMD_READ)
                throw string_format("Read ack command error: 0x%x", ack_cmd);

            if (ack_addr != addr)
                throw string_format("Read ack address error: 0x%x", ack_addr);

            if (ack_len != len)
                throw string_format("Read ack length error: %d (expected %d)", int(ack_len), int(len));

            if (ack_crc32 != ack_crc32_calc)
                throw string_format("Read ack CRC error: 0x%x (expected 0x%x)", ack_crc32, ack_crc32_calc);

            rddata.resize(len);
            memcpy(&rddata[0], &rx_buf[5], len);

            break;
        }
    }

    return rddata;
}

vector<uint8_t> CncCom::readFifo(uint32_t addr, uint8_t len) {
    vector<uint8_t> v;

    if (addr >> 28 != 0)
        throw string_format("Address error: 0x%x", addr);

//    if (pFile == nullptr)
    if (!port || !port->isOpen())
        throw string("Com port isn't open");

    tx_buf.clear();

    uint32_t data = Commands::CMD_READ_FIFO << 28 | addr;

    push_back_u32_rev(tx_buf, data);

    tx_buf.push_back(len);

    uint32_t crc32_calc = crc32(tx_buf.data(), tx_buf.size());
    push_back_u32_rev(tx_buf, crc32_calc);

//    fwrite(tx_buf.data(), sizeof(uint8_t), tx_buf.size(), pFile);
//    fflush(pFile);
    port->write(reinterpret_cast<char*>(tx_buf.data()), qint64(tx_buf.size()));
    port->flush();

#ifdef PRINT_CNC_COM_DEBUG
    qDebug("Read address 0x%x:", addr);
    print_vector(tx_buf);
#endif

    int timeout = 1000;
    rx_buf.clear();
    uint8_t ack_len = 0;

    while (true) {
        int res = readPort(rx_buf, timeout);

        if (res <= 0)
            throw string("Rx timeout. Received ") + to_string(rx_buf.size()) + " bytes";

        if (rx_buf.size() >= 5)
            ack_len = rx_buf[4];

        if (rx_buf.size() >= 9 && rx_buf[0] >> 4 == Commands::CMD_ERROR)
            throw aux_func::string_format("CNC write error code: %d", int(rx_buf[4]));
        else if (rx_buf.size() >= 5U + ack_len + 4U) {
            uint8_t ack_cmd = rx_buf[0] >> 4;
            uint32_t ack_addr = BitConverter::toUInt32Rev(rx_buf, 0) & 0x0FFFFFFF;

            uint32_t ack_crc32 = BitConverter::toUInt32Rev(rx_buf, 5 + ack_len);
            uint32_t ack_crc32_calc = crc32(rx_buf.data(), rx_buf.size() - sizeof(uint32_t));

            if (ack_cmd != Commands::CMD_READ_FIFO)
                throw string_format("Read ack command error: 0x%x", int(ack_cmd));

            if (ack_addr != addr)
                throw string_format("Read ack address error: 0x%x", int(ack_addr));

            if (ack_crc32 != ack_crc32_calc)
                throw string_format("Read ack CRC error: 0x%x (expected 0x%x)", ack_crc32, ack_crc32_calc);

            v.resize(ack_len);

            if (ack_len != 0)
                memcpy(&v[0], &rx_buf[5], ack_len);

            break;
        }
    }

    return v;
}

vector<uint8_t> CncCom::read(uint32_t addr, size_t len) {
    vector<uint8_t> v;
    const uint8_t max = 255;
    size_t rem = len;

    while (rem > 0) {
        uint8_t size = rem > max ? max : static_cast<uint8_t>(rem);

        vector<uint8_t> packet = readBytes(addr, size);
        push_back_range(v, packet, 0, packet.size());

        addr += size;
        rem -= size;
    }

    return v;
}

uint16_t CncCom::read16(uint32_t addr) {
    vector<uint8_t> v = read(addr, sizeof(uint16_t));
    return BitConverter::toUInt16(v, 0);
}

uint32_t CncCom::read32(uint32_t addr) {
    vector<uint8_t> v = read(addr, sizeof(uint32_t));
    return BitConverter::toUInt32(v, 0);
}

uint64_t CncCom::read64(uint32_t addr) {
    vector<uint8_t> v = read(addr, sizeof(uint64_t));
    return BitConverter::toUInt64(v, 0);
}

uint64_t CncCom::read48(uint32_t addr) {
    vector<uint8_t> v = read(addr, sizeof(uint16_t) * 3);
    return BitConverter::toUInt48(v, 0);
}
