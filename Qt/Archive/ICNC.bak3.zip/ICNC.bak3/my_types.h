#ifndef MY_TYPES_H
#define MY_TYPES_H

//#include "gframe.h"
//#include "gcode.h"
//#include "project_param.h"
//#include "aux_func.h"
//cnc.h \
//cnc_com.h \
//motor_record.h \
//form_test.h \
//form_run.h \
//form_edit.h \
//cnc_program.h \
//code_editor.h \
//form_home.h \
//plot_widget.h \
//run_widget.h \
//dxf_entities.h \
//dxf.h \
//form_contour.h \
//debug.h \
//contours.h \
//new_cutline_dialog.h \
//form_passes.h \
//spinbox_delegate.h \
//contour_table_model.h \
//mode_table_model.h \
//my_types.h

#endif // MY_TYPES_H
