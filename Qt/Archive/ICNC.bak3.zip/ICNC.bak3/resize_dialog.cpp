#include "resize_dialog.h"

ResizeDialog::ResizeDialog(double width, double height, QWidget *parent) : QDialog(parent) {
    labelWidth = new QLabel(tr("Width"));
    labelHeight = new QLabel(tr("Height"));
    labelBase = new QLabel(tr("Size"));
    labelNew = new QLabel(tr("New size"));

    inPct = new QDoubleSpinBox;
    inPct->setRange(0, 100);
    inPct->setValue(100);
    inPct->setSuffix(" %");
    inPct->setSingleStep(1);
    inPct->setDecimals(3);

    inWidth = new QDoubleSpinBox;
    inWidth->setRange(0, 1000);
    inWidth->setValue(width);
    inWidth->setSuffix(" " + tr("mm"));
    inWidth->setSingleStep(1);
    inWidth->setDecimals(3);

    inHeight = new QDoubleSpinBox;
    inHeight->setRange(0, 1000);
    inHeight->setValue(height);
    inHeight->setSuffix(" " + tr("mm"));
    inHeight->setSingleStep(1);
    inHeight->setDecimals(3);

    inBase = new QDoubleSpinBox;
    inBase->setRange(0, 1000);
    inBase->setValue(100);
    inBase->setSuffix(" " + tr("mm"));
    inBase->setSingleStep(1);
    inBase->setDecimals(3);

    inNew = new QDoubleSpinBox;
    inNew->setRange(0, 1000);
    inNew->setValue(100);
    inNew->setSuffix(" " + tr("mm"));
    inNew->setSingleStep(1);
    inNew->setDecimals(3);

    labelWidth->setBuddy(inWidth);
    labelHeight->setBuddy(inHeight);
    labelBase->setBuddy(inBase);
    labelNew->setBuddy(inNew);

    radioPct = new QRadioButton;
    radioRect = new QRadioButton;
    radioRatio = new QRadioButton;

    QGridLayout* grid = new QGridLayout;
    grid->addWidget(radioPct,0,0);
    grid->addWidget(inPct,0,2);

    grid->addWidget(radioRect,1,0);
    grid->addWidget(labelWidth,1,1);
    grid->addWidget(inWidth,1,2);
    grid->addWidget(labelHeight,1,3);
    grid->addWidget(inHeight,1,4);

    grid->addWidget(radioRatio,2,0);
    grid->addWidget(labelBase,2,1);
    grid->addWidget(inBase,2,2);
    grid->addWidget(labelNew,2,3);
    grid->addWidget(inNew,2,4);

    grid->setColumnStretch(0, 0);
    grid->setColumnStretch(1, 1);
    grid->setColumnStretch(2, 0);
    grid->setColumnStretch(3, 1);

    group = new QGroupBox;
    group->setLayout(grid);

    radioPct->setChecked(true);
    inPct->setEnabled(true);
    inWidth->setEnabled(false);
    inHeight->setEnabled(false);
    inBase->setEnabled(false);
    inNew->setEnabled(false);

    QHBoxLayout* hbox = new QHBoxLayout;
    buttonBox = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel);
    hbox->addWidget(buttonBox);

    QVBoxLayout* vbox = new QVBoxLayout;
    vbox->addWidget(group);
    vbox->addLayout(hbox);

    this->setLayout(vbox);

    inPct->setFocus();

    this->layout()->setSizeConstraint( QLayout::SetFixedSize );
    this->setWindowTitle(tr("Resize"));

    connect(radioPct, &QRadioButton::toggled, this, [&]() {
        inPct->setEnabled(true);
        inWidth->setEnabled(false);
        inHeight->setEnabled(false);
        inBase->setEnabled(false);
        inNew->setEnabled(false);
    });
    connect(radioRect, &QRadioButton::toggled, this, [&]() {
        inPct->setEnabled(false);
        inWidth->setEnabled(true);
        inHeight->setEnabled(true);
        inBase->setEnabled(false);
        inNew->setEnabled(false);
    });
    connect(radioRatio, &QRadioButton::toggled, this, [&]() {
        inPct->setEnabled(false);
        inWidth->setEnabled(false);
        inHeight->setEnabled(false);
        inBase->setEnabled(true);
        inNew->setEnabled(true);
    });

    connect(buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttonBox, &QDialogButtonBox::rejected, this, &QDialog::reject);
}

bool ResizeDialog::isPct() const { return radioPct->isChecked(); }
bool ResizeDialog::isRect() const { return radioRect->isChecked(); }
bool ResizeDialog::isRatio() const { return radioRatio->isChecked(); }

double ResizeDialog::pct() const { return inPct->value(); }
double ResizeDialog::rectWidth() const { return inWidth->value(); }
double ResizeDialog::rectHeight() const { return inHeight->value(); }
double ResizeDialog::ratioSize() const { return inBase->value(); }
double ResizeDialog::ratioNew() const { return inNew->value(); }

ResizeDialog::~ResizeDialog() {}
