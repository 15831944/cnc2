#include "dxf_intersect.h"
#include <cmath>

using namespace DxfIntersect;
using namespace std;

void DxfIntersect::intersect(const DxfLine& A, const DxfLine& B, fpoint_t& pt) {
    if (A.point_1() == B.point_0())
        pt = A.point_1();
    else if ((A.vertical() && B.vertical()) || (A.horizontal() && B.horizontal()) || A.same(B))
        pt = DxfLine::midpoint(A.point_1(), B.point_0());
    else if (A.vertical()) {
        pt.x = A.point_1().x;
        pt.y = B.y(pt.x);
    }
    else if (B.vertical()) {
        pt.x = B.point_0().x;
        pt.y = A.y(pt.x);
    }
    else {
        double Ak, Ab, Bk, Bb;

        A.func(Ak, Ab);
        B.func(Bk, Bb);

        if (Ak == Bk)
            pt = DxfLine::midpoint(A.point_1(), B.point_0());
        else {
            pt.x = (Bb - Ab) / (Ak - Bk);

            // main line nearest to 45 degrees
            Ak = fabs(Ak) - 0.5;
            Bk = fabs(Bk) - 0.5;

            if (fabs(Ak) < fabs(Bk))
                pt.y = A.y(pt.x);
            else
                pt.y = B.y(pt.x);
        }
    }
}

bool DxfIntersect::intersect(const DxfLine& A, const DxfArc& B, fpoint_t (&pt)[2], double (&angle)[2]) {
    double k = A.k();
    double b = A.b();
    double x0 = B.center().x;
    double y0 = B.center().y;
    double R = B.radius();

    double P = k * k + 1;
    double Q = 2 * k * b - 2 * x0 - 2 * k * y0;
    double C = b * b + y0 * y0 - 2 * b * y0 - R * R + x0 * x0;

    double D = Q * Q - 4 * P * C;

    if (D >= 0) {
        double sqrt_D = sqrt(D);
        double _2_P = 2 * P;
        pt[0].x = (-Q + sqrt_D) / _2_P;
        pt[1].x = (-Q - sqrt_D) / _2_P;

        pt[0].y = A.y(pt[0].x);
        pt[1].y = A.y(pt[1].x);

        angle[0] = atangent(B.center(), pt[0], R);
        angle[1] = atangent(B.center(), pt[1], R);

//        if (angle[0] > angle[1]) swap(angle[0], angle[1]);

        return true;
    }

    return false;
}

bool DxfIntersect::intersect(const DxfArc& A, const DxfArc& B, fpoint_t (&pt)[2], double (&angleA)[2], double (&angleB)[2]) {
    if (A.intersected(B)) {
        double R1 = A.radius();
        double R2 = B.radius();

        double _dx = B.center().x - A.center().x;
        double _dy = B.center().y - A.center().y;
        double d__2 = _dx * _dx + _dy * _dy;

        double d = sqrt(d__2);

        double R1__2 = R1*R1;

        double a = (R1__2 - R2*R2 + d__2) / (2 * d);

        double h = sqrt(R1__2 - a*a);

        pt[0].x = A.center().x + (a * _dx + h * _dy) / d;
        pt[1].x = A.center().x + (a * _dx - h * _dy) / d;

        pt[0].y = A.center().y + (a * _dy + h * _dx) / d;
        pt[1].y = A.center().y + (a * _dy - h * _dx) / d;

        angleA[0] = atangent(A.center(), pt[0], R1);
        angleA[1] = atangent(A.center(), pt[1], R1);
//        if (angleA[0] > angleA[1]) swap(angleA[0], angleA[1]);

        angleB[0] = atangent(B.center(), pt[0], R2);
        angleB[1] = atangent(B.center(), pt[1], R2);
//        if (angleB[0] > angleB[1]) swap(angleB[0], angleB[1]);
    }

    return false;
}

double DxfIntersect::atangent(double dx, double dy, double R) {
    if (R <= 0) return 0;

    double angle = asin(dy / R); // [-90, 90]

    if (dx >= 0)
        angle = dy >= 0 ? angle : angle + 2 * M_PI;
    else
        angle = dy >= 0 ? M_PI - angle : M_PI + angle;

    if (angle >= 2*M_PI || angle <= 0)
        angle = 0;

    return angle;
}

double DxfIntersect::atangent(const fpoint_t& C, const fpoint_t& A, double R) {
    return atangent(A.x - C.x, A.y - C.y, R);
}
