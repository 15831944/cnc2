<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>ContourTableModel</name>
    <message>
        <location filename="contour_table_model.cpp" line="44"/>
        <source>XY Plane</source>
        <translatorcomment>Плоскость XY</translatorcomment>
        <translation>XY</translation>
    </message>
    <message>
        <location filename="contour_table_model.cpp" line="46"/>
        <source>UV Plane</source>
        <translatorcomment>Плоскость UV</translatorcomment>
        <translation>UV</translation>
    </message>
</context>
<context>
    <name>FormContour</name>
    <message>
        <location filename="form_contour.cpp" line="59"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="61"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="64"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="67"/>
        <source>Save as</source>
        <translatorcomment>Сохранить как</translatorcomment>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="70"/>
        <source>Load XY</source>
        <oldsource>Load BOT</oldsource>
        <translatorcomment>Загрузить нижний контур</translatorcomment>
        <translation>Загр. XY</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="72"/>
        <source>Load UV</source>
        <oldsource>Load TOP</oldsource>
        <translatorcomment>Загрузить верхний контур</translatorcomment>
        <translation>Загр. UV</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="75"/>
        <source>Passes</source>
        <translation>Проходы</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="77"/>
        <source>Generate</source>
        <translatorcomment>Генерировать</translatorcomment>
        <translation>Генер.</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="94"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="138"/>
        <source>Contours</source>
        <translation>Контуры</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="139"/>
        <source>Current</source>
        <translation>Текущий</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="169"/>
        <source>New Contour</source>
        <translation>Новый контур</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="171"/>
        <source>New Cutline</source>
        <translation>Создать линию захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="183"/>
        <source>Top</source>
        <translation>В начало</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="184"/>
        <source>Change direction</source>
        <translation>Изменить направление</translation>
    </message>
    <message>
        <source>Flip contour</source>
        <translation type="vanished">Перевернуть контур</translation>
    </message>
    <message>
        <source>New Cut Line</source>
        <translation type="vanished">Новыя линия входа</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="172"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="173"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <source>First segment</source>
        <oldsource>First</oldsource>
        <translation type="vanished">Первый сегмент</translation>
    </message>
    <message>
        <source>Reverse</source>
        <translation type="vanished">Реверс</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="187"/>
        <source>Edit</source>
        <translation>Редактировать</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="191"/>
        <source>Use as Cutline</source>
        <translation>Использовать как линию захода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="192"/>
        <source>Set as exit point</source>
        <translation>Использовать как точку выхода</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="241"/>
        <source>Bottom layer loaded successfully</source>
        <translation>Низжний слой загружен успешно</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="244"/>
        <source>Bottom layer DXF segments sorting error</source>
        <translation>Ошибка сортировки сегментов нижнего слоя DXF файла</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="252"/>
        <source>Bottom layer DXF parsing error</source>
        <translation>Ошибка разбора DXF файла нижнего слоя</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="521"/>
        <source>Open DXF file</source>
        <translation>Открыть DXF файл</translation>
    </message>
    <message>
        <location filename="form_contour.cpp" line="521"/>
        <source>DXF Files (*.dxf)</source>
        <translation>Файлы DXF (*.dxf)</translation>
    </message>
</context>
<context>
    <name>FormEdit</name>
    <message>
        <location filename="form_edit.cpp" line="75"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="76"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="77"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="78"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="79"/>
        <source>Save as</source>
        <translatorcomment>Сохранить как</translatorcomment>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <source>Compile</source>
        <translation type="vanished">Проверка</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="80"/>
        <source>Plot</source>
        <translation>Чертёж</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="265"/>
        <source>Play</source>
        <translatorcomment>Проиграть</translatorcomment>
        <translation>Проигр.</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="86"/>
        <source>as Contour</source>
        <translation>В контур</translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="vanished">Тест</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="101"/>
        <source>Run</source>
        <translation>Работа</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="102"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="160"/>
        <location filename="form_edit.cpp" line="252"/>
        <source>G-code (*.nc *.NC)</source>
        <translation>Файлы G-код (*.nc *.NC)</translation>
    </message>
    <message>
        <source>All files (*)</source>
        <translation type="vanished">Все файлы (*)</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="160"/>
        <source>Open G-code file</source>
        <translation>Открыть G-код файл</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="250"/>
        <source>Save G-code file</source>
        <translation>Сохранить G-код файл</translation>
    </message>
    <message>
        <location filename="form_edit.cpp" line="271"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
</context>
<context>
    <name>FormHelp</name>
    <message>
        <location filename="form_help.cpp" line="32"/>
        <source>Help file not found</source>
        <translation>Файл помощи не найден</translation>
    </message>
    <message>
        <location filename="form_help.cpp" line="48"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
</context>
<context>
    <name>FormHome</name>
    <message>
        <location filename="formhome.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="formhome.ui" line="37"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="44"/>
        <source>Contour</source>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="51"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="58"/>
        <source>Run</source>
        <translation>Работа</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="68"/>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="78"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="88"/>
        <location filename="formhome.ui" line="94"/>
        <location filename="formhome.ui" line="97"/>
        <source>G-code Recovery</source>
        <translation>Восстановить G-код</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="100"/>
        <source>Recovery</source>
        <translatorcomment>Восстановить</translatorcomment>
        <translation>Восстан.</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="140"/>
        <source>Test</source>
        <translation>Тест</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="150"/>
        <source>Minimize Program</source>
        <translation>Свернуть программу</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="153"/>
        <source>Minimize</source>
        <translation>Свернуть</translation>
    </message>
    <message>
        <source>Diagnostic</source>
        <translation type="vanished">Диагностика</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="163"/>
        <source>Shutdown</source>
        <translatorcomment>Выключение</translatorcomment>
        <translation>Выкл.</translation>
    </message>
    <message>
        <location filename="formhome.ui" line="173"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="109"/>
        <source>Info: </source>
        <translation>Информация: </translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="109"/>
        <source>Connecting...</source>
        <translation>Соединение...</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="115"/>
        <source>UART port is not found</source>
        <translation>Последовательный порт не найден</translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="115"/>
        <location filename="form_home.cpp" line="121"/>
        <source>Error: </source>
        <translation>Ошибка: </translation>
    </message>
    <message>
        <location filename="form_home.cpp" line="121"/>
        <source>No connection. Check conection between computer and CNC board</source>
        <translation>Нет соединения. Проверьте соединение между компьютером и платой ЧПУ</translation>
    </message>
    <message>
        <location filename="form_home.h" line="17"/>
        <source>Meatec CNC Machine</source>
        <oldsource>MACHINE_NAME</oldsource>
        <translation>Станок с ЧПУ фирмы Меатэк</translation>
    </message>
    <message>
        <location filename="form_home.h" line="18"/>
        <source>MODEL_NAME</source>
        <translation>ИМЯ_МОДЕЛИ</translation>
    </message>
    <message>
        <location filename="form_home.h" line="20"/>
        <source>Model</source>
        <translation>Модель</translation>
    </message>
    <message>
        <source>Meatec CNC Machine: </source>
        <translation type="vanished">Станок с ЧПУ фирмы Меатэк: </translation>
    </message>
</context>
<context>
    <name>FormPasses</name>
    <message>
        <location filename="form_passes.cpp" line="12"/>
        <source>Cutting settings</source>
        <oldsource>&lt;h2&gt;Cutting settings&lt;/h2&gt;</oldsource>
        <translation>Параметры реза</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="52"/>
        <source>Left Offset</source>
        <translation>Левое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="53"/>
        <source>Right Offset</source>
        <translation>Правое смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="62"/>
        <source>Cut Times</source>
        <translation>Количество проходов</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="79"/>
        <source>Overlap</source>
        <translation>Перерез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="82"/>
        <location filename="form_passes.cpp" line="105"/>
        <location filename="form_passes.cpp" line="131"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="87"/>
        <source>Tab Width</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <source>Offset</source>
        <translation type="vanished">Смещение</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="458"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="119"/>
        <source>Onepass Cutting</source>
        <translation>Однопроходный рез</translation>
    </message>
    <message>
        <source>Pass</source>
        <translation type="vanished">Проход</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="120"/>
        <source>Multipass Cutting</source>
        <translation>Многопроходный рез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="122"/>
        <source>Tab</source>
        <translation>Недорез</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="128"/>
        <source>Tab Offset</source>
        <translation>Смещение при дорезе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="136"/>
        <source>Cutline Mode</source>
        <translation>Режим линии захода</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="140"/>
        <source>Tab Mode</source>
        <translation>Режим при дорезе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="144"/>
        <source>Tab Pause</source>
        <translation>Остановка перед дорезанием</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="146"/>
        <source>Pump Delay</source>
        <translation>Задержка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="149"/>
        <source>sec</source>
        <translation>сек</translation>
    </message>
    <message>
        <source> sec</source>
        <translation type="vanished"> сек</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="102"/>
        <source>Offset in pass</source>
        <translation>Смещение при проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="111"/>
        <source>Mode in pass</source>
        <translation>Режим при проходе</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="153"/>
        <source>Pump Pause</source>
        <translation>Остановка по включению насоса</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="327"/>
        <source>Table of Generator Operation Modes</source>
        <oldsource>&lt;h3&gt;Generator Operation Modes&lt;/h3&gt;</oldsource>
        <translation>Таблица режимов работы генератора</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="339"/>
        <source>New</source>
        <translation>Новый</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="340"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="341"/>
        <source>Open</source>
        <translation>Открыть</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="342"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="343"/>
        <source>Save As</source>
        <translatorcomment>Сохранить как</translatorcomment>
        <translation>Сохр. как</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="344"/>
        <source>Factory</source>
        <translation>Сброс</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="393"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_passes.cpp" line="431"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormPult</name>
    <message>
        <location filename="form_pult.cpp" line="19"/>
        <source>Pult</source>
        <translation>Пульт</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="71"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="75"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="79"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="83"/>
        <source>Voltage</source>
        <translatorcomment>Напряжение</translatorcomment>
        <translation>Напряж.</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="87"/>
        <location filename="form_pult.cpp" line="93"/>
        <location filename="form_pult.cpp" line="99"/>
        <location filename="form_pult.cpp" line="105"/>
        <location filename="form_pult.cpp" line="111"/>
        <source>DEC</source>
        <translation>Минус</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="90"/>
        <location filename="form_pult.cpp" line="96"/>
        <location filename="form_pult.cpp" line="102"/>
        <location filename="form_pult.cpp" line="108"/>
        <location filename="form_pult.cpp" line="114"/>
        <source>INC</source>
        <translation>Плюс</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="68"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="117"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="204"/>
        <source>Drum: </source>
        <translation>Барабан: </translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="206"/>
        <source>Width: </source>
        <translation>Ширина: </translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="208"/>
        <source>Ratio: </source>
        <translatorcomment>Скважность: </translatorcomment>
        <translation>Скважн.: </translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="210"/>
        <source>Voltage: </source>
        <translatorcomment>Напряжение: </translatorcomment>
        <translation>Напряж.: </translation>
    </message>
    <message>
        <location filename="form_pult.cpp" line="212"/>
        <source>Current: </source>
        <translation>Ток: </translation>
    </message>
</context>
<context>
    <name>FormRun</name>
    <message>
        <location filename="form_run.cpp" line="87"/>
        <source>Drum</source>
        <translation>Барабан</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="83"/>
        <source>Pump</source>
        <translation>Насос</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="79"/>
        <source>Wire</source>
        <translation>Проволока</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="99"/>
        <source>Voltage</source>
        <translatorcomment>Напряжение</translatorcomment>
        <translation>Напряж.</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="91"/>
        <location filename="form_run.cpp" line="106"/>
        <location filename="form_run.cpp" line="120"/>
        <location filename="form_run.cpp" line="134"/>
        <location filename="form_run.cpp" line="148"/>
        <source>DEC</source>
        <translation>Минус</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="94"/>
        <location filename="form_run.cpp" line="113"/>
        <location filename="form_run.cpp" line="127"/>
        <location filename="form_run.cpp" line="141"/>
        <location filename="form_run.cpp" line="155"/>
        <source>INC</source>
        <translation>Плюс</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="73"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="76"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="263"/>
        <source>Drum: </source>
        <translation>Барабан: </translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="265"/>
        <source>Width: </source>
        <translation>Ширина: </translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="267"/>
        <source>Ratio: </source>
        <translatorcomment>Скважность: </translatorcomment>
        <translation>Скважн.: </translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="269"/>
        <source>Voltage: </source>
        <translatorcomment>Напряжение: </translatorcomment>
        <translation>Напряж.: </translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="271"/>
        <source>Current: </source>
        <translation>Ток: </translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="369"/>
        <location filename="form_run.cpp" line="381"/>
        <location filename="form_run.cpp" line="390"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="369"/>
        <source>No G-code</source>
        <translation>Не загружен G-код</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="381"/>
        <source>G-code error</source>
        <translation>ошибка G-кода</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="390"/>
        <source>No CNC connection</source>
        <translation>Нет связи с ЧПУ</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="436"/>
        <location filename="form_run.cpp" line="441"/>
        <location filename="form_run.cpp" line="451"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="436"/>
        <location filename="form_run.cpp" line="441"/>
        <location filename="form_run.cpp" line="451"/>
        <source>Reverse</source>
        <translation>Реверс</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="436"/>
        <location filename="form_run.cpp" line="441"/>
        <location filename="form_run.cpp" line="451"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="446"/>
        <location filename="form_run.cpp" line="456"/>
        <location filename="form_run.cpp" line="466"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="461"/>
        <source>Shortcut</source>
        <translation>Выход</translation>
    </message>
    <message>
        <location filename="form_run.cpp" line="471"/>
        <source>Reset</source>
        <translation>Сброс</translation>
    </message>
</context>
<context>
    <name>FormSettings</name>
    <message>
        <location filename="form_settings.cpp" line="53"/>
        <source>&lt;h2&gt;Settings&lt;/h2&gt;</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="54"/>
        <source>&lt;h3&gt;CNC parameters&lt;/h3&gt;</source>
        <translation>Параметры ЧПУ</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="65"/>
        <source>Input Levels, bits: </source>
        <translation>Входные уровни, биты: </translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="78"/>
        <source>Metal</source>
        <translation>Метал</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="79"/>
        <source>Stone</source>
        <translation>Камень</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="80"/>
        <source>Test</source>
        <translation>Тест</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="82"/>
        <source>Step, mm: </source>
        <translation>Шаг, мм: </translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="96"/>
        <source>Scale (steps/mm)</source>
        <translation>Масштаб (шагов/мм)</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="97"/>
        <source>Motor</source>
        <translation>Мотор</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="98"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <source>Scale (steps/mm):</source>
        <translation type="vanished">Масштаб (шагов/мм):</translation>
    </message>
    <message>
        <source>Motor:</source>
        <translation type="vanished">Мотор:</translation>
    </message>
    <message>
        <source>Encoder:</source>
        <translation type="vanished">Энкодер:</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="260"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="263"/>
        <source>Read</source>
        <translation>Чтение</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="266"/>
        <source>Write</source>
        <translation>Запись</translation>
    </message>
    <message>
        <location filename="form_settings.cpp" line="309"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>FormTest</name>
    <message>
        <location filename="formtest.ui" line="14"/>
        <source>Form</source>
        <translation></translation>
    </message>
    <message>
        <location filename="formtest.ui" line="31"/>
        <source>Home</source>
        <translation>Главная</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="38"/>
        <source>Quick Test</source>
        <translatorcomment>Быстрый тест</translatorcomment>
        <translation>Быстрый</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="45"/>
        <source>Full Test</source>
        <translatorcomment>Полный тест</translatorcomment>
        <translation>Полный</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="52"/>
        <source>Imitation</source>
        <translatorcomment>Имитация</translatorcomment>
        <translation>Имит.</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="59"/>
        <source>Read CNC</source>
        <translatorcomment>Прочитать программу ЧПУ</translatorcomment>
        <translation>Читать</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="115"/>
        <source>G-code</source>
        <translation>G-код</translation>
    </message>
    <message>
        <location filename="formtest.ui" line="122"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="form_test.cpp" line="112"/>
        <location filename="form_test.cpp" line="118"/>
        <source>Error: No G-code program
</source>
        <translation>Ошибка: Нет программы G-код\n</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <source>Warning: </source>
        <translation>Предупреждение: </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="92"/>
        <source>Error: </source>
        <translation>Ошибка: </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="125"/>
        <source>Meatec</source>
        <translation>Меатэк</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="184"/>
        <source>Load DXF contours</source>
        <translation>Загрузка DXF</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="190"/>
        <source>Code Edit Page</source>
        <translation>Редактор</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="197"/>
        <source>Run Page</source>
        <translation>Работа</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="203"/>
        <source>CNC Settigns</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="208"/>
        <source>CNC Pult</source>
        <translation>Пульт станка</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="214"/>
        <source>Test Page</source>
        <translation>Диагностика</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>Home Page</source>
        <translation>Главная страница</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="226"/>
        <source>Passes Page</source>
        <translation>Проходы</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="231"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
</context>
<context>
    <name>ModeTableModel</name>
    <message>
        <source>Drum
Velocity</source>
        <oldsource>Drum Velocity</oldsource>
        <translation type="vanished">Скорость\nбарабана</translation>
    </message>
    <message>
        <source>Drum</source>
        <translation type="vanished">Скорость</translation>
    </message>
    <message>
        <source>Velocity</source>
        <translation type="vanished">барабана</translation>
    </message>
    <message>
        <source>Pulse</source>
        <oldsource>Pulse
Width</oldsource>
        <translation type="vanished">Длительность</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">импульса</translation>
    </message>
    <message>
        <source>Voltage</source>
        <oldsource>Voltage
Level</oldsource>
        <translation type="vanished">Напряжения</translation>
    </message>
    <message>
        <source>Current</source>
        <oldsource>Current
Index</oldsource>
        <translation type="vanished">Ток</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="16"/>
        <source>Drum Velocity</source>
        <translation>Скорость барабана</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="17"/>
        <source>Pulse Width</source>
        <translation>Ширина импульса</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="18"/>
        <source>Pulse Ratio</source>
        <translatorcomment>Скважность импульсов</translatorcomment>
        <translation>Скважн. импульсов</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="19"/>
        <source>Voltage Level</source>
        <translatorcomment>Уровень напряжения</translatorcomment>
        <translation>Уровень напр.</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="20"/>
        <source>Current Index</source>
        <translation>Уровень тока</translation>
    </message>
    <message>
        <location filename="mode_table_model.cpp" line="27"/>
        <source>Mode</source>
        <translation>Режим</translation>
    </message>
</context>
<context>
    <name>NewCutlineDialog</name>
    <message>
        <location filename="new_cutline_dialog.cpp" line="43"/>
        <source>Abs</source>
        <translatorcomment>Абсолютные</translatorcomment>
        <translation>Абс.</translation>
    </message>
    <message>
        <location filename="new_cutline_dialog.cpp" line="44"/>
        <source>Rel</source>
        <translatorcomment>Относительные</translatorcomment>
        <translation>Отн.</translation>
    </message>
</context>
<context>
    <name>PultWidget</name>
    <message>
        <location filename="pult_widget.cpp" line="129"/>
        <location filename="pult_widget.cpp" line="247"/>
        <source>Motor</source>
        <translation>Мотор</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="130"/>
        <location filename="pult_widget.cpp" line="248"/>
        <source>Encoder</source>
        <translation>Энкодер</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="131"/>
        <location filename="pult_widget.cpp" line="421"/>
        <source>mm</source>
        <translation>мм</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="132"/>
        <location filename="pult_widget.cpp" line="422"/>
        <source>steps</source>
        <translation>шаги</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="157"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="161"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="246"/>
        <source>Scale (steps/mm)</source>
        <translation>Масштаб (шагов/мм)</translation>
    </message>
    <message>
        <source>Scale (steps/mm):</source>
        <translation type="vanished">Масштаб (шагов/мм):</translation>
    </message>
    <message>
        <source>Motor:</source>
        <translation type="vanished">Мотор:</translation>
    </message>
    <message>
        <source>Encoder:</source>
        <translation type="vanished">Энкодер:</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="259"/>
        <source>Move</source>
        <translation>Движение</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="260"/>
        <source>Set</source>
        <translation>Установить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="261"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="434"/>
        <source>Speed:</source>
        <translation>Скорость:</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="440"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="pult_widget.cpp" line="441"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Error: </source>
        <translation type="vanished">Ошибка: </translation>
    </message>
</context>
<context>
    <name>RunWidget</name>
    <message>
        <location filename="run_widget.cpp" line="35"/>
        <source>Start</source>
        <translation>Пуск</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="35"/>
        <source>Reverse</source>
        <translation>Реверс</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="35"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="38"/>
        <source>Hold</source>
        <translation>Держать</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="41"/>
        <source>Speed:</source>
        <translation>Скорость:</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="47"/>
        <source>mm/min</source>
        <translation>мм/мин</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="48"/>
        <source>um/sec</source>
        <translation>мкм/сек</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="105"/>
        <source>Time</source>
        <translation>Прошло</translation>
    </message>
    <message>
        <location filename="run_widget.cpp" line="106"/>
        <source>Remain</source>
        <translation>Осталось</translation>
    </message>
</context>
</TS>
