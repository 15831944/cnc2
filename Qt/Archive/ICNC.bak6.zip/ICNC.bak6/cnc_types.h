#ifndef CNC_TYPES_H
#define CNC_TYPES_H

#include <cstdint>
#include <vector>
#include <QObject>

#include "wire_cut.h"
#include "generator_mode_list.h"

enum class TAB_MODE : uint8_t { TAB_NONE, TAB_SINGLE, TAB_MULTI };

enum class cnc_state_t: uint8_t {ST_IDLE, ST_DIRECT, ST_READ, ST_SEGMENT, ST_WAIT, ST_PAUSE, ST_STOP, ST_WAIT_BUTTON, ST_END, ST_ERROR};
enum class drum_state_t: uint8_t {DRUM_DIS, DRUM_FWD, DRUM_REV, DRUM_ANY, DRUM_ERROR};

class WireSpeed {
public:
    enum class Mode: bool {UMS, MMM}; // mm/min, um/sec

    static constexpr double FPGA_FREQ = 72e6; // Hz
    static constexpr double MIN = 1 * 60 / 1000; // mm/min
    static constexpr double MAX = 300 * 60 / 1000; // mm/min

private:
    double value; // mm/min
    Mode mode;

public:
    WireSpeed(double value = MAX, WireSpeed::Mode mode = WireSpeed::Mode::MMM) {
        setMode(mode);
        set(value);
    }

    void setMode(WireSpeed::Mode value) { mode = value; }
    void set(double value) { this->value = (mode == Mode::MMM) ? value : toMMM(value); }
    void set(double value, WireSpeed::Mode mode) {
        setMode(mode);
        set(value);
    }
    double get() {
        double res = (mode == Mode::MMM) ? value : toUMS(value);

        if (res < min())
            return min();
        else if (res > max())
            return max();

        return res;
    }

    double getMMM() {
        if (value < MIN)
            return MIN;
        else if (value > MAX)
            return MAX;

        return value;
    }

    // result - mm/min
    // T - clock/mm
    static double TtoSpeed(float T) { return (FPGA_FREQ * 60.0) / double(T); }
    void setClockPerMM(float T) { value = TtoSpeed(T); }

    float getClockPerMM() { return float( (FPGA_FREQ * 60.0) / value ); }

    double min() { return mode == Mode::MMM ? MIN : toUMS(MIN); }
    double max() { return mode == Mode::MMM ? MAX : toUMS(MAX); }

    static double toUMS(double value) { return value * (1000.0 / 60.0); }
    static double toMMM(double value) { return value * (60.0 / 1000.0); }
    static float toMMM(float value) { return value * (60.0f / 1000.0f); }
};

#endif // CNC_TYPES_H
